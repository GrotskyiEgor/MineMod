package com.therootsofancientmagic.world;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7924;

public class ModPlacedFeatures {

    public static final class_5321<class_6796> EARTH_DARK_OAK =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("earth_dark_oak")
            );
}
