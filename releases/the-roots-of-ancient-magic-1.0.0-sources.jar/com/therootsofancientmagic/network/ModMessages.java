package com.therootsofancientmagic.network;

import com.therootsofancientmagic.network.ManaSyncS2CPacket;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class ModMessages {
    // Создает уникальний айди канал
    public static final class_2960 MANA_SYNC_ID = new class_2960("the-roots-of-ancient-magic", "mana_sync");

    // Метод для регистрации приемников пакетов
    public static void registerC2SPackets() {
    }

    // Регистрирует пакет на клиенте
    public static void registerS2CPackets() {
        ClientPlayNetworking.registerGlobalReceiver(MANA_SYNC_ID, ManaSyncS2CPacket::receive);
    }

    public static void sendToClient(class_3222 player, int mana) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeInt(mana);
        
        // Отправляет пакет по каналу конкретному игроку
        ServerPlayNetworking.send(player, MANA_SYNC_ID, buf);
    }
}
