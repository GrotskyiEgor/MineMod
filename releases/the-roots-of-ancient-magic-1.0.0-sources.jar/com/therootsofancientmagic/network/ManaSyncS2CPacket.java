package com.therootsofancientmagic.network;

import com.therootsofancientmagic.util.IEntityDataSaver;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_310;
import net.minecraft.class_634;

public class ManaSyncS2CPacket {

    public static void receive(class_310 client, class_634 handler,
                               class_2540 buf, PacketSender responseSender) {
        
        int mana = buf.readInt();

       
        client.execute(() -> {
            if (client.field_1724 instanceof IEntityDataSaver dataSaver) {
                dataSaver.getPersistentData().method_10569("mana", mana);
            }
        });
    }
}
