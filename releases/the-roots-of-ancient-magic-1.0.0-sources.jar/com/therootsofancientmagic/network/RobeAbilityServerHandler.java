package com.therootsofancientmagic.network;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import com.therootsofancientmagic.component.CustomArmorHolder;
import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import com.therootsofancientmagic.item.ModItem;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1263;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import com.therootsofancientmagic.client.TheRootsOfAncientMagicClient;

public class RobeAbilityServerHandler {
    public static final class_2960 ROBE_ABILITY_PACKET = new class_2960(TheRootsOfAncientMagic.MOD_ID, "robe_ability");

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(ROBE_ABILITY_PACKET, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                
                if (!(player instanceof CustomArmorHolder holder)) return;
                class_1263 inventory = holder.getCustomArmorInventory();
                if (inventory == null) return;

                class_1799 backStack = inventory.method_5438(0);
                if (backStack.method_7960()) return;

                class_1792 robeItem = backStack.method_7909();

                if (player.method_7357().method_7904(robeItem)) return;
                
                if (!player.method_7337() && !PlayerMana.consumeMana((IEntityDataSaver) player, 50, player)) {
                    return;
                }

                class_3218 world = player.method_51469();

                if (backStack.method_31574(ModItem.AQUA_ROBE)) {
                    player.method_6092(new class_1293(class_1294.field_5900, 600, 0, true, false, false));
                    player.method_6092(new class_1293(class_1294.field_5923, 600, 0, true, false, false));

                    world.method_14199(class_2398.field_11247, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 30, 0.5, 0.5, 0.5, 0.15);
                    world.method_8396(null, player.method_24515(), class_3417.field_14912, class_3419.field_15248, 1.0F, 1.0F);

                    player.method_7357().method_7906(robeItem, 700);

                } else if (backStack.method_31574(ModItem.AIR_ROBE)) {
                    player.method_6092(new class_1293(class_1294.field_5902, 40, 2, true, false, false));
                    player.method_6092(new class_1293(class_1294.field_5906, 140, 0, true, false, false));

                    world.method_14199(class_2398.field_11207, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 30, 0.5, 0.5, 0.5, 0.15);
                    world.method_8396(null, player.method_24515(), class_3417.field_14858, class_3419.field_15248, 1.0F, 1.2F);

                    player.method_7357().method_7906(robeItem, 100);

                } else if (backStack.method_31574(ModItem.EARTH_ROBE)) {
                    player.method_6092(new class_1293(class_1294.field_5913, 600, 1, true, false, false));
                    player.method_6092(new class_1293(class_1294.field_5917, 600, 1, true, false, false));

                    world.method_14199(
                        new net.minecraft.class_2388(class_2398.field_11217, net.minecraft.class_2246.field_10566.method_9564()),
                        player.method_23317(), player.method_23318() + 0.1, player.method_23321(), 40, 0.5, 0.2, 0.5, 0.1
                    );
                    world.method_8396(null, player.method_24515(), class_3417.field_28601, class_3419.field_15248, 1.0F, 0.8F);

                    player.method_7357().method_7906(robeItem, 700);

                } else if (backStack.method_31574(ModItem.FIRE_ROBE)) {
                    player.method_6092(new class_1293(class_1294.field_5918, 600, 0, true, false, false));
                    player.method_6092(new class_1293(class_1294.field_5910, 600, 1, true, false, false));

                    holder.activateFireRobeAbility();

                    world.method_14199(class_2398.field_11240, player.method_23317(), player.method_23318() + 0.1, player.method_23321(), 50, 0.5, 0.5, 0.5, 0.1);
                    world.method_8396(null, player.method_24515(), class_3417.field_15013, class_3419.field_15248, 1.0F, 1.0F);

                    player.method_7357().method_7906(robeItem, 700);
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(TheRootsOfAncientMagicClient.FIRST_RING_PACKET, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                if (player instanceof CustomArmorHolder holder) {
                    holder.useFirstRingAbility();
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(TheRootsOfAncientMagicClient.SECOND_RING_PACKET, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                if (player instanceof CustomArmorHolder holder) {
                    holder.useSecondRingAbility();
                }
            });
        });
    }
}
