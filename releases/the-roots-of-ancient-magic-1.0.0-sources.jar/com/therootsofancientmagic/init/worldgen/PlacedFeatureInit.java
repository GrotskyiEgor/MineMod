package com.therootsofancientmagic.init.worldgen;

import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2382;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_6646;
import net.minecraft.class_6658;
import net.minecraft.class_6793;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6804;
import net.minecraft.class_6808;
import net.minecraft.class_6817;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import com.therootsofancientmagic.TheRootsOfAncientMagic;

public class PlacedFeatureInit {

    public static final class_5321<class_6796> FLOWER_DARK_PLACED_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("flower_dark_placed")
            );

    public static final class_5321<class_6796> FLOWER_LIGHT_PLACED_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("flower_light_placed")
            );

    public static final class_5321<class_6796> FLOWER_AIR_PLACED_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("flower_air_placed")
            );

    public static final class_5321<class_6796> FLOWER_EARTH_PLACED_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("flower_earth_placed")
            );

    public static final class_5321<class_6796> FLOWER_FIRE_PLACED_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("flower_fire_placed")
            );

    public static final class_5321<class_6796> FLOWER_AQUA_PLACED_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("flower_aqua_placed")
            );

    public static final class_5321<class_6796> EARTH_DARK_OAK_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("earth_dark_oak")
            );

    public static final class_5321<class_6796> EARTH_BROWN_MUSHROOM_PLACED_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("earth_brown_mushroom")
            );

    public static final class_5321<class_6796> EARTH_HUGE_BROWN_MUSHROOM_PLACED_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("earth_huge_brown_mushroom")
            );

    public static final class_5321<class_6796> FIRE_LAVA_LAKE_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("fire_lava_lake")
            );

    public static final class_5321<class_6796> DARK_RED_MUSHROOM_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("dark_red_mushroom")
            );

    public static final class_5321<class_6796> DARK_SPRUCE_KEY =
            class_5321.method_29179(
                    class_7924.field_41245,
                    TheRootsOfAncientMagic.id("dark_spruce")
            );

    public static final class_5321<class_6796> FIRE_ACACIA_KEY =
        class_5321.method_29179(
                class_7924.field_41245,
                TheRootsOfAncientMagic.id("fire_acacia")
        );

    public static final List<class_5321<class_6796>> FLOWERS_KEYS =
            List.of(
                    FLOWER_DARK_PLACED_KEY,
                    FLOWER_LIGHT_PLACED_KEY,
                    FLOWER_AIR_PLACED_KEY,
                    FLOWER_EARTH_PLACED_KEY,
                    FLOWER_AQUA_PLACED_KEY
            );

    private static class_5321<class_2975<?, ?>>
    getKeyForConfiguredFeatureEntry(
            class_5321<class_6796> key
    ) {
        String path = key.method_29177().method_12832();

        return switch (path) {
            case "flower_dark_placed" ->
                    ConfigureFeatureInit.FLOWER_DARK_KEY;

            case "flower_light_placed" ->
                    ConfigureFeatureInit.FLOWER_LIGHT_KEY;

            case "flower_air_placed" ->
                    ConfigureFeatureInit.FLOWER_AIR_KEY;

            case "flower_earth_placed" ->
                    ConfigureFeatureInit.FLOWER_EARTH_KEY;

            case "flower_aqua_placed" ->
                    ConfigureFeatureInit.FLOWER_AQUA_KEY;

            case "flower_fire_placed" ->
                    ConfigureFeatureInit.FLOWER_FIRE_KEY;

            default ->
                    throw new IllegalArgumentException(
                            "Unknown flower patch: " + path
                    );
        };
    }

    private static class_6880<class_2975<?, ?>>
    getConfiguredFeatureEntry(
            class_7891<class_6796> context,
            class_5321<class_2975<?, ?>> configuredKey
    ) {
        return context
                .method_46799(class_7924.field_41239)
                .method_46747(configuredKey);
    }

    private static List<class_6797> getModifiers() {
        return List.of(
                class_6799.method_39659(4),
                class_5450.method_39639(),
                class_6817.field_36078
        );
    }

    public static void bootstrap(
            class_7891<class_6796> context
    ) {
        List<class_6797> modifiers = getModifiers();

        for (class_5321<class_6796> placeKey : FLOWERS_KEYS) {
            class_5321<class_2975<?, ?>> configuredKey =
                    getKeyForConfiguredFeatureEntry(placeKey);

            class_6880<class_2975<?, ?>> configuredFeatureEntry =
                    getConfiguredFeatureEntry(
                            context,
                            configuredKey
                    );

            context.method_46838(
                    placeKey,
                    new class_6796(
                            configuredFeatureEntry,
                            modifiers
                    )
            );
        }

        context.method_46838(
                FLOWER_FIRE_PLACED_KEY,
                new class_6796(
                        getConfiguredFeatureEntry(
                                context,
                                ConfigureFeatureInit.FLOWER_FIRE_KEY
                        ),
                        List.of(
                                class_6799.method_39659(2),
                                class_5450.method_39639(),
                                class_6817.field_36078
                        )
                )
        );

        class_6880<class_2975<?, ?>> darkOak =
                context.method_46799(
                        class_7924.field_41239
                ).method_46747(
                        class_6808.field_35906
                );

        context.method_46838(
                EARTH_DARK_OAK_KEY,
                new class_6796(
                        darkOak,
                        List.of(
                                class_6793.method_39623(4),
                                class_5450.method_39639(),
                                class_6817.field_36078,
                                class_6658.method_39618(
                                        class_6646.method_39009(
                                                class_2246.field_10160
                                                        .method_9564(),
                                                class_2382.field_11176
                                        )
                                )
                        )
                )
        );

        class_6880<class_2975<?, ?>> brownMushroom =
                context.method_46799(
                        class_7924.field_41239
                ).method_46747(
                        ConfigureFeatureInit.EARTH_BROWN_MUSHROOM_KEY
                );

        context.method_46838(
                EARTH_BROWN_MUSHROOM_PLACED_KEY,
                new class_6796(
                        brownMushroom,
                        List.of(
                                class_6793.method_39623(2),
                                class_5450.method_39639(),
                                class_6817.field_36078,
                                class_6658.method_39618(
                                        class_6646.method_39009(
                                                class_2246.field_10251
                                                        .method_9564(),
                                                class_2382.field_11176
                                        )
                                )
                        )
                )
        );

        class_6880<class_2975<?, ?>> hugeBrownMushroom =
                context.method_46799(
                        class_7924.field_41239
                ).method_46747(
                        class_6808.field_35903
                );

        context.method_46838(
                EARTH_HUGE_BROWN_MUSHROOM_PLACED_KEY,
                new class_6796(
                        hugeBrownMushroom,
                        List.of(
                                class_6799.method_39659(2),
                                class_5450.method_39639(),
                                class_6817.field_36078,
                                class_6658.method_39618(
                                        class_6646.method_39009(
                                                class_2246.field_10251
                                                        .method_9564(),
                                                class_2382.field_11176
                                        )
                                )
                        )
                )
        );

        class_6880<class_2975<?, ?>> lavaLake =
                context.method_46799(
                        class_7924.field_41239
                ).method_46747(
                        class_6804.field_35806
                );

        context.method_46838(
                FIRE_LAVA_LAKE_KEY,
                new class_6796(
                        lavaLake,
                        List.of(
                                class_6799.method_39659(2),
                                class_5450.method_39639(),
                                class_6817.field_36078
                        )
                )
        );

        class_6880<class_2975<?, ?>> spruce =
                context.method_46799(
                        class_7924.field_41239
                ).method_46747(
                        class_6808.field_35905
                );

        context.method_46838(
                DARK_SPRUCE_KEY,
                new class_6796(
                        spruce,
                        List.of(
                                class_6799.method_39659(12),
                                class_5450.method_39639(),
                                class_6817.field_36078,
                                class_6658.method_39618(
                                        class_6646.method_39009(
                                                class_2246.field_10217
                                                        .method_9564(),
                                                class_2382.field_11176
                                        )
                                )
                        )
                )
        );

        class_6880<class_2975<?, ?>> redMushroom =
                context.method_46799(
                        class_7924.field_41239
                ).method_46747(
                        ConfigureFeatureInit.DARK_RED_MUSHROOM_KEY
                );

        context.method_46838(
                DARK_RED_MUSHROOM_KEY,
                new class_6796(
                        redMushroom,
                        List.of(
                                class_6799.method_39659(12),
                                class_5450.method_39639(),
                                class_6817.field_36078,
                                class_6658.method_39618(
                                        class_6646.method_39009(
                                                class_2246.field_10559
                                                        .method_9564(),
                                                class_2382.field_11176
                                        )
                                )
                        )
                )
        );

        class_6880<class_2975<?, ?>> acacia =
        context.method_46799(
                class_7924.field_41239
        ).method_46747(
                class_6808.field_35908
        );

        context.method_46838(
                FIRE_ACACIA_KEY,
                new class_6796(
                        acacia,
                        List.of(
                                class_6793.method_39623(4),
                                class_5450.method_39639(),
                                class_6817.field_36078,
                                class_6658.method_39618(
                                        class_6646.method_39009(
                                                class_2246.field_10385.method_9564(),
                                                class_2382.field_11176
                                        )
                                )
                        )
                )
        );
    }
}