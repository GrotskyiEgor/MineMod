package com.therootsofancientmagic.init.worldgen;

import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_4635;
import net.minecraft.class_4638;
import net.minecraft.class_4651;
import net.minecraft.class_5321;
import net.minecraft.class_6808;
import net.minecraft.class_6817;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import com.therootsofancientmagic.TheRootsOfAncientMagic;
import com.therootsofancientmagic.block.ModFlowerBlock;

public class ConfigureFeatureInit {

    public static final class_5321<class_2975<?, ?>> FLOWER_DARK_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("flower_dark_patch")
            );

    public static final class_5321<class_2975<?, ?>> FLOWER_LIGHT_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("flower_light_patch")
            );

    public static final class_5321<class_2975<?, ?>> FLOWER_AIR_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("flower_air_patch")
            );

    public static final class_5321<class_2975<?, ?>> FLOWER_EARTH_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("flower_earth_patch")
            );

    public static final class_5321<class_2975<?, ?>> FLOWER_FIRE_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("flower_fire_patch")
            );

    public static final class_5321<class_2975<?, ?>> FLOWER_AQUA_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("flower_aqua_patch")
            );

    public static final class_5321<class_2975<?, ?>> DARK_RED_MUSHROOM_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("dark_red_mushroom")
            );

    public static final class_5321<class_2975<?, ?>> EARTH_DARK_OAK_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("earth_dark_oak")
            );

    public static final class_5321<class_2975<?, ?>> EARTH_BROWN_MUSHROOM_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("earth_brown_mushroom")
            );

    public static final class_5321<class_2975<?, ?>> EARTH_HUGE_BROWN_MUSHROOM_KEY =
            class_5321.method_29179(
                    class_7924.field_41239,
                    TheRootsOfAncientMagic.id("earth_huge_brown_mushroom")
            );
            
    public static final List<class_5321<class_2975<?, ?>>> FLOWERS = List.of(
            FLOWER_DARK_KEY,
            FLOWER_LIGHT_KEY,
            FLOWER_AIR_KEY,
            FLOWER_EARTH_KEY,
            FLOWER_FIRE_KEY,
            FLOWER_AQUA_KEY
    );

    private static class_2248 getBlockForKey(
            class_5321<class_2975<?, ?>> key
    ) {
        String path = key.method_29177().method_12832();

        return switch (path) {
            case "flower_dark_patch" -> ModFlowerBlock.FLOWER_DARK;
            case "flower_light_patch" -> ModFlowerBlock.FLOWER_LIGHT;
            case "flower_air_patch" -> ModFlowerBlock.FLOWER_AIR;
            case "flower_earth_patch" -> ModFlowerBlock.FLOWER_EARTH;
            case "flower_fire_patch" -> ModFlowerBlock.FLOWER_FIRE;
            case "flower_aqua_patch" -> ModFlowerBlock.FLOWER_AQUA;
            default -> throw new IllegalArgumentException(
                    "Unknown flower patch: " + path
            );
        };
    }

    private static class_3175 getFlowerConfig(
            class_2248 blockFlower
    ) {
        return new class_3175(
                class_4651.method_38433(
                        blockFlower.method_9564()
                )
        );
    }

    private static class_4638 getPatchConfig(
            class_3175 flowerConfig
    ) {
        return new class_4638(
                32,
                6,
                2,
                class_6817.method_40366(
                        class_3031.field_13518,
                        flowerConfig
                )
        );
    }

    public static void bootstrap(
            class_7891<class_2975<?, ?>> context
    ) {
        for (class_5321<class_2975<?, ?>> key : FLOWERS) {
            class_2248 blockFlower = getBlockForKey(key);

            class_3175 flower =
                    getFlowerConfig(blockFlower);

            context.method_46838(
                    key,
                    new class_2975<>(
                            class_3031.field_21220,
                            getPatchConfig(flower)
                    )
            );
        }

        context.method_46838(
                EARTH_BROWN_MUSHROOM_KEY,
                new class_2975<>(
                        class_3031.field_21220,
                        new class_4638(
                                64,
                                7,
                                3,
                                class_6817.method_40366(
                                        class_3031.field_13518,
                                        new class_3175(
                                                class_4651.method_38433(
                                                        class_2246.field_10251
                                                                .method_9564()
                                                )
                                        )
                                )
                        )
                )
        );

        context.method_46838(
                EARTH_HUGE_BROWN_MUSHROOM_KEY,
                new class_2975<>(
                        class_3031.field_13531,
                        new class_4635(
                                class_4651.method_38433(
                                        class_2246.field_10580
                                                .method_9564()
                                ),
                                class_4651.method_38433(
                                        class_2246.field_10556
                                                .method_9564()
                                ),
                                4
                        )
                )
        );

        context.method_46838(
                DARK_RED_MUSHROOM_KEY,
                new class_2975<>(
                        class_3031.field_21220,
                        new class_4638(
                                8,
                                4,
                                1,
                                class_6817.method_40366(
                                        class_3031.field_13518,
                                        new class_3175(
                                                class_4651.method_38433(
                                                        class_2246.field_10559
                                                                .method_9564()
                                                )
                                        )
                                )
                        )
                )
        );

        class_6880<class_2975<?, ?>> acacia =
            context.method_46799(
                    class_7924.field_41239
            ).method_46747(
                    class_6808.field_35908
            );
    }
}