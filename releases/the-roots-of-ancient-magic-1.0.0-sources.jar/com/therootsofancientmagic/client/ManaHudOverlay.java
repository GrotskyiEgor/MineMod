package com.therootsofancientmagic.client; 

import com.therootsofancientmagic.util.IEntityDataSaver;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ManaHudOverlay implements HudRenderCallback {

    private static final class_2960 MANA_TEXTURE = new class_2960("the-roots-of-ancient-magic", "textures/hud/mana.png");

    @Override
    public void onHudRender(class_332 drawContext, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) return;

        if (!client.field_1724.method_7337() && !client.field_1724.method_7325()) {
            int width = client.method_22683().method_4486();
            int height = client.method_22683().method_4502();

            int currentMana = 0;
            if (client.field_1724 instanceof IEntityDataSaver dataSaver) {
                class_2487 nbt = dataSaver.getPersistentData();
                currentMana = nbt.method_10550("mana");
            }


            int xStart = width - 24; 
            int yStart = height - 25; 

            for (int i = 0; i < 10; i++) {
                int threshold = i * 10;


                int yPos = yStart - (i * 18);


                if (currentMana > threshold) {
                    // Рисует заполнений орб
                    drawContext.method_25290(MANA_TEXTURE, xStart, yPos, 0, 0, 16, 16, 32, 16);
                } else {
                    // Рисует пустой орб
                    drawContext.method_25290(MANA_TEXTURE, xStart, yPos, 16, 0, 16, 16, 32, 16);
                }
            }
        }
    }
}
