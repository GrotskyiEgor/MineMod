package com.therootsofancientmagic.client;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import com.therootsofancientmagic.client.biomes.dark.DarkBiomeParticles;
import com.therootsofancientmagic.client.biomes.earth.EarthBiomeParticles;
import com.therootsofancientmagic.client.biomes.earth.EarthWindOverlay;
import com.therootsofancientmagic.client.biomes.fire.FireBiomeParticles;
import com.therootsofancientmagic.entity.ModEntities;
import com.therootsofancientmagic.item.tools.unique_tools.BattleAxeItem;
import com.therootsofancientmagic.network.ModMessages;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class TheRootsOfAncientMagicClient implements ClientModInitializer {
    public static final class_2960 ROBE_ABILITY_PACKET = new class_2960(TheRootsOfAncientMagic.MOD_ID, "robe_ability");
    public static final class_2960 FIRST_RING_PACKET = new class_2960(TheRootsOfAncientMagic.MOD_ID, "first_ring_ability");
    public static final class_2960 SECOND_RING_PACKET = new class_2960(TheRootsOfAncientMagic.MOD_ID, "second_ring_ability");
    public static class_304 robeAbilityKey;
    public static class_304 firstRingKey;
    public static class_304 secondRingKey;

    private static boolean wasUsingBattleAxe = false;

    @Override
    public void onInitializeClient() {
        EarthBiomeParticles.register();
        EarthWindOverlay.register();

        DarkBiomeParticles.register();

        FireBiomeParticles.register();

        robeAbilityKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.therootsofancientmagic.robe_ability",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_R,
                "category.therootsofancientmagic.general"
        ));

        firstRingKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.therootsofancientmagic.first_ring_ability",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_Z,
            "category.therootsofancientmagic.keys"
        ));

        secondRingKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.therootsofancientmagic.second_ring_ability",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_V,
            "category.therootsofancientmagic.keys"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 != null) {
                
                // Проверяет, держит ли игрок чтото и если етот предмет боевой топор
                boolean isCurrentlyUsingBattleAxe = client.field_1724.method_6115() && 
                        client.field_1724.method_6030().method_7909() instanceof BattleAxeItem;

                if (isCurrentlyUsingBattleAxe && !wasUsingBattleAxe) {
                    // Если абилку нажали то переводит игрока в 3 лицо
                    if (client.field_1690.method_31044() == class_5498.field_26664) {
                        client.field_1690.method_31043(class_5498.field_26665);
                    }
                    wasUsingBattleAxe = true;
                } else if (!isCurrentlyUsingBattleAxe && wasUsingBattleAxe) {
                    // Если абилка завершилась то переводит игрока в 1 лицо
                    if (client.field_1690.method_31044() == class_5498.field_26665) {
                        client.field_1690.method_31043(class_5498.field_26664);
                    }
                    wasUsingBattleAxe = false;
                }

                while (robeAbilityKey.method_1436()) {
                    ClientPlayNetworking.send(ROBE_ABILITY_PACKET, PacketByteBufs.create());
                }

                while (firstRingKey.method_1436()) {
                    ClientPlayNetworking.send(FIRST_RING_PACKET, PacketByteBufs.create());
                }

                while (secondRingKey.method_1436()) {
                    ClientPlayNetworking.send(SECOND_RING_PACKET, PacketByteBufs.create());
                }
            }
        });
        
        ModMessages.registerS2CPackets();

        HudRenderCallback.EVENT.register(new ManaHudOverlay());

    }
}
