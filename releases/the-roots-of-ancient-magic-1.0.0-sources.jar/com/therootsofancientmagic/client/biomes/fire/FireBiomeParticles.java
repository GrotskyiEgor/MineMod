package com.therootsofancientmagic.client.biomes.fire;

import com.therootsofancientmagic.biome.ModBiomes;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_5819;
import net.minecraft.class_638;

public class FireBiomeParticles {

    private static final class_5819 RANDOM = class_5819.method_43047();

    public static void register() {

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            if (client.field_1724 == null || client.field_1687 == null) {
                return;
            }

            class_638 world = client.field_1687;
            class_2338 pos = client.field_1724.method_24515();

            // Работаем только в Fire биоме
            if (!world.method_23753(pos)
                    .method_40230()
                    .orElse(null)
                    .equals(ModBiomes.FIRE)) {
                return;
            }

            // Дым
            if (RANDOM.method_43057() < 0.50F) {
                spawnSmoke(world, pos);
            }
        });
    }

    private static void spawnSmoke(
            class_638 world,
            class_2338 pos
    ) {

        for (int i = 0; i < 3; i++) {

            double x = pos.method_10263()
                    + 0.5
                    + (RANDOM.method_43058() - 0.5) * 8.0;

            double y = pos.method_10264()
                    + 0.2
                    + RANDOM.method_43058() * 2.5;

            double z = pos.method_10260()
                    + 0.5
                    + (RANDOM.method_43058() - 0.5) * 8.0;

            world.method_8406(
                    class_2398.field_17430,
                    x,
                    y,
                    z,
                    (RANDOM.method_43058() - 0.5) * 0.01,
                    0.015 + RANDOM.method_43058() * 0.02,
                    (RANDOM.method_43058() - 0.5) * 0.01
            );
        }
    }
}