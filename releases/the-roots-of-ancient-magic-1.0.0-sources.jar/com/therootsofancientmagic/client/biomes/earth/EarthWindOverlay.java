package com.therootsofancientmagic.client.biomes.earth;

import com.mojang.blaze3d.systems.RenderSystem;
import com.therootsofancientmagic.biome.ModBiomes;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5819;
import net.minecraft.class_638;

public class EarthWindOverlay {
    private static final class_5819 RANDOM = class_5819.method_43047();
    private static final Wind[] WINDS = new Wind[32];

    public static void register() {
        for (int i = 0; i < WINDS.length; i++) {
            WINDS[i] = new Wind();
            WINDS[i].reset(true);
        }

        HudRenderCallback.EVENT.register(EarthWindOverlay::render);
    }

    private static void render(class_332 context, float tickDelta) {
        class_310 client = class_310.method_1551();

        if (client.field_1724 == null || client.field_1687 == null) return;

        class_638 world = client.field_1687;
        class_2338 pos = client.field_1724.method_24515();

        if (!world.method_23753(pos).method_40230().orElse(null).equals(ModBiomes.EARTH)) return;

        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        for (Wind wind : WINDS) {
            wind.update();

            if (wind.delay > 0) continue;

            for (int i = 0; i < wind.segments; i++) {
                float progress = i / (float) wind.segments;

                float x = (wind.x + progress * wind.lengthX) * width;
                float y = (wind.y + progress * wind.lengthY) * height;

                x += (float) Math.sin(wind.wave + i * 1.8F) * 2.0F;
                y += (float) Math.sin(wind.wave * 0.7F + i * 2.4F) * 1.5F;

                int alpha = (int) (
                        wind.alpha *
                        255.0F *
                        (1.0F - progress * 0.55F)
                );

                int color = (alpha << 24) | 0x92958A;

                int segmentLength = (int) (
                        wind.segmentLength *
                        (0.45F + RANDOM.method_43057() * 0.55F)
                );

                int thickness = Math.max(
                        1,
                        (int) wind.thickness
                );

                context.method_25294(
                        (int) x,
                        (int) y,
                        (int) x + segmentLength,
                        (int) y + thickness,
                        color
                );
            }
        }

        RenderSystem.disableBlend();
    }

    private static class Wind {
        float x;
        float y;
        float speed;
        float lengthX;
        float lengthY;
        float segmentLength;
        float thickness;
        float alpha;
        float wave;
        float waveSpeed;
        int segments;
        int delay;

        void reset(boolean firstSpawn) {
            x = -0.15F + RANDOM.method_43057() * 1.3F;
            y = -0.15F + RANDOM.method_43057() * 1.3F;

            speed = 0.003F + RANDOM.method_43057() * 0.005F;

            lengthX = 0.08F + RANDOM.method_43057() * 0.14F;
            lengthY = 0.04F + RANDOM.method_43057() * 0.10F;

            segmentLength = 4.0F + RANDOM.method_43057() * 8.0F;

            thickness = 0.5F + RANDOM.method_43057() * 0.8F;

            alpha = 0.025F + RANDOM.method_43057() * 0.075F;

            wave = RANDOM.method_43057() * 6.28F;
            waveSpeed = 0.025F + RANDOM.method_43057() * 0.07F;

            segments = 3 + RANDOM.method_43048(5);

            delay = firstSpawn
                    ? RANDOM.method_43048(40)
                    : RANDOM.method_43048(25);
        }

        void update() {
            if (delay > 0) {
                delay--;
                return;
            }

            x += speed;
            y += speed * 0.25F;

            wave += waveSpeed;

            if (x > 1.2F || y > 1.2F) {
                reset(false);
                x = -0.15F + RANDOM.method_43057() * 1.25F;
                y = -0.15F + RANDOM.method_43057() * 1.25F;
            }
        }
    }
}