package com.therootsofancientmagic.client.biomes.earth;

import com.therootsofancientmagic.biome.ModBiomes;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_5819;
import net.minecraft.class_638;

public class EarthBiomeParticles {

    private static final class_5819 RANDOM = class_5819.method_43047();

    public static void register() {

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            if (client.field_1724 == null || client.field_1687 == null) {
                return;
            }

            class_638 world = client.field_1687;
            class_2338 pos = client.field_1724.method_24515();

            if (!world.method_23753(pos)
                    .method_40230()
                    .orElse(null)
                    .equals(ModBiomes.EARTH)) {
                return;
            }

            // Серо-зелёная пыль
            if (RANDOM.method_43057() < 0.55F) {
                spawnDust(world, pos);
            }

            // Пепел
            if (RANDOM.method_43057() < 0.40F) {
                spawnAsh(world, pos);
            }

            // Светящиеся частицы
            if (RANDOM.method_43057() < 0.06F) {
                spawnGlow(world, pos);
            }

            // Споры
            if (RANDOM.method_43057() < 0.15F) {
                spawnSpore(world, pos);
            }

            // Дополнительная пыль
            if (RANDOM.method_43057() < 0.25F) {
                spawnDust(world, pos);
            }
        });
    }

    private static double randomX(class_2338 pos, double radius) {
        return pos.method_10263()
                + 0.5
                + (RANDOM.method_43058() - 0.5) * radius;
    }

    private static double randomY(class_2338 pos) {
        return pos.method_10264()
                + 0.5
                + RANDOM.method_43058() * 6.0;
    }

    private static double randomZ(class_2338 pos, double radius) {
        return pos.method_10260()
                + 0.5
                + (RANDOM.method_43058() - 0.5) * radius;
    }

    private static void spawnDust(
            class_638 world,
            class_2338 pos
    ) {

        double x = randomX(pos, 18.0);
        double y = randomY(pos);
        double z = randomZ(pos, 18.0);

        class_2390 particle =
                new class_2390(
                        new org.joml.Vector3f(
                                0.32F,
                                0.34F,
                                0.30F
                        ),
                        0.40F
                );

        world.method_8406(
                particle,
                x,
                y,
                z,
                (RANDOM.method_43058() - 0.5) * 0.012,
                0.003 + RANDOM.method_43058() * 0.008,
                (RANDOM.method_43058() - 0.5) * 0.012
        );
    }

    private static void spawnAsh(
            class_638 world,
            class_2338 pos
    ) {

        double x = randomX(pos, 20.0);
        double y = randomY(pos);
        double z = randomZ(pos, 20.0);

        world.method_8406(
                class_2398.field_22247,
                x,
                y,
                z,
                (RANDOM.method_43058() - 0.5) * 0.012,
                -0.003 - RANDOM.method_43058() * 0.008,
                (RANDOM.method_43058() - 0.5) * 0.012
        );
    }

    private static void spawnGlow(
            class_638 world,
            class_2338 pos
    ) {

        double x = randomX(pos, 16.0);
        double y = randomY(pos);
        double z = randomZ(pos, 16.0);

        world.method_8406(
                class_2398.field_11207,
                x,
                y,
                z,
                (RANDOM.method_43058() - 0.5) * 0.003,
                0.002,
                (RANDOM.method_43058() - 0.5) * 0.003
        );
    }

    private static void spawnSpore(
            class_638 world,
            class_2338 pos
    ) {

        double x = randomX(pos, 18.0);
        double y = randomY(pos);
        double z = randomZ(pos, 18.0);

        world.method_8406(
                class_2398.field_28803,
                x,
                y,
                z,
                (RANDOM.method_43058() - 0.5) * 0.004,
                0.001 + RANDOM.method_43058() * 0.003,
                (RANDOM.method_43058() - 0.5) * 0.004
        );
    }
}