package com.therootsofancientmagic.client;

import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_2561;

public class ModTooltips {

    public static void register() {
        // ОСТАВЛЯЕМ ТОЛЬКО ОДИН УНИВЕРСАЛЬНЫЙ ИВЕНТ
        ItemTooltipCallback.EVENT.register((stack, context, lines) -> {
            
            // Получаем стандартный ключ перевода предмета или блока (например, "item.mod.fire_staff")
            String baseKey = stack.method_7909().method_7876();
            String descriptionKey = baseKey + ".description";

            // Проверяем, существует ли для него описание в файле en_us.json
            if (net.minecraft.class_1074.method_4663(descriptionKey)) {
                // Получаем сырую строку из файла локализации
                String fullDescription = net.minecraft.class_1074.method_4662(descriptionKey);
                
                // ЖЕСТКО РАЗДЕЛЯЕМ её по символу переноса строки \n
                String[] splitLines = fullDescription.split("\n");
                
                // Добавляем каждую строчку отдельно, что гарантирует работу переносов
                for (String line : splitLines) {
                    lines.add(class_2561.method_43470(line));
                }
            }
        });
    }
}
