package com.therootsofancientmagic.item.magic.staff;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1295;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;

public class LightStaff extends class_1792 {

    private static final int MANA_COST = 6;
    private static final int COOLDOWN_TICKS = 1200;
    private static final double MAX_DISTANCE = 50.0;
    private static final float CLOUD_RADIUS = 2.5F;

    public LightStaff(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(
            class_1937 world,
            class_1657 player,
            class_1268 hand) {

        class_1799 stack = player.method_5998(hand);

        // Кулдаун
        if (player.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }

        // Только серверная сторона
        if (!world.field_9236 && player instanceof class_3222 serverPlayer) {

            // Тратим ману
            if (!PlayerMana.consumeMana(
                    (IEntityDataSaver) serverPlayer,
                    MANA_COST,
                    serverPlayer)) {

                return class_1271.method_22431(stack);
            }

            class_3218 serverWorld = serverPlayer.method_51469();

            // Запоминаем точную точку СТАРТА перед телепортом
            class_243 startPos = serverPlayer.method_19538();

            // Откуда начинаем смотреть
            class_243 start = serverPlayer.method_5836(1.0F);

            // Направление взгляда
            class_243 direction = serverPlayer.method_5828(1.0F);

            // Максимальная точка — 50 блоков
            class_243 end = start.method_1031(
                    direction.field_1352 * MAX_DISTANCE,
                    direction.field_1351 * MAX_DISTANCE,
                    direction.field_1350 * MAX_DISTANCE
            );

            // Проверяем, во что смотрит игрок
            class_239 hit = world.method_17742(new class_3959(
                    start,
                    end,
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    serverPlayer
            ));

            class_243 teleportPos;

            if (hit.method_17783() == class_239.class_240.field_1332) {
                // Если смотрим в блок — телепортируемся прямо перед ним
                teleportPos = hit.method_17784().method_1023(
                        direction.field_1352,
                        direction.field_1351,
                        direction.field_1350
                );
            } else {
                // Если блоков нет — телепортируемся на полную дальность
                teleportPos = end;
            }

            // 1. Спавним ЖЕЛТОЕ облако дыхания дракона на месте СТАРТА
            spawnLightBreathCloud(serverWorld, startPos, serverPlayer);
            
            // Звук исчезновения на старте
            serverWorld.method_43128(
                    null,
                    startPos.field_1352, startPos.field_1351, startPos.field_1350,
                    class_3417.field_14879,
                    class_3419.field_15248,
                    1.0F,
                    1.0F
            );

            // 2. Сама телепортация
            serverPlayer.method_14251(
                    serverWorld,
                    teleportPos.field_1352,
                    teleportPos.field_1351,
                    teleportPos.field_1350,
                    serverPlayer.method_36454(),
                    serverPlayer.method_36455()
            );

            // 3. Спавним ЖЕЛТОЕ облако дыхания дракона на месте ФИНИША
            spawnLightBreathCloud(serverWorld, teleportPos, serverPlayer);
            
            // Дополнительные светящиеся искры вспышки света в точке прибытия
            serverWorld.method_14199(
                    class_2398.field_11213,
                    teleportPos.field_1352,
                    teleportPos.field_1351 + 1.0,
                    teleportPos.field_1350,
                    50,
                    0.5, 0.5, 0.5,
                    0.1
            );

            // Звук прибытия (исправленный аметистовый звон)
            serverWorld.method_43128(
                    null,
                    teleportPos.field_1352, teleportPos.field_1351, teleportPos.field_1350,
                    class_3417.field_26980,
                    class_3419.field_15248,
                    1.2F,
                    1.3F
            );

            // Кулдаун
            serverPlayer.method_7357().method_7906(
                    this,
                    COOLDOWN_TICKS
            );
        }

        return class_1271.method_29237(
                stack,
                world.field_9236
        );
    }

    /**
     * Создает желтое магическое облако дыхания дракона.
     */
    private void spawnLightBreathCloud(class_3218 world, class_243 pos, class_1657 user) {
        class_1295 cloud = new class_1295(world, pos.field_1352, pos.field_1351, pos.field_1350);
        
        cloud.method_5607(user);
        cloud.method_5608(class_2398.field_11226); // Окрашиваемый тип частиц
        cloud.method_5603(CLOUD_RADIUS);
        cloud.method_5609(-0.1F);
        cloud.method_5595(0);
        cloud.method_5604(80); // Облако висит 4 секунды
        cloud.method_5596(-0.02F);
        
        // Цвет: Ярко-желтый золотистый (0xFFD700)
        cloud.method_5602(0xFFD700); 
        
        // Накладывает эффект Свечения (Glowing) на всех, кто попал в облако
        cloud.method_5610(new class_1293(class_1294.field_5912, 100, 0));

        world.method_8649(cloud);
    }
}
