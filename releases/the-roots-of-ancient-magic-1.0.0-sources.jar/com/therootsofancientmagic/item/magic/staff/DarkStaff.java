package com.therootsofancientmagic.item.magic.staff;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1295;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class DarkStaff extends class_1792 {

    private static final int COOLDOWN_TICKS = 1200;
    private static final double WAVE_RADIUS = 5.0;
    private static final double KNOCKBACK_STRENGTH = 10.0;
    private static final int EFFECT_DURATION = 400;

    private static final Random RANDOM = new Random();

    public DarkStaff(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (user.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }

        if (!world.field_9236 && user instanceof class_3222 serverPlayer) {

            if (!PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, 60, serverPlayer)) {
                return class_1271.method_22431(stack);
            }

            knockbackNearbyEntities(world, user);

            class_3218 serverWorld = (class_3218) world;

            // МНОГО ФИОЛЕТОВЫХ ЧАСТИЦ
            spawnDarkParticles(serverWorld, user.method_19538());

            // НЕВИДИМОСТЬ
            user.method_6092(new class_1293(
                    class_1294.field_5905,
                    EFFECT_DURATION,
                    0,
                    false,
                    false,
                    true
            ));

            // СКОРОСТЬ
            user.method_6092(new class_1293(
                    class_1294.field_5904,
                    EFFECT_DURATION,
                    1,
                    false,
                    false,
                    true
            ));

            // СПАВН ОБЛАКА ДЫХАНИЯ ДРАКОНА
            spawnDragonBreathCloud(serverWorld, user);

            playSoundBarrage(world, user);

            user.method_7357().method_7906(this, COOLDOWN_TICKS);
        }

        return class_1271.method_29237(stack, world.field_9236);
    }

    /**
     * Создает спавнящееся облако Дыхания Дракона, наносящее урон.
     */
    private void spawnDragonBreathCloud(class_3218 world, class_1657 user) {
        class_1295 cloud = new class_1295(world, user.method_23317(), user.method_23318(), user.method_23321());
        
        cloud.method_5607(user);
        cloud.method_5608(class_2398.field_11216);
        cloud.method_5603((float) WAVE_RADIUS);
        cloud.method_5609(-0.5F);
        cloud.method_5595(0);
        cloud.method_5604(100); // Облако висит 5 секунд (100 тиков)
        cloud.method_5596(-0.05F); // Постепенно сужается
        
        // Накладывает Иссушение II на врагов внутри облака
        cloud.method_5610(new class_1293(class_1294.field_5920, 100, 1)); 

        world.method_8649(cloud);
    }

    /**
     * Много фиолетовых частиц вокруг игрока.
     */
    private void spawnDarkParticles(class_3218 world, class_243 center) {

        // Фиолетовые частицы WITCH
        world.method_14199(
                class_2398.field_11249,
                center.field_1352,
                center.field_1351 + 1.0,
                center.field_1350,
                300,
                2.5,
                1.5,
                2.5,
                0.15
        );

        // Фиолетовые частицы портала
        world.method_14199(
                class_2398.field_11214,
                center.field_1352,
                center.field_1351 + 1.0,
                center.field_1350,
                300,
                3.0,
                2.0,
                3.0,
                0.5
        );

        // Тёмное фиолетовое облако
        world.method_14199(
                class_2398.field_11216,
                center.field_1352,
                center.field_1351 + 1.0,
                center.field_1350,
                200,
                2.5,
                1.5,
                2.5,
                0.08
        );

        // Ещё фиолетовые частицы вокруг ног
        world.method_14199(
                class_2398.field_11214,
                center.field_1352,
                center.field_1351 + 0.2,
                center.field_1350,
                150,
                2.5,
                0.2,
                2.5,
                0.3
        );

        // Столб частиц вверх
        for (int i = 0; i < 50; i++) {

            double x = center.field_1352 + (RANDOM.nextDouble() - 0.5) * 2.0;
            double y = center.field_1351 + RANDOM.nextDouble() * 3.0;
            double z = center.field_1350 + (RANDOM.nextDouble() - 0.5) * 2.0;

            world.method_14199(
                    class_2398.field_11249,
                    x,
                    y,
                    z,
                    2,
                    0.1,
                    0.1,
                    0.1,
                    0.05
            );
        }
    }

    /**
     * Отбрасывает существ вокруг игрока.
     */
    private void knockbackNearbyEntities(class_1937 world, class_1657 user) {

        class_238 box = user.method_5829().method_1014(WAVE_RADIUS);

        List<class_1309> entities =
                world.method_8390(
                        class_1309.class,
                        box,
                        e -> e != user
                );

        for (class_1309 entity : entities) {

            double dx = entity.method_23317() - user.method_23317();
            double dz = entity.method_23321() - user.method_23321();

            double distance =
                    Math.max(Math.sqrt(dx * dx + dz * dz), 0.1);

            dx /= distance;
            dz /= distance;

            entity.method_6005(
                    KNOCKBACK_STRENGTH,
                    -dx,
                    -dz
            );

            class_243 velocity = entity.method_18798();

            entity.method_18800(
                    velocity.field_1352,
                    0.5,
                    velocity.field_1350
                );

            entity.field_6037 = true;
        }
    }

    /**
     * Звуки.
     */
    private void playSoundBarrage(class_1937 world, class_1657 user) {

        var pos = user.method_24515();

        world.method_8396(
                null,
                pos,
                class_3417.field_14588,
                class_3419.field_15248,
                1.0F,
                0.6F
        );

        world.method_8396(
                null,
                pos,
                class_3417.field_14879,
                class_3419.field_15248,
                0.8F,
                0.5F
        );

        world.method_8396(
                null,
                pos,
                class_3417.field_15152,
                class_3419.field_15248,
                0.7F,
                1.6F
        );

        world.method_8396(
                null,
                pos,
                class_3417.field_14671,
                class_3419.field_15248,
                0.4F,
                1.8F
        );

        world.method_8396(
                null,
                pos,
                class_3417.field_23060,
                class_3419.field_15248,
                0.6F,
                0.5F
        );

        world.method_8396(
                null,
                pos,
                class_3417.field_15203,
                class_3419.field_15248,
                0.5F,
                1.4F
        );
    }
}
