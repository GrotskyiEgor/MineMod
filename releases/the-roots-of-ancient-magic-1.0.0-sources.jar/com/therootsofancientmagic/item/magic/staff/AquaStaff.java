package com.therootsofancientmagic.item.magic.staff;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1295;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AquaStaff extends class_1792 {
	private static final int COOLDOWN_TICKS = 900;
	private static final int SPHERE_RADIUS = 2;
	private static final double RAY_RANGE = 20.0D;
	private static final int DEBRIS_COUNT = 150;
	private static final double KNOCKBACK_STRENGTH = 10.0;

	private static final Random RANDOM = new Random();

	public AquaStaff(class_1793 settings) {
		super(settings);
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
		class_1799 stack = user.method_5998(hand);

		if (user.method_7357().method_7904(this)) {
			return class_1271.method_22431(stack);
		}

		if (!world.field_9236 && user instanceof class_3222 serverPlayer) {
			if (!PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, 50, serverPlayer)) {
				return class_1271.method_22431(stack);
			}

			class_2338 bottomPos = getTargetPoint(world, user);
			class_2338 centerPos = bottomPos.method_10086(SPHERE_RADIUS);

			// Создаем купол воды или льда (в зависимости от твоей задумки, тут изначальный вызов сферы)
			createWaterSphere(world, centerPos);
			
			class_3218 serverWorld = (class_3218) world;
			
			// Эффекты водяного взрыва и расталкивание мобов
			knockbackNearbyEntities(serverWorld, centerPos, user);
			spawnImpactEffects(serverWorld, centerPos);
			
			// Спавн СИНЕГО водяного дыхания прямо внутри купола
			spawnAquaBreathCloud(serverWorld, centerPos, user);

			world.method_8396(null, user.method_24515(), class_3417.field_15237, class_3419.field_15248, 1.0F, 1.0F);
			user.method_7357().method_7906(this, COOLDOWN_TICKS);
		}

		return class_1271.method_29237(stack, world.field_9236);
	}

	private void createWaterSphere(class_1937 world, class_2338 centerPos) {
		for (int x = -SPHERE_RADIUS; x <= SPHERE_RADIUS; x++) {
			for (int y = -SPHERE_RADIUS - 1; y <= SPHERE_RADIUS; y++) {
				for (int z = -SPHERE_RADIUS; z <= SPHERE_RADIUS; z++) {
					double distance = Math.sqrt(x * x + y * y + z * z);
					if (distance < SPHERE_RADIUS - 0.5D || distance > SPHERE_RADIUS + 0.5D) {
						continue;
					}
					if (isSecondLayerOpening(x, y, z)) {
						continue;
					}

					class_2338 blockPos = centerPos.method_10069(x, y, z);
					if (world.method_8320(blockPos).method_45474()) {
						// Здесь можно ставить блоки льда или синего стекла (вместо STONE)
						world.method_8501(blockPos, class_2246.field_10295.method_9564());
					}
				}
			}
		}
	}

	private boolean isSecondLayerOpening(int x, int y, int z) {
		return y == 0 && ((Math.abs(x) == SPHERE_RADIUS && z == 0) || (Math.abs(z) == SPHERE_RADIUS && x == 0));
	}

	/**
	 * Создает синее бурлящее водяное облако на месте купола.
	 */
	private void spawnAquaBreathCloud(class_3218 world, class_2338 centerPos, class_1657 user) {
		class_1295 cloud = new class_1295(world, centerPos.method_10263() + 0.5, centerPos.method_10264(), centerPos.method_10260() + 0.5);
		
		cloud.method_5607(user);
		cloud.method_5608(class_2398.field_11226); // Идеальный тип для кастомного цвета
		cloud.method_5603((float) SPHERE_RADIUS + 0.5F);
		cloud.method_5609(-0.2F);
		cloud.method_5595(0);
		cloud.method_5604(120); // Водяной туман висит 6 секунд
		cloud.method_5596(-0.02F);
		
		// Цвет: Насыщенный магический синий (0x0066FF)
		cloud.method_5602(0x0066FF); 
		
		// Эффекты: Сильное замедление (тяжело двигаться в воде) и урон от удушья (Иссушение)
		cloud.method_5610(new class_1293(class_1294.field_5909, 100, 2));
		cloud.method_5610(new class_1293(class_1294.field_5920, 100, 1)); 

		world.method_8649(cloud);
	}

	/**
	 * Водяные брызги и капли разлетаются взрывом от центра купола.
	 */
	private void spawnImpactEffects(class_3218 world, class_2338 centerPos) {
		class_243 center = class_243.method_24953(centerPos);
		
		// Частицы брызг и капель воды
		sphereBurst(world, center, DEBRIS_COUNT, class_2398.field_11202, 0.4);
		sphereBurst(world, center, 80, class_2398.field_18306, 0.3);
		sphereBurst(world, center, DEBRIS_COUNT / 2, class_2398.field_11204, 0.15);
		groundRing(world, center, SPHERE_RADIUS + 1.5, 40);

		world.method_8396(null, centerPos, class_3417.field_14810, class_3419.field_15248, 1.2F, 0.7F);
		world.method_8396(null, centerPos, class_3417.field_14737, class_3419.field_15248, 1.0F, 1.2F);
	}

	/**
	 * Отбрасывает существ мощной волной от центра купола.
	 */
	private void knockbackNearbyEntities(class_3218 world, class_2338 centerPos, class_1657 user) {
		class_238 box = new class_238(centerPos).method_1014(SPHERE_RADIUS + 1.0);
		List<class_1309> entities = world.method_8390(class_1309.class, box, e -> e != user);

		for (class_1309 entity : entities) {
			double dx = entity.method_23317() - (centerPos.method_10263() + 0.5);
			double dz = entity.method_23321() - (centerPos.method_10260() + 0.5);
			double distance = Math.max(Math.sqrt(dx * dx + dz * dz), 0.1);

			dx /= distance;
			dz /= distance;

			entity.method_6005(KNOCKBACK_STRENGTH, -dx, -dz);
			class_243 velocity = entity.method_18798();
			entity.method_18800(velocity.field_1352, 0.4, velocity.field_1350);
			entity.field_6037 = true;
		}
	}

	/** Разлёт частиц равномерно по сфере. */
	private void sphereBurst(class_3218 world, class_243 origin, int count, class_2394 particle, double maxSpeed) {
		for (int i = 0; i < count; i++) {
			double u = RANDOM.nextDouble() * 2.0 - 1.0;
			double theta = RANDOM.nextDouble() * Math.PI * 2.0;
			double sqrtTerm = Math.sqrt(1.0 - u * u);

			double dirX = sqrtTerm * Math.cos(theta);
			double dirY = u;
			double dirZ = sqrtTerm * Math.sin(theta);
			double speed = RANDOM.nextDouble() * maxSpeed;

			world.method_14199(particle, origin.field_1352, origin.field_1351, origin.field_1350, 1, dirX * speed, dirY * speed, dirZ * speed, 1.0);
		}
	}

	/** Кольцо брызг на земле вокруг купола. */
	private void groundRing(class_3218 world, class_243 center, double radius, int count) {
		for (int i = 0; i < count; i++) {
			double angle = (Math.PI * 2.0 * i) / count;
			double dirX = Math.cos(angle);
			double dirZ = Math.sin(angle);

			double x = center.field_1352 + dirX * radius;
			double z = center.field_1350 + dirZ * radius;

			world.method_14199(class_2398.field_11244, x, center.field_1351 - SPHERE_RADIUS, z, 1, dirX * 0.05, 0.05, dirZ * 0.05, 0.0);
		}
	}

	private class_2338 getTargetPoint(class_1937 world, class_1657 player) {
		class_243 start = player.method_5836(1.0F);
		class_243 end = start.method_1019(player.method_5828(1.0F).method_1021(RAY_RANGE));
		class_3965 hitResult = world.method_17742(new class_3959(
				start,
				end,
				class_3959.class_3960.field_17559,
				class_3959.class_242.field_1348,
				player
		));

		if (hitResult.method_17783() == class_239.class_240.field_1332) {
			return class_2338.method_49638(hitResult.method_17784());
		}

		return class_2338.method_49638(end);
	}
}
