package com.therootsofancientmagic.item.magic.staff;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AirStaff extends class_1792 {

    // Радиус, в котором притягиваются сущности
    private static final double PULL_RADIUS = 3.0D;
    // Дальность луча (как далеко смотрит игрок)
    private static final double RAY_RANGE = 20.0D;
    // Скорость подброса вверх
    private static final double LAUNCH_VELOCITY_Y = 1.8D;
    // Сила притяжения к центральной точке
    private static final double PULL_STRENGTH = 0.6D;

    public AirStaff(class_1793 settings) {
        super(settings);
    }

@Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        // Проверка кулдауна
        if (user.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }

        if (!world.field_9236) {
            if (user instanceof class_3222 serverPlayer) {
                
                if (PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, 40, serverPlayer)) {
                    
                    class_243 targetPoint = getTargetPoint(world, user);

                    class_238 searchBox = new class_238(
                            targetPoint.field_1352 - PULL_RADIUS, targetPoint.field_1351 - PULL_RADIUS, targetPoint.field_1350 - PULL_RADIUS,
                            targetPoint.field_1352 + PULL_RADIUS, targetPoint.field_1351 + PULL_RADIUS, targetPoint.field_1350 + PULL_RADIUS
                    );

                        List<class_1297> entities = world.method_8333(user, searchBox,
                            entity -> entity.method_5707(targetPoint) > 0.0001D);

                        for (class_1297 entity : entities) {
                        class_243 toCenter = targetPoint.method_1020(entity.method_19538());
                        class_243 pullVec = toCenter.method_1029().method_1021(PULL_STRENGTH);

                        class_243 newVelocity = entity.method_18798()
                            .method_1031(pullVec.field_1352, pullVec.field_1351, pullVec.field_1350)
                            .method_1031(0, LAUNCH_VELOCITY_Y, 0);

                        entity.method_18799(newVelocity);
                        entity.field_6037 = true;
                        entity.field_6017 = 0.0F;
                        }

                    world.method_8396(null, user.method_24515(), class_3417.field_14545,
                            class_3419.field_15248, 1.0F, 1.0F);
                    world.method_8396(null, user.method_24515(), class_3417.field_14869,
                            class_3419.field_15248, 1.2F, 0.6F);
                    world.method_8396(null, user.method_24515(), class_3417.field_14606,
                            class_3419.field_15248, 1.0F, 1.4F);

                    if (world instanceof class_3218 serverWorld) {
                        spawnVortexParticles(serverWorld, targetPoint);
                        spawnGustBurst(serverWorld, targetPoint);

                        serverWorld.method_14199(class_2398.field_11221,
                                targetPoint.field_1352, targetPoint.field_1351, targetPoint.field_1350,
                                1, 0.2, 0.2, 0.2, 0.0);
                    }

                    user.method_7357().method_7906(this, 900);

                } else {

                    return class_1271.method_22431(stack);
                }
            }
        }
         return class_1271.method_29237(stack, world.field_9236);
    }

    /** Вихрь из частиц, закручивающийся к центральной точке — визуализация притяжения. */
    private void spawnVortexParticles(class_3218 world, class_243 center) {
        int arms = 30;
        for (int i = 0; i < arms; i++) {
            double angle = (Math.PI * 2.0 * i) / arms;
            double radius = PULL_RADIUS;

            double x = center.field_1352 + Math.cos(angle) * radius;
            double z = center.field_1350 + Math.sin(angle) * radius;
            double y = center.field_1351 + (Math.random() - 0.5) * PULL_RADIUS;

            class_243 toCenter = center.method_1023(x, y, z).method_1029().method_1021(0.15);
            world.method_14199(class_2398.field_11204, x, y, z, 0, toCenter.field_1352, toCenter.field_1351, toCenter.field_1350, 0.02);
            world.method_14199(class_2398.field_11207, x, y, z, 0, toCenter.field_1352, toCenter.field_1351, toCenter.field_1350, 0.01);
        }
    }

    /** Всплеск воздушных частиц вверх в момент подброса сущностей. */
    private void spawnGustBurst(class_3218 world, class_243 center) {
        world.method_14199(class_2398.field_11204, center.field_1352, center.field_1351, center.field_1350, 25, 0.6, 0.2, 0.6, 0.08);
        world.method_14199(class_2398.field_11227, center.field_1352, center.field_1351 + 0.3, center.field_1350, 3, 0.3, 0.1, 0.3, 0.0);
        world.method_14199(class_2398.field_11205, center.field_1352, center.field_1351, center.field_1350, 20, 0.8, 0.4, 0.8, 0.15);
    }

    private class_243 getTargetPoint(class_1937 world, class_1657 player) {
        class_243 start = player.method_5836(1.0F);
        class_243 look = player.method_5828(1.0F);
        class_243 end = start.method_1019(look.method_1021(RAY_RANGE));

        class_3965 hitResult = world.method_17742(new class_3959(
                start, end,
                class_3959.class_3960.field_17559,
                class_3959.class_242.field_1348,
                player
        ));

        if (hitResult.method_17783() == class_239.class_240.field_1332) {
            return hitResult.method_17784();
        }

        return end;
    }
}