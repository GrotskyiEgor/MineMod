package com.therootsofancientmagic.item.magic.staff;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1674;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class FireStaff extends class_1792 {
    private static final int COOLDOWN_TICKS = 900;

    private static final Random RANDOM = new Random();

    public FireStaff(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        // Проверка кулдауна
        if (user.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }

        if (!world.field_9236) {
            // Принудительно кастим игрока к серверному типу для работи с пакетами мани
            if (user instanceof class_3222 serverPlayer) {
                
                // ВЫЗЫВАЕМ СПИСАНИЕ МАНЫ: Тратим ровно 10 единиц (1 кружочек на худ-баре)
                if (PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, 40, serverPlayer)) {
                    
                    // МАНЫ ХВАТИЛО: Спавним огненний шар и запускаем звук
                    castSpell(world, user);

                    world.method_8396(
                            null,
                            user.method_24515(),
                            class_3417.field_14970,
                            class_3419.field_15248,
                            1.0F,
                            1.0F
                    );
                    world.method_8396(
                            null,
                            user.method_24515(),
                            class_3417.field_15013,
                            class_3419.field_15248,
                            1.2F,
                            0.8F
                    );
                    world.method_8396(
                            null,
                            user.method_24515(),
                            class_3417.field_15231,
                            class_3419.field_15248,
                            0.6F,
                            1.5F
                    );

                    // Устанавливаем кулдаун ТОЛЬКО если посох успешно вистрелил заклинанием
                    user.method_7357().method_7906(this, COOLDOWN_TICKS);

                } else {
                    // МАНЫ НЕ ХВАТИЛО: Заклинание полностью блокируется, посох выдает осечку
                    return class_1271.method_22431(stack);
                }
            }
        }

        return class_1271.method_29237(stack, world.field_9236);
    }

    private void castSpell(class_1937 world, class_1657 user) {
        // Направление взгляда игрока
        var lookVec = user.method_5828(1.0F);

        class_1674 fireball = new class_1674(
                world,
                user,
                lookVec.field_1352 * 0.3,
                lookVec.field_1351 * 0.3,
                lookVec.field_1350 * 0.3,
                3 // сила взрыва
        );

        class_243 spawnPos = new class_243(
                user.method_23317() + lookVec.field_1352,
                user.method_23320() - 0.1,
                user.method_23321() + lookVec.field_1350
        );

        fireball.method_23327(spawnPos.field_1352, spawnPos.field_1351, spawnPos.field_1350);
        world.method_8649(fireball);

        spawnMuzzleEffects(world, spawnPos, lookVec);
    }

    /** Огненный "хлопок" частиц и дымный шлейф в точке вылета шара. */
    private void spawnMuzzleEffects(class_1937 world, class_243 origin, class_243 direction) {
        sphereBurst(world, origin, 40, class_2398.field_11240, 0.35);
        sphereBurst(world, origin, 15, class_2398.field_11239, 0.2);
        sphereBurst(world, origin, 25, class_2398.field_11237, 0.15);

        for (int i = 1; i <= 8; i++) {
            class_243 point = origin.method_1019(direction.method_1021(i * 0.4));
            world.method_8406(class_2398.field_11251, point.field_1352, point.field_1351, point.field_1350, 0, 0.02, 0);
        }
    }

    /** Разлёт count частиц равномерно по сфере из одной точки. */
    private void sphereBurst(class_1937 world, class_243 origin, int count, class_2394 particle, double maxSpeed) {
        for (int i = 0; i < count; i++) {
            double u = RANDOM.nextDouble() * 2.0 - 1.0;
            double theta = RANDOM.nextDouble() * Math.PI * 2.0;
            double sqrtTerm = Math.sqrt(1.0 - u * u);

            double dirX = sqrtTerm * Math.cos(theta);
            double dirY = u;
            double dirZ = sqrtTerm * Math.sin(theta);
            double speed = RANDOM.nextDouble() * maxSpeed;

            world.method_8406(particle, origin.field_1352, origin.field_1351, origin.field_1350, dirX * speed, dirY * speed, dirZ * speed);
        }
    }
}