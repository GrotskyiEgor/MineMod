package com.therootsofancientmagic.item.magic.robe;

import net.minecraft.class_1792;

public class ElementalRobeItem extends class_1792 {
    public ElementalRobeItem(class_1793 settings) {
        super(settings);
    }
}