package com.therootsofancientmagic.item.magic.ring;

import java.util.UUID;
import net.minecraft.class_1792;

public class RingItem extends class_1792 {
    public static final UUID RING_1_MODIFIER_ID = UUID.fromString("a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d");
    public static final UUID RING_2_MODIFIER_ID = UUID.fromString("f1e2d3c4-b5a6-9f8e-7d6c-5b4a3f2e1d0c");

    public RingItem(class_1793 settings) {
        super(settings);
    }
}