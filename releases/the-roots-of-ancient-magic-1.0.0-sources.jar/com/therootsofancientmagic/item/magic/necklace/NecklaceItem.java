package com.therootsofancientmagic.item.magic.necklace;

import net.minecraft.class_1792;

public class NecklaceItem extends class_1792 {

    public NecklaceItem(class_1793 settings) {
        super(settings);
    }
}