package com.therootsofancientmagic.item;

import java.util.function.Supplier;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public enum ModToolMaturial implements class_1832 {
    // Железо
    ESSENCE_AQUA(2, 250, 6.0f, 2.0f, 14, () -> class_1856.method_8091(class_7923.field_41178.method_10223(new class_2960("the-roots-of-ancient-magic", "ESSENCE_AQUA")))),
    ESSENCE_AIR(2, 250, 6.0f, 2.0f, 14, () -> class_1856.method_8091(class_7923.field_41178.method_10223(new class_2960("the-roots-of-ancient-magic", "ESSENCE_AIR")))),
    // Алмазы
    ESSENCE_FIRE(3, 1561, 8.0f, 3.0f, 10, () -> class_1856.method_8091(class_7923.field_41178.method_10223(new class_2960("the-roots-of-ancient-magic", "ESSENCE_FIRE")))),
    ESSENCE_EARTH(3, 1561, 8.0f, 3.0f, 10, () -> class_1856.method_8091(class_7923.field_41178.method_10223(new class_2960("the-roots-of-ancient-magic", "ESSENCE_EARTH")))),
    // Незеритовые
    ESSENCE_DARK(4, 2031, 9.0f, 4.0f, 15, () -> class_1856.method_8091(class_7923.field_41178.method_10223(new class_2960("the-roots-of-ancient-magic", "ESSENCE_DARK")))),
    ESSENCE_LIGHT(4, 2031, 9.0f, 4.50f, 15, () -> class_1856.method_8091(class_7923.field_41178.method_10223(new class_2960("the-roots-of-ancient-magic", "ESSENCE_LIGHT")))),
    // Чуть лучше Незеритовых
    ESSENCE_HEROIC(4, 2400, 10.0f, 5f, 30, () -> class_1856.method_8091(class_7923.field_41178.method_10223(new class_2960("the-roots-of-ancient-magic", "HEROIC_ESSENCE"))));

    private final int miningLevel;
    private final int itemDurability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final Supplier<class_1856> repairIngredient;

    ModToolMaturial(int miningLevel, int itemDurability, float miningSpeed, float attackDamage, int enchantability, Supplier<class_1856> repairIngredient) {
        this.miningLevel = miningLevel;
        this.itemDurability = itemDurability;
        this.miningSpeed = miningSpeed;
        this.attackDamage = attackDamage;
        this.enchantability = enchantability;
        this.repairIngredient = repairIngredient;
    }

    @Override public int method_8025() { return this.itemDurability; }
    @Override public float method_8027() { return this.miningSpeed; }
    @Override public float method_8028() { return this.attackDamage; }
    @Override public int method_8024() { return this.miningLevel; }
    @Override public int method_8026() { return this.enchantability; }
    @Override public class_1856 method_8023() { return this.repairIngredient.get(); }
}