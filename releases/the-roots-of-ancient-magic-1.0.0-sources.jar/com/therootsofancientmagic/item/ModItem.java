package com.therootsofancientmagic.item;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import com.therootsofancientmagic.item.tools.sword.ElementalSwordItem;
import com.therootsofancientmagic.item.tools.axe.ElementalAxeItem;
import com.therootsofancientmagic.item.tools.pickaxe.ElementalPickaxeItem;
import com.therootsofancientmagic.item.tools.shovel.ElementalShovelItem;
import com.therootsofancientmagic.item.tools.hoe.ElementalHoeItem;
import com.therootsofancientmagic.item.magic.necklace.NecklaceItem;
import com.therootsofancientmagic.item.magic.ring.RingItem;
import com.therootsofancientmagic.item.magic.robe.ElementalRobeItem;
import com.therootsofancientmagic.item.magic.staff.AquaStaff;
import com.therootsofancientmagic.item.magic.staff.EarthStaff;
import com.therootsofancientmagic.item.magic.staff.FireStaff;
import com.therootsofancientmagic.item.magic.staff.AirStaff;
import com.therootsofancientmagic.item.magic.staff.LightStaff;
import com.therootsofancientmagic.item.magic.staff.DarkStaff;
import com.therootsofancientmagic.item.tools.heroic_tools.HeroicAxeItem;
import com.therootsofancientmagic.item.tools.heroic_tools.HeroicSwordItem;
import com.therootsofancientmagic.item.tools.heroic_tools.HeroicPickaxeItem;
import com.therootsofancientmagic.item.tools.heroic_tools.HeroicShovelItem;
import com.therootsofancientmagic.item.tools.heroic_tools.HeroicStaff;
import com.therootsofancientmagic.item.tools.heroic_tools.HeroicHoeItem;
import com.therootsofancientmagic.item.tools.unique_tools.BattleAxeItem;
import com.therootsofancientmagic.item.tools.unique_tools.LightningHammerItem;
import com.therootsofancientmagic.item.tools.unique_tools.NecromancerScytheItem;

public class ModItem {    
    public static final class_1792 FIRE_HELMET = registerItem(
        "fire_helmet", 
        new class_1738(
            ModArmorMaterial.ESSENCE_FIRE, 
            class_1738.class_8051.field_41934,
            new class_1792.class_1793()
        )
    );
    
    public static final class_1792 FIRE_CHESTPLATE = registerItem(
        "fire_chestplate", 
        new class_1738(
            ModArmorMaterial.ESSENCE_FIRE, 
            class_1738.class_8051.field_41935,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 FIRE_LEGGINGS= registerItem(
        "fire_leggings", 
        new class_1738(
            ModArmorMaterial.ESSENCE_FIRE, 
            class_1738.class_8051.field_41936,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 FIRE_BOOTS = registerItem(
        "fire_boots", 
        new class_1738(
            ModArmorMaterial.ESSENCE_FIRE, 
            class_1738.class_8051.field_41937,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 AIR_HELMET = registerItem(
        "air_helmet", 
        new class_1738(
            ModArmorMaterial.ESSENCE_AIR, 
            class_1738.class_8051.field_41934,
            new class_1792.class_1793()
        )
    );
    
    public static final class_1792 AIR_CHESTPLATE = registerItem(
        "air_chestplate", 
        new class_1738(
            ModArmorMaterial.ESSENCE_AIR, 
            class_1738.class_8051.field_41935,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 AIR_LEGGINGS= registerItem(
        "air_leggings", 
        new class_1738(
            ModArmorMaterial.ESSENCE_AIR, 
            class_1738.class_8051.field_41936,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 AIR_BOOTS = registerItem(
        "air_boots", 
        new class_1738(
            ModArmorMaterial.ESSENCE_AIR, 
            class_1738.class_8051.field_41937,
            new class_1792.class_1793()
        )
    );


    public static final class_1792 AQUA_HELMET = registerItem(
        "aqua_helmet", 
        new class_1738(
            ModArmorMaterial.ESSENCE_AQUA, 
            class_1738.class_8051.field_41934,
            new class_1792.class_1793()
        )
    );
    
    public static final class_1792 AQUA_CHESTPLATE = registerItem(
        "aqua_chestplate", 
        new class_1738(
            ModArmorMaterial.ESSENCE_AQUA, 
            class_1738.class_8051.field_41935,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 AQUA_LEGGINGS= registerItem(
        "aqua_leggings", 
        new class_1738(
            ModArmorMaterial.ESSENCE_AQUA, 
            class_1738.class_8051.field_41936,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 AQUA_BOOTS = registerItem(
        "aqua_boots", 
        new class_1738(
            ModArmorMaterial.ESSENCE_AQUA, 
            class_1738.class_8051.field_41937,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 EARTH_HELMET = registerItem(
        "earth_helmet", 
        new class_1738(
            ModArmorMaterial.ESSENCE_EARTH, 
            class_1738.class_8051.field_41934,
            new class_1792.class_1793()
        )
    );
    
    public static final class_1792 EARTH_CHESTPLATE = registerItem(
        "earth_chestplate", 
        new class_1738(
            ModArmorMaterial.ESSENCE_EARTH, 
            class_1738.class_8051.field_41935,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 EARTH_LEGGINGS= registerItem(
        "earth_leggings", 
        new class_1738(
            ModArmorMaterial.ESSENCE_EARTH, 
            class_1738.class_8051.field_41936,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 EARTH_BOOTS = registerItem(
        "earth_boots", 
        new class_1738(
            ModArmorMaterial.ESSENCE_EARTH, 
            class_1738.class_8051.field_41937,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 LIGHT_HELMET = registerItem(
        "light_helmet", 
        new class_1738(
            ModArmorMaterial.ESSENCE_LIGHT, 
            class_1738.class_8051.field_41934,
            new class_1792.class_1793()
        )
    );
    
    public static final class_1792 LIGHT_CHESTPLATE = registerItem(
        "light_chestplate", 
        new class_1738(
            ModArmorMaterial.ESSENCE_LIGHT, 
            class_1738.class_8051.field_41935,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 LIGHT_LEGGINGS= registerItem(
        "light_leggings", 
        new class_1738(
            ModArmorMaterial.ESSENCE_LIGHT, 
            class_1738.class_8051.field_41936,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 LIGHT_BOOTS = registerItem(
        "light_boots", 
        new class_1738(
            ModArmorMaterial.ESSENCE_LIGHT, 
            class_1738.class_8051.field_41937,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 DARK_HELMET = registerItem(
        "dark_helmet", 
        new class_1738(
            ModArmorMaterial.ESSENCE_DARK, 
            class_1738.class_8051.field_41934,
            new class_1792.class_1793()
        )
    );
    
    public static final class_1792 DARK_CHESTPLATE = registerItem(
        "dark_chestplate", 
        new class_1738(
            ModArmorMaterial.ESSENCE_DARK, 
            class_1738.class_8051.field_41935,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 DARK_LEGGINGS= registerItem(
        "dark_leggings", 
        new class_1738(
            ModArmorMaterial.ESSENCE_DARK, 
            class_1738.class_8051.field_41936,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 DARK_BOOTS = registerItem(
        "dark_boots", 
        new class_1738(
            ModArmorMaterial.ESSENCE_DARK, 
            class_1738.class_8051.field_41937,
            new class_1792.class_1793()
        )
    );

    
    public static final class_1792 HEROIC_HELMET = registerItem(
        "heroic_helmet", 
        new class_1738(
            ModArmorMaterial.ESSENCE_HEROIC, 
            class_1738.class_8051.field_41934,
            new class_1792.class_1793()
        )
    );  
    
    public static final class_1792 HEROIC_CHESTPLATE = registerItem(
        "heroic_chestplate", 
        new class_1738(
            ModArmorMaterial.ESSENCE_HEROIC, 
            class_1738.class_8051.field_41935,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 HEROIC_LEGGINGS= registerItem(
        "heroic_leggings", 
        new class_1738(
            ModArmorMaterial.ESSENCE_HEROIC, 
            class_1738.class_8051.field_41936,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 HEROIC_BOOTS = registerItem(
        "heroic_boots", 
        new class_1738(
            ModArmorMaterial.ESSENCE_HEROIC, 
            class_1738.class_8051.field_41937,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 HEROIC_STAFF = registerItem(
        "heroic_staff",
        new HeroicStaff(new class_1792.class_1793())
    );

    public static final class_1792 FIRE_STAFF = registerItem(
        "fire_staff",
        new FireStaff(new class_1792.class_1793())
    );

    public static final class_1792 EARTH_STAFF = registerItem(
                "earth_staff",
         new EarthStaff(new class_1792.class_1793())
    );
        
    public static final class_1792 AIR_STAFF = registerItem(
        "air_staff",
        new AirStaff(new class_1792.class_1793())
    );

    public static final class_1792 AQUA_STAFF = registerItem(
        "aqua_staff",
        new AquaStaff(new class_1792.class_1793())
    );

    public static final class_1792 LIGHT_STAFF = registerItem(
        "light_staff",
        new LightStaff(new class_1792.class_1793())
    );

    public static final class_1792 DARK_STAFF = registerItem(
        "dark_staff",
        new DarkStaff(new class_1792.class_1793())
    );

    public static final class_1792 IRON_STICK = registerItem(
        "iron_stick",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 ESSENCE_AQUA = registerItem(
        "essence_aqua",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 ESSENCE_FIRE = registerItem(
        "essence_fire",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 ESSENCE_AIR = registerItem(
        "essence_air",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 ESSENCE_EARTH = registerItem(
        "essence_earth",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 ESSENCE_LIGHT = registerItem(
        "essence_light",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 ESSENCE_DARK = registerItem(
        "essence_dark",
        new class_1792(new class_1792.class_1793())
    );
    public static final class_1792 ESSENCE_HEROIC = registerItem(
        "essence_heroic",
        new class_1792(new class_1792.class_1793())    );

    public static final class_1792 FRAGMENT_AQUA = registerItem(
        "fragment_aqua",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 FRAGMENT_FIRE = registerItem(
        "fragment_fire",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 FRAGMENT_AIR = registerItem(
        "fragment_air",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 FRAGMENT_EARTH = registerItem(
        "fragment_earth",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 FRAGMENT_LIGHT = registerItem(
        "fragment_light",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 FRAGMENT_DARK = registerItem(
        "fragment_dark",
        new class_1792(new class_1792.class_1793())
    );
    public static final class_1792 FRAGMENT_HEROIC = registerItem(
        "fragment_heroic",
        new class_1792(new class_1792.class_1793())
    );
    
    public static final class_1792 BATTLE_AXE = registerItem("battle_axe",
            new BattleAxeItem(ModToolMaturial.ESSENCE_HEROIC, 7, -3.4f, new class_1792.class_1793()));

    public static final class_1792 LIGHTNING_HAMMER = registerItem("lightning_hammer",
        new LightningHammerItem(ModToolMaturial.ESSENCE_HEROIC, 7, -3.0f, new class_1792.class_1793()));
        
    public static final class_1792 NECROMANCER_SCYTHE = registerItem("necromancer_scythe",
        new NecromancerScytheItem(ModToolMaturial.ESSENCE_HEROIC, 7, -2.4f, new class_1792.class_1793()));


    public static final class_1792 AQUA_NECKLACE = registerItem("aqua_necklace",
        new NecklaceItem(new FabricItemSettings().method_7889(1)));

    public static final class_1792 FIRE_NECKLACE = registerItem("fire_necklace",
        new NecklaceItem(new FabricItemSettings().method_7889(1)));

    public static final class_1792 AIR_NECKLACE = registerItem("air_necklace",
        new NecklaceItem(new FabricItemSettings().method_7889(1)));

    public static final class_1792 EARTH_NECKLACE = registerItem("earth_necklace",
        new NecklaceItem(new FabricItemSettings().method_7889(1)));


    public static final class_1792 FIRE_ROBE = registerItem(
        "fire_robe", 
        new ElementalRobeItem(new class_1792.class_1793().method_7889(1)));

    public static final class_1792 AIR_ROBE = registerItem(
        "air_robe", 
        new ElementalRobeItem(new class_1792.class_1793().method_7889(1)));
    
    public static final class_1792 AQUA_ROBE = registerItem(
        "aqua_robe", 
        new ElementalRobeItem(new class_1792.class_1793().method_7889(1)));
    public static final class_1792 EARTH_ROBE = registerItem(
        "earth_robe", 
        new ElementalRobeItem(new class_1792.class_1793().method_7889(1)));

        
    public static final class_1792 AQUA_RING = registerItem("aqua_ring",
        new RingItem(new FabricItemSettings().method_7889(1)));

    public static final class_1792 FIRE_RING = registerItem("fire_ring",
        new RingItem(new FabricItemSettings().method_7889(1)));

    public static final class_1792 AIR_RING = registerItem("air_ring",
        new RingItem(new FabricItemSettings().method_7889(1)));

    public static final class_1792 EARTH_RING = registerItem("earth_ring",
        new RingItem(new FabricItemSettings().method_7889(1)));


    public static final class_1792 HEROIC_PICKAXE = registerItem("heroic_pickaxe",
        new ElementalPickaxeItem(ModToolMaturial.ESSENCE_HEROIC, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 LIGHT_PICKAXE = registerItem("light_pickaxe",
            new ElementalPickaxeItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.8f, new class_1792.class_1793()));
        
    public static final class_1792 DARK_PICKAXE = registerItem("dark_pickaxe",
            new ElementalPickaxeItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.8f, new class_1792.class_1793()));
            
   
    public static final class_1792 FIRE_PICKAXE = registerItem("fire_pickaxe",
            new ElementalPickaxeItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.8f, new class_1792.class_1793()));
            
    public static final class_1792 AQUA_PICKAXE = registerItem("aqua_pickaxe",
            new ElementalPickaxeItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.8f, new class_1792.class_1793()));
            
    public static final class_1792 EARTH_PICKAXE = registerItem("earth_pickaxe",
            new ElementalPickaxeItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.8f, new class_1792.class_1793()));
            
    public static final class_1792 AIR_PICKAXE = registerItem("air_pickaxe",
            new ElementalPickaxeItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.8f, new class_1792.class_1793()));
            
    
    public static final class_1792 HEROIC_AXE = registerItem("heroic_axe",
        new ElementalAxeItem(ModToolMaturial.ESSENCE_HEROIC, 1, -3.0f, new class_1792.class_1793()));

    public static final class_1792 FIRE_AXE = registerItem("fire_axe",
            new ElementalAxeItem(ModToolMaturial.ESSENCE_FIRE, 1, -3.0f, new class_1792.class_1793()));
    
    public static final class_1792 AQUA_AXE = registerItem("aqua_axe",
            new ElementalAxeItem(ModToolMaturial.ESSENCE_AQUA, 1, -3.0f, new class_1792.class_1793()));
    
    public static final class_1792 AIR_AXE = registerItem("air_axe",
            new ElementalAxeItem(ModToolMaturial.ESSENCE_AIR, 1, -3.0f, new class_1792.class_1793()));
    
    public static final class_1792 DARK_AXE = registerItem("dark_axe",
            new ElementalAxeItem(ModToolMaturial.ESSENCE_DARK, 1, -3.0f, new class_1792.class_1793()));
    
    public static final class_1792 LIGHT_AXE = registerItem("light_axe",
            new ElementalAxeItem(ModToolMaturial.ESSENCE_LIGHT, 1, -3.0f, new class_1792.class_1793()));
         
    public static final class_1792 EARTH_AXE = registerItem("earth_axe",
            new ElementalAxeItem(ModToolMaturial.ESSENCE_EARTH, 1, -3.0f, new class_1792.class_1793()));
    
    
    // поджигает противника.
    public static final class_1792 HEROIC_SWORD = registerItem("heroic_sword",
            new ElementalSwordItem(ModToolMaturial.ESSENCE_HEROIC, 1, -2.4f, new class_1792.class_1793()));

    // поджигает противника.
    public static final class_1792 FIRE_SWORD = registerItem("fire_sword",
            new ElementalSwordItem(ModToolMaturial.ESSENCE_FIRE, 1, -2.4f, new class_1792.class_1793()));

    // замедляет противника
    public static final class_1792 AQUA_SWORD = registerItem("aqua_sword",
            new ElementalSwordItem(ModToolMaturial.ESSENCE_AQUA, 1, -2.4f, new class_1792.class_1793()));

    // отталкивает противника
    public static final class_1792 AIR_SWORD = registerItem("air_sword",
            new ElementalSwordItem(ModToolMaturial.ESSENCE_AIR, 1, -2.4f, new class_1792.class_1793()));

    // подкидивание вверх
    public static final class_1792 EARTH_SWORD = registerItem("earth_sword",
            new ElementalSwordItem(ModToolMaturial.ESSENCE_EARTH, 1, -2.4f, new class_1792.class_1793()));

    // накладивает слепоту на противника
    public static final class_1792 DARK_SWORD = registerItem("dark_sword",
            new ElementalSwordItem(ModToolMaturial.ESSENCE_DARK, 1, -2.4f, new class_1792.class_1793()));

    // ефект спектральной стрели(свечения)
    public static final class_1792 LIGHT_SWORD = registerItem("light_sword",
            new ElementalSwordItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.4f, new class_1792.class_1793()));

    
    public static final class_1792 HEROIC_SHOVEL = registerItem("heroic_shovel",
            new ElementalShovelItem(ModToolMaturial.ESSENCE_HEROIC, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 FIRE_SHOVEL = registerItem("fire_shovel",
            new ElementalShovelItem(ModToolMaturial.ESSENCE_FIRE, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 AQUA_SHOVEL = registerItem("aqua_shovel",
            new ElementalShovelItem(ModToolMaturial.ESSENCE_AQUA, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 AIR_SHOVEL = registerItem("air_shovel",
            new ElementalShovelItem(ModToolMaturial.ESSENCE_AIR, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 DARK_SHOVEL = registerItem("dark_shovel",
            new ElementalShovelItem(ModToolMaturial.ESSENCE_DARK, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 LIGHT_SHOVEL = registerItem("light_shovel",
            new ElementalShovelItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 EARTH_SHOVEL = registerItem("earth_shovel",
            new ElementalShovelItem(ModToolMaturial.ESSENCE_EARTH, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 HEROIC_HOE = registerItem("heroic_hoe",
            new ElementalHoeItem(ModToolMaturial.ESSENCE_HEROIC, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 FIRE_HOE = registerItem("fire_hoe",
            new ElementalHoeItem(ModToolMaturial.ESSENCE_FIRE, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 AQUA_HOE = registerItem("aqua_hoe",
            new ElementalHoeItem(ModToolMaturial.ESSENCE_AQUA, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 AIR_HOE = registerItem("air_hoe",
            new ElementalHoeItem(ModToolMaturial.ESSENCE_AIR, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 LIGHT_HOE = registerItem("light_hoe",
            new ElementalHoeItem(ModToolMaturial.ESSENCE_LIGHT, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 DARK_HOE = registerItem("dark_hoe",
            new ElementalHoeItem(ModToolMaturial.ESSENCE_DARK, 1, -2.8f, new class_1792.class_1793()));

    public static final class_1792 EARTH_HOE = registerItem("earth_hoe",
            new ElementalHoeItem(ModToolMaturial.ESSENCE_EARTH, 1, -2.8f, new class_1792.class_1793()));

    public static class_1792 registerItem(String name, class_1792 item){
        return class_2378.method_10230(
            class_7923.field_41178, 
            new class_2960("the-roots-of-ancient-magic", name),
            item
        );
    }

    public static void registerModItems(){
    }
}
