package com.therootsofancientmagic.item;

import java.util.function.Supplier;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public enum ModArmorMaterial implements class_1741 {
    // Железо
    ESSENCE_AQUA(
            "the-roots-of-ancient-magic:essence_aqua",
            825,
            new int[]{3, 8, 6, 3},
            15,
            class_3417.field_15103,
            2.0f,
            0.1f,
            () -> class_1856.method_8091(ModItem.ESSENCE_AQUA)
    ),

    ESSENCE_AIR(
            "the-roots-of-ancient-magic:essence_air",
            825,
            new int[]{3, 7, 6, 3},
            20,
            class_3417.field_14581,
            1.0f,
            0.0f,
            () -> class_1856.method_8091(ModItem.ESSENCE_AIR)
    ),

    // Алмазная
    ESSENCE_FIRE(
            "the-roots-of-ancient-magic:essence_fire",
            35,
            new int[]{4, 9, 7, 4},
            1815,
            class_3417.field_21866,
            2.5f,
            0.1f,
            () -> class_1856.method_8091(ModItem.ESSENCE_FIRE)
    ),

    ESSENCE_EARTH(
            "the-roots-of-ancient-magic:essence_earth",
            1815,
            new int[]{5, 10, 8, 5},
            25,
            class_3417.field_21866,
            3.0f,
            0.2f,
            () -> class_1856.method_8091(ModItem.ESSENCE_EARTH)
    ),

    // Незеритавая 
    ESSENCE_DARK(
            "the-roots-of-ancient-magic:essence_dark",
            2500,
            new int[]{4, 9, 7, 4},
            30,
            class_3417.field_21866,
            3.0f,
            0.2f,
            () -> class_1856.method_8091(ModItem.ESSENCE_DARK)
    ),

    ESSENCE_LIGHT(
            "the-roots-of-ancient-magic:essence_light",
            2500,
            new int[]{5, 10, 8, 5},
            30,
            class_3417.field_14761,
            2.0f,
            0.1f,
            () -> class_1856.method_8091(ModItem.ESSENCE_LIGHT)
    ),

    // Чуть лучше Незеритовой
    ESSENCE_HEROIC(
            "the-roots-of-ancient-magic:essence_heroic",
            50,
            new int[]{5, 10, 8, 5},
            25,
            class_3417.field_21866,
            3.0f,
            0.2f,
            () -> class_1856.method_8091(ModItem.ESSENCE_HEROIC)
    );

    private final String gameName;
    private final int durabilityMultiplier;
    private final int[] protectionAmounts;
    private final int enchantability;
    private final class_3414 equipSound;
    private final float toughness;
    private final float knockbackResistance;
    private final Supplier<class_1856> repairIngredient;

    ModArmorMaterial(
            String gameName,
            int durabilityMultiplier,
            int[] protectionAmounts,
            int enchantability,
            class_3414 equipSound,
            float toughness,
            float knockbackResistance,
            Supplier<class_1856> repairIngredient
    ) {
        this.gameName = gameName;
        this.durabilityMultiplier = durabilityMultiplier;
        this.protectionAmounts = protectionAmounts;
        this.enchantability = enchantability;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public String method_7694() {
        return gameName;
    }

    @Override
    public int method_48402(class_1738.class_8051 type) {
        int[] baseDurability = {13, 15, 16, 11};
        return baseDurability[type.ordinal()] * durabilityMultiplier;
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        return protectionAmounts[type.ordinal()];
    }

    @Override
    public int method_7699() {
        return enchantability;
    }

    @Override
    public class_3414 method_7698() {
        return equipSound;
    }

    @Override
    public class_1856 method_7695() {
        return repairIngredient.get();
    }

    @Override
    public float method_7700() {
        return toughness;
    }

    @Override
    public float method_24355() {
        return knockbackResistance;
    }
}