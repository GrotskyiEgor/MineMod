package com.therootsofancientmagic.item;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import com.therootsofancientmagic.block.ModBlock;
import com.therootsofancientmagic.block.ModFlowerBlock;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public class ModItemGroups {
    public static final class_1761 TOOLS = class_2378.method_10230(
            class_7923.field_44687,
            TheRootsOfAncientMagic.id("roots_of_ancient_magic_tools"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471(
                            "itemGroup.the-roots-of-ancient-magic.tools"
                    ))
                    .method_47320(() -> new class_1799(ModItem.HEROIC_SWORD))
                    .method_47317((context, entries) -> {
                        entries.method_45421(ModItem.BATTLE_AXE);

                        entries.method_45421(ModItem.LIGHTNING_HAMMER);
                        entries.method_45421(ModItem.NECROMANCER_SCYTHE);

                        entries.method_45421(ModItem.FIRE_STAFF);
                        entries.method_45421(ModItem.AIR_STAFF);
                        entries.method_45421(ModItem.EARTH_STAFF);
                        entries.method_45421(ModItem.AQUA_STAFF);    
                        entries.method_45421(ModItem.LIGHT_STAFF); 
                        entries.method_45421(ModItem.DARK_STAFF); 
                        
                        entries.method_45421(ModItem.HEROIC_STAFF);
                        entries.method_45421(ModItem.HEROIC_SWORD);
                        entries.method_45421(ModItem.HEROIC_PICKAXE);
                        entries.method_45421(ModItem.HEROIC_AXE);
                        entries.method_45421(ModItem.HEROIC_SHOVEL);
                        entries.method_45421(ModItem.HEROIC_HOE);

                        entries.method_45421(ModItem.FIRE_PICKAXE);
                        entries.method_45421(ModItem.AQUA_PICKAXE);
                        entries.method_45421(ModItem.AIR_PICKAXE);
                        entries.method_45421(ModItem.DARK_PICKAXE);
                        entries.method_45421(ModItem.LIGHT_PICKAXE);
                        entries.method_45421(ModItem.EARTH_PICKAXE);

                        entries.method_45421(ModItem.FIRE_AXE);
                        entries.method_45421(ModItem.AQUA_AXE);
                        entries.method_45421(ModItem.AIR_AXE);
                        entries.method_45421(ModItem.DARK_AXE);
                        entries.method_45421(ModItem.LIGHT_AXE);
                        entries.method_45421(ModItem.EARTH_AXE);

                        entries.method_45421(ModItem.FIRE_SHOVEL);
                        entries.method_45421(ModItem.AQUA_SHOVEL);
                        entries.method_45421(ModItem.AIR_SHOVEL);
                        entries.method_45421(ModItem.DARK_SHOVEL);
                        entries.method_45421(ModItem.LIGHT_SHOVEL);
                        entries.method_45421(ModItem.EARTH_SHOVEL);
                        
                        entries.method_45421(ModItem.FIRE_HOE);
                        entries.method_45421(ModItem.AQUA_HOE);
                        entries.method_45421(ModItem.AIR_HOE);
                        entries.method_45421(ModItem.DARK_HOE);
                        entries.method_45421(ModItem.LIGHT_HOE);
                        entries.method_45421(ModItem.EARTH_HOE);
                    })
                    .method_47324()
    );

    public static final class_1761 MAGIC_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            TheRootsOfAncientMagic.id("roots_of_ancient_magic_magic"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471(
                            "itemGroup.the-roots-of-ancient-magic.magic"
                    ))
                    .method_47320(() -> new class_1799(ModItem.ESSENCE_FIRE))
                    .method_47317((context, entries) -> {
                        entries.method_45421(ModItem.ESSENCE_AQUA);
                        entries.method_45421(ModItem.ESSENCE_FIRE);
                        entries.method_45421(ModItem.ESSENCE_AIR);
                        entries.method_45421(ModItem.ESSENCE_EARTH);
                        entries.method_45421(ModItem.ESSENCE_LIGHT);
                        entries.method_45421(ModItem.ESSENCE_DARK);
                        entries.method_45421(ModItem.ESSENCE_HEROIC);

                        entries.method_45421(ModItem.FRAGMENT_AQUA);
                        entries.method_45421(ModItem.FRAGMENT_FIRE);
                        entries.method_45421(ModItem.FRAGMENT_AIR);
                        entries.method_45421(ModItem.FRAGMENT_EARTH);
                        entries.method_45421(ModItem.FRAGMENT_LIGHT);
                        entries.method_45421(ModItem.FRAGMENT_DARK);
                        entries.method_45421(ModItem.FRAGMENT_HEROIC);
                        
                        entries.method_45421(ModBlock.FURNACE_POWDER);
                        entries.method_45421(ModBlock.CRAFT_TABLE);
                        entries.method_45421(ModItem.IRON_STICK);

                        entries.method_45421(ModFlowerBlock.FLOWER_DARK);
                        entries.method_45421(ModFlowerBlock.FLOWER_LIGHT);
                        entries.method_45421(ModFlowerBlock.FLOWER_AQUA);
                        entries.method_45421(ModFlowerBlock.FLOWER_FIRE);
                        entries.method_45421(ModFlowerBlock.FLOWER_EARTH);
                        entries.method_45421(ModFlowerBlock.FLOWER_AIR);
                    })
                    .method_47324()
    );

    public static final class_1761 ARMOR_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            TheRootsOfAncientMagic.id("roots_of_ancient_magic_armor"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471(
                            "itemGroup.the-roots-of-ancient-magic.armor"
                    ))
                    .method_47320(() -> new class_1799(ModItem.FIRE_BOOTS))
                    .method_47317((context, entries) -> {                                             
                        entries.method_45421(ModItem.FIRE_HELMET); 
                        entries.method_45421(ModItem.FIRE_CHESTPLATE);                       
                        entries.method_45421(ModItem.FIRE_LEGGINGS);                      
                        entries.method_45421(ModItem.FIRE_BOOTS);

                        entries.method_45421(ModItem.AQUA_HELMET);
                        entries.method_45421(ModItem.AQUA_CHESTPLATE);
                        entries.method_45421(ModItem.AQUA_LEGGINGS);
                        entries.method_45421(ModItem.AQUA_BOOTS);

                        entries.method_45421(ModItem.AIR_HELMET); 
                        entries.method_45421(ModItem.AIR_CHESTPLATE);                       
                        entries.method_45421(ModItem.AIR_LEGGINGS);                      
                        entries.method_45421(ModItem.AIR_BOOTS);

                        entries.method_45421(ModItem.EARTH_HELMET); 
                        entries.method_45421(ModItem.EARTH_CHESTPLATE);                       
                        entries.method_45421(ModItem.EARTH_LEGGINGS);                      
                        entries.method_45421(ModItem.EARTH_BOOTS);

                        entries.method_45421(ModItem.LIGHT_HELMET); 
                        entries.method_45421(ModItem.LIGHT_CHESTPLATE);                       
                        entries.method_45421(ModItem.LIGHT_LEGGINGS);                      
                        entries.method_45421(ModItem.LIGHT_BOOTS);

                        entries.method_45421(ModItem.DARK_HELMET); 
                        entries.method_45421(ModItem.DARK_CHESTPLATE);                       
                        entries.method_45421(ModItem.DARK_LEGGINGS);                      
                        entries.method_45421(ModItem.DARK_BOOTS);

                        entries.method_45421(ModItem.HEROIC_HELMET); 
                        entries.method_45421(ModItem.HEROIC_CHESTPLATE);                       
                        entries.method_45421(ModItem.HEROIC_LEGGINGS);                      
                        entries.method_45421(ModItem.HEROIC_BOOTS);

                        entries.method_45421(ModItem.AQUA_ROBE);
                        entries.method_45421(ModItem.FIRE_ROBE);
                        entries.method_45421(ModItem.AIR_ROBE);
                        entries.method_45421(ModItem.EARTH_ROBE);
                        
                        entries.method_45421(ModItem.AQUA_NECKLACE);
                        entries.method_45421(ModItem.FIRE_NECKLACE);
                        entries.method_45421(ModItem.EARTH_NECKLACE);
                        entries.method_45421(ModItem.AIR_NECKLACE);

                        entries.method_45421(ModItem.AQUA_RING);
                        entries.method_45421(ModItem.FIRE_RING);
                        entries.method_45421(ModItem.AIR_RING);
                        entries.method_45421(ModItem.EARTH_RING);
                    })
                    .method_47324()
    );

    public static void registerItemGroups() {}
}