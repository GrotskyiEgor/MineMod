package com.therootsofancientmagic.item.tools.axe; // Убедись, что путь к пакету совпадает с твоим проектом

import com.therootsofancientmagic.item.ModToolMaturial;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3481;


public class ElementalAxeItem extends class_1743 {

    public ElementalAxeItem(class_1832 material, float attackDamage, float attackSpeed, class_1792.class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        if (!world.method_8608() && miner instanceof class_3222 player) {
            
            // Получаем случайное число для расчета 5% шанса баффов
            float effectChance = player.method_6051().method_43057();
            if (effectChance < 0.05F) {
                if (this.method_8022() == ModToolMaturial.ESSENCE_AIR) {
                    player.method_6092(new class_1293(class_1294.field_5904, 600, 0));
                }
                else if (this.method_8022() == ModToolMaturial.ESSENCE_AQUA) {
                    player.method_6092(new class_1293(class_1294.field_5923, 600, 0));
                } 
                else if (this.method_8022() == ModToolMaturial.ESSENCE_DARK || this.method_8022() == ModToolMaturial.ESSENCE_LIGHT) {
                    player.method_6092(new class_1293(class_1294.field_5925, 600, 0));
                } 
                else if (this.method_8022() == ModToolMaturial.ESSENCE_EARTH) {
                    player.method_6092(new class_1293(class_1294.field_5917, 600, 0));
                } 
                else if (this.method_8022() == ModToolMaturial.ESSENCE_FIRE) {
                    player.method_6092(new class_1293(class_1294.field_5918, 600, 0));
                }
            }
            //Проверяет, является ли блок деревом
            if (state.method_26164(class_3481.field_15475)) {
                // Проходит по дереву вверх, начиная с блока, которий бил сломан, просто чтоби найти все блоки дерева в пределах 30 блоков вверх
                for (int y = 1; y <= 30; y++) {
                    // Если топор сломался то дерево перестает ломаться
                    if (stack.method_7960()) break; 

                    boolean foundLogInLayer = false;
                    // Определяет центр дерева, которий ми проверяем
                    class_2338 layerCenter = pos.method_10086(y);
                    
                    // Сетка 5x5 вокруг центра дерева,чтоби найти все блоки дерева в пределах этого слоя
                     for (int x = -2; x <= 2; x++) {
                        for (int z = -2; z <= 2; z++) {
                            // Получает точние координати конкретного блока на этой сетке 3х3
                            class_2338 nextLogPos = layerCenter.method_10069(x, 0, z);
                            // Получает состояние блока на этих координатах
                            class_2680 nextLogState = world.method_8320(nextLogPos);

                           // Проверяет является ли этот блок деревом,если да, то ломает его и наносит урон топору
                            if (nextLogState.method_26164(class_3481.field_15475)) {
                                world.method_8651(nextLogPos, true, player);
                                stack.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
                                // Если блок дерева сломали, то дает значение True
                                foundLogInLayer = true;
                            }
                        }
                    }
                    // Если дерева верху больше нету, например небо началось, то цикл останавливаеться
                    if (!foundLogInLayer) {
                        break; 
                    }
                }
            }
        }

        return super.method_7879(stack, world, state, pos, miner);
    }
}
