package com.therootsofancientmagic.item.tools.sword;

import com.therootsofancientmagic.item.ModToolMaturial;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;

public class ElementalSwordItem extends class_1829 {

    public ElementalSwordItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        // Случайный шанс, 0.3f = 30% шанс
        float randomChance = attacker.method_6051().method_43057();

        // Проверяем, что в руках огненный меч и случайно срабатывает эффект поджигания с шансом 30% 
        if (this.method_8022() == ModToolMaturial.ESSENCE_FIRE && randomChance < 0.3F) {
            target.method_5639(5); // Поджигаем цель на 5 секунд
        }
        // Проверяем, что в руках водный меч и случайно срабатывает эффект медлительности с шансом 30%
        if (this.method_8022() == ModToolMaturial.ESSENCE_AQUA && randomChance < 0.3F) {
            // Медлительность II уровня на 4 секунды
            target.method_6092(new class_1293(class_1294.field_5909, 80, 1));
        }
        // Проверяем что рукав в руках воздушний меч и случайно срабатывает эффект отбрасывания с шансом 30%
        if (this.method_8022() == ModToolMaturial.ESSENCE_AIR && randomChance < 0.3F) {
            // Мы передаем направление взгляда игрока(как raycast)
            target.method_6005(1.2F, attacker.method_23317() - target.method_23317(), attacker.method_23321() - target.method_23321());
        }
         if (this.method_8022() == ModToolMaturial.ESSENCE_EARTH && randomChance < 0.3F) {
            // Подбрасываем цель 5 блоков верх
            target.method_5762(0, 1.0, 0);
            target.field_6037 = true;
        }
        
        // Проверяем, что в руках темный меч и случайно срабатывает эффект слепоти с шансом 30%
        if (this.method_8022() == ModToolMaturial.ESSENCE_DARK && randomChance < 0.3F) {
            // Слепота I уровня на 5 секунд 
            target.method_6092(new class_1293(class_1294.field_5919, 100, 0));
        }
        // Проверяем, что в руках светлый меч и случайно срабатывает эффект свечения с шансом 30%
        if (this.method_8022() == ModToolMaturial.ESSENCE_LIGHT && randomChance < 0.3F) {
            // Свечение I уровня на 7 секунд
            target.method_6092(new class_1293(class_1294.field_5912, 140, 0));
        }

        return super.method_7873(stack, target, attacker);
    }
}
