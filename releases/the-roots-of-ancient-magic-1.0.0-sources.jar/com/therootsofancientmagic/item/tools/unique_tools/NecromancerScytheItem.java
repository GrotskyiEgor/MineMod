package com.therootsofancientmagic.item.tools.unique_tools;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1314;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1613;
import net.minecraft.class_1639;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;

public class NecromancerScytheItem extends class_1829 {

    // Абилка стоит 50 мани, тоесть 5 орбов
    private static final int MANA_COST = 100;
    // кулдаун на использование, 15 секунд
    private static final int COOLDOWN_TICKS = 300;

    public NecromancerScytheItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    // Накладывает пассивние эффекти каждие 20 тиков, пока коса находится в руках
    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        if (!world.method_8608() && entity instanceof net.minecraft.class_1309 livingEntity) {
            
            // Проверяет активний слот хотбара или левую руку
            boolean isHoldingInMainHand = selected;
            boolean isHoldingInOffHand = livingEntity.method_6079() == stack;

            if (isHoldingInMainHand || isHoldingInOffHand) {
                // Обновляет Ночное зрение и Скорость I на 2 тика для мгновенного снятия при свапе слота
                livingEntity.method_6092(new class_1293(class_1294.field_5925, 2, 0, false, false, true));
                livingEntity.method_6092(new class_1293(class_1294.field_5904, 2, 0, false, false, true));
            }
        }
        super.method_7888(stack, world, entity, slot, selected);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        // Проверяет кулдаун коси
        if (user.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }

        // Запускает руку и ставит локальний кулдаун на клиенте для синхронизации слотов
        if (world.method_8608()) {
            user.method_7357().method_7906(this, COOLDOWN_TICKS);
            return class_1271.method_22427(stack);
        }

        if (!world.method_8608() && user instanceof class_3222 serverPlayer) {
            
           // Тратит 50 мани при использовании абилки
            if (!serverPlayer.method_7337() 
                    && !PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, MANA_COST, serverPlayer)) {
                // Снимает кд на клиенте, если мани не хватило для запуска
                serverPlayer.method_7357().method_7900(this);
                return class_1271.method_22431(stack);
            }

            class_3218 serverWorld = (class_3218) world;
            class_2338 playerPos = serverPlayer.method_24515();

            // Призивает 2 визер скелета
            for (int i = 0; i < 2; i++) {
                class_1639 witherSkeleton = class_1299.field_6076.method_5883(world);
                if (witherSkeleton != null) {
                    setupSummon(witherSkeleton, serverPlayer, serverWorld, playerPos);
                }
            }

            // Призивает 2 зомби
            for (int i = 0; i < 2; i++) {
                class_1642 zombie = class_1299.field_6051.method_5883(world);
                if (zombie != null) {
                    setupSummon(zombie, serverPlayer, serverWorld, playerPos);
                }
            }

            // Призивает 1 скелета 
            class_1613 skeleton = class_1299.field_6137.method_5883(world);
            if (skeleton != null) {
                skeleton.method_5673(class_1304.field_6173, new class_1799(class_1802.field_8102));
                setupSummon(skeleton, serverPlayer, serverWorld, playerPos);
            }
            
            world.method_8396(null, playerPos, class_3417.field_15163, class_3419.field_15248, 1.0F, 0.5F);
            serverWorld.method_14199(class_2398.field_11249, serverPlayer.method_23317(), serverPlayer.method_23318() + 1.0D, serverPlayer.method_23321(), 30, 1.5D, 0.5D, 1.5D, 0.1D);
            
            // Активирует кд
            serverPlayer.method_7357().method_7906(this, COOLDOWN_TICKS);
            return class_1271.method_22428(stack);
        }

        return class_1271.method_22430(stack);
    }

    // Главний ии у мобов, чтоби они не атаковали игрока которий их призвал
    private void setupSummon(class_1314 summon, class_3222 master, class_3218 world, class_2338 pos) {
        // Спавнит мобов в рандомном месте возле игрока чтоб не в 1 кучке
        double xOffset = master.method_6051().method_43058() * 3.0D - 1.5D;
        double zOffset = master.method_6051().method_43058() * 3.0D - 1.5D;
        
        summon.method_5808(master.method_23317() + xOffset, master.method_23318(), master.method_23321() + zOffset, master.method_36454(), master.method_36455());
        summon.method_5943(world, world.method_8404(pos), class_3730.field_16471, null, null);

        // Убирает полний таргет у мобов, они атаковать никого не будут
        summon.method_5980(null);
        
        try {
            java.lang.reflect.Field targetSelectorField = class_1308.class.getDeclaredField("targetSelector");
            targetSelectorField.setAccessible(true);
            net.minecraft.class_1355 targetSelector = (net.minecraft.class_1355) targetSelectorField.get(summon);

            if (targetSelector != null) {
                // Очищает базовий селектор целей через полученний селектор
                targetSelector.method_35113(goal -> true);

                // Моб будет атаковать тех кто его ударил(только не игрока)
                targetSelector.method_6277(1, new class_1399(summon) {
                    @Override
                    public boolean method_6266() {
                        if (summon.method_6065() == master) {
                            summon.method_6015(null);
                            return false;
                        }
                        return super.method_6266();
                    }

                    @Override
                    public void method_6269() {
                        if (summon.method_6065() == master) {
                            summon.method_6015(null);
                            return;
                        }
                        super.method_6269();
                    }
                }.method_6318(class_1657.class));
                
                // Моб будет атаковать тех кого ударил игрок(которий их призвал)
                targetSelector.method_6277(2, new class_1400<>(summon, class_1308.class, true, (entity) -> {
                    if (entity == master || entity == summon) return false;
                    return entity.method_6065() == master || master.method_6052() == entity;
                }));
            }
        } catch (Exception e) {
            // Логирует ошибку в консоль
            e.printStackTrace();
        }

        world.method_8649(summon);
    }
}