package com.therootsofancientmagic.item.tools.unique_tools;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class BattleAxeItem extends class_1829 {

    // Радиус абилки(как торнадо)
    private static final double SPIN_RADIUS = 3.5D;
    // Кулдаун в тиках: 10 секунд * 20 тиков = 200
    private static final int COOLDOWN_TICKS = 200;

    public BattleAxeItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    // Задает тип анимации, заставляет держать топор в руке пока идет абилка
    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8952; 
    }

    // Абилка длиться 5 секунд
    @Override
    public int method_7881(class_1799 stack) {
        return 100;
    }

    // Срабативает когда нажимаеться правая кнопка миши
    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        // Проверяем кулдаун перед активацией
        if (user.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }

        if (user instanceof class_3222 serverPlayer) {
            // Проверяет, если есть 20 мани
            if (!serverPlayer.method_7337()
                    && !PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, 10, serverPlayer)) {
                // Если нету мани то абилки не будет
                return class_1271.method_22431(stack);
            }
        }
        // Похоже с типом анимации, но ета функция удерживает топор в руке
        user.method_6019(hand);

        
        return class_1271.method_29237(stack, world.method_8608());
    }

    // Главний цикл, сервер постоянно тикает когда зажата абилка
    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTime) {
        if (user instanceof class_1657 player) {
            
            // При абилке на игрока налаживаеться ефект замедления и сопротивления
            player.method_6092(new class_1293(class_1294.field_5909, 2, 0, false, false, false));
            player.method_6092(new class_1293(class_1294.field_5907, 2, 0, false, false, false));

            // Расщитивает сколько секунд/тиков осталось до завершения абилки
            int ticksUsed = method_7881(stack) - remainingUseTime;

            // Каждий тик вращает игрока на 45 градусов
            float currentBodyYaw = player.method_36454() + (ticksUsed * 45.0F);
            player.method_5636(currentBodyYaw);
            player.method_5847(currentBodyYaw);

            // Вращение частиц (Выполняется только на стороне клиента для безопасности)
            if (world.method_8608()) {
                double angle = ticksUsed * 0.4D; 
                double px = player.method_23317() + Math.cos(angle) * 2.5D;
                double pz = player.method_23321() + Math.sin(angle) * 2.5D;
                world.method_8406(class_2398.field_11227, px, player.method_23318() + 0.8D, pz, 0, 0, 0);
            }
            
            if (!world.method_8608() && player instanceof class_3222 serverPlayer) {
                // Каждую секунду абилки, списивает 10 мани
                if (ticksUsed % 20 == 0 && ticksUsed > 0) {
                    if (!serverPlayer.method_7337() && !PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, 5, serverPlayer)) {
                        // Если мани нет, абилка прекращаеться
                        player.method_6021();
                        return;
                    }
                }

                if (ticksUsed % 10 == 0) {
                    class_243 playerPos = player.method_19538();
                    
                    // Создает 5д куб в котором наноситься урон при обнаружения мобов в нем
                    class_238 searchBox = new class_238(
                            playerPos.field_1352 - SPIN_RADIUS, playerPos.field_1351 - 1.0D, playerPos.field_1350 - SPIN_RADIUS,
                            playerPos.field_1352 + SPIN_RADIUS, playerPos.field_1351 + 2.0D, playerPos.field_1350 + SPIN_RADIUS
                    );
                    // СОбирает список врагов в кубе
                    List<class_1297> targets = world.method_8333(player, searchBox, 
                            entity -> entity instanceof class_1309 && entity.method_5739(player) <= SPIN_RADIUS);

                    // Наносит урон каждому мобу в кубе
                    for (class_1297 entity : targets) {
                        class_1309 target = (class_1309) entity;
                        // Наносит весь урон топора
                        target.method_5643(world.method_48963().method_48802(player), this.method_8020());

                        // При нанесении урона отбрасивает врагов от игрока
                        class_243 pushDirection = target.method_19538().method_1020(playerPos).method_1029().method_1021(0.4D);
                        target.method_5762(pushDirection.field_1352, 0.1D, pushDirection.field_1350);
                        target.field_6037 = true;
                    }
                    // Звук
                    world.method_8396(null, player.method_24515(), class_3417.field_14706, 
                            class_3419.field_15248, 1.0F, 0.8F);
                    // Партикли
                    if (world instanceof class_3218 serverWorld) {
                        serverWorld.method_14199(class_2398.field_11204, 
                                player.method_23317(), player.method_23318() + 0.2D, player.method_23321(), 
                                5, 1.2D, 0.1D, 1.2D, 0.05D);
                    }
                }
            }
        }
    }

    @Override
    public void method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTime) {
        if (user instanceof class_1657 player) {
            player.method_7357().method_7906(this, COOLDOWN_TICKS);
        }
        super.method_7840(stack, world, user, remainingUseTime);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (user instanceof class_1657 player) {
            // 10 секунд кд для топора, если способность полностью завершилась
            player.method_7357().method_7906(this, COOLDOWN_TICKS);
        }
        return super.method_7861(stack, world, user);
    }
}