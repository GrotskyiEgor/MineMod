package com.therootsofancientmagic.item.tools.unique_tools;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class LightningHammerItem extends class_1829 {

    private static final int COOLDOWN_TICKS = 100;
    private static final int MANA_COST = 80;
    private static final double RAYCAST_DISTANCE = 20.0D;

    public LightningHammerItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    // При ударе дает Слабость 2 
    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        if (!attacker.method_37908().method_8608()) {
            // Накладывает Слабость II на врага при ударе на 6 секунд (120 тиков)
            target.method_6092(new class_1293(class_1294.field_5911, 120, 1));
        }
        return super.method_7873(stack, target, attacker);
    }

    // Механика призыва молнии
    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (user.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }

        if (!world.method_8608() && user instanceof class_3222 serverPlayer) {
            
            // Тратит 30 мани
            if (!serverPlayer.method_7337() 
                    && !PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, MANA_COST, serverPlayer)) {
                // Если маны нет,способность не сработает
                return class_1271.method_22431(stack);
            }

            // Запускает рейкаст по взгляду игрока
            class_243 cameraPos = serverPlayer.method_33571();
            class_243 rotationVec = serverPlayer.method_5828(1.0F);
            class_243 targetPos = cameraPos.method_1019(rotationVec.method_1021(RAYCAST_DISTANCE));

            // Делает рейкаст на блоки
            class_239 blockHit = world.method_17742(new net.minecraft.class_3959(
                    cameraPos, targetPos,
                    net.minecraft.class_3959.class_3960.field_17559,
                    net.minecraft.class_3959.class_242.field_1348,
                    serverPlayer
            ));

            class_2338 strikePos = null;

            if (blockHit.method_17783() == class_239.class_240.field_1332) {
                strikePos = ((class_3965) blockHit).method_17777();
            } 
            else {
                strikePos = class_2338.method_49638(targetPos);
            }

            // Рейкаст для мобов
            class_239 entityHit = class_1675.method_18075(
                    serverPlayer, cameraPos, targetPos,
                    serverPlayer.method_5829().method_18804(rotationVec.method_1021(RAYCAST_DISTANCE)).method_1009(1.0D, 1.0D, 1.0D),
                    entity -> entity instanceof class_1309,
                    RAYCAST_DISTANCE * RAYCAST_DISTANCE
            );

            if (entityHit != null && entityHit.method_17783() == class_239.class_240.field_1331) {
                strikePos = ((class_3966) entityHit).method_17782().method_24515();
            }

            if (strikePos != null) {
                class_1538 lightning = class_1299.field_6112.method_5883(world);
                if (lightning != null) {
                    lightning.method_29495(class_243.method_24955(strikePos));
                    lightning.method_6961(serverPlayer); 
                    world.method_8649(lightning);
                }
            }

            // Задает для молота кд 5 сеунд
            serverPlayer.method_7357().method_7906(this, COOLDOWN_TICKS);
            return class_1271.method_29237(stack, false);
        }

        return class_1271.method_29237(stack, world.method_8608());
    }
}