package com.therootsofancientmagic.item.tools.pickaxe;

import com.therootsofancientmagic.item.ModToolMaturial;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1277;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3861;
import net.minecraft.class_3956;
import net.minecraft.class_3965;
import java.util.List;
import java.util.Optional;

public class ElementalPickaxeItem extends class_1810 {

    public ElementalPickaxeItem(class_1832 material, int attackDamage, float attackSpeed, class_1792.class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
        this.registerEvents();
    }
    private void registerEvents() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (!world.method_8608() && player instanceof class_3222 serverPlayer) {
                class_1799 mainHandItem = serverPlayer.method_6047();

                // Проверяет если игрок держит в руке кирку с материалом ESSENCE_FIRE, то активирует функцию AutoSmeltBlock
                if (mainHandItem.method_7909() == this && this.method_8022() == ModToolMaturial.ESSENCE_FIRE) {
                    
                    //Визиваем метод AutoSmeltBlock, которий обрабативает переплавку
                    if (AutoSmeltBlock((class_3218) world, pos, state, serverPlayer, mainHandItem)) {
                        //Если автоплавка сработала, отменяем випадение непереплавленних предметов
                        return false; 
                    }
                }
            }
            return true;
        });
    }
    
    // Функция, которая переплавляет блоки, если на них есть рецепт переплавки,например железная руда сразу превращаеться железний слиток
    private boolean AutoSmeltBlock(class_3218 world, class_2338 pos, class_2680 state, class_3222 player, class_1799 toolStack) {
        // Получаем список предметов, которие должни били випасть
        List<class_1799> normalDrops = class_2248.method_9609(state, world, pos, null, player, player.method_6047());
        boolean smeltedAny = false;

        for (class_1799 drop : normalDrops) {
            // Ищем подходящий рецепт плавки в печи для полученного предмета
            Optional<class_3861> recipe = world.method_8433()
                .method_8132(class_3956.field_17546, new class_1277(drop), world);

            // Если нашли рецепт, то сразу переплавляет предмет в его переплавленний предмет,например железная руда переплавляеться в железний слиток
            if (recipe.isPresent()) {
                class_1799 cookedResult = recipe.get().method_8110(world.method_30349()).method_7972();
                cookedResult.method_7939(drop.method_7947());

                // Удаляет старий предмет из мира и заменяет его на переплавленний предмет
                world.method_8652(pos, class_2246.field_10124.method_9564(), 3);
                class_2248.method_9577(world, pos, cookedResult);
                toolStack.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
                smeltedAny = true;
                // 5% шанс на накладивание эффекта Огнестойкость I на 30 секунд при ломание блока огненной киркой
                if (player.method_6051().method_43057() < 0.05F) {
                    // Накладиваем Огнестойкость I на 30 секунд
                    player.method_6092(new class_1293(class_1294.field_5918, 600, 0));
                }
            }
        }
        return smeltedAny;
    }
    
    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        if (!world.method_8608() && miner instanceof class_3222 player) {
            // Генерируем случайное число от 0.0 до 1.0 для шанса на наложение эффекта, если видает 0.05(5%),то накладивает эффект
            float effectChance = player.method_6051().method_43057();

            // 1. AIR ABILITY (1x1x3 mining)
            if (this.method_8022() == ModToolMaturial.ESSENCE_AIR && method_7856(state)) {
                breakTunnel(world, pos, player, stack, 2);
                // 5% шанс на накладивание эффекта Скорость I на 30 секунд при ломание блока воздушной киркой
                if (effectChance < 0.05F) {
                    player.method_6092(new class_1293(class_1294.field_5904, 600, 0));
                }
            }
            
            // 3. AQUA ABILITY (1x1x3 mining)
            if (this.method_8022() == ModToolMaturial.ESSENCE_AQUA) {
                breakTunnel(world, pos, player, stack, 2);
                // 5% шанс на накладивание эффекта Водное дихание I на 30 секунд при ломание блока водной киркой
                if (effectChance < 0.05F) {
                    player.method_6092(new class_1293(class_1294.field_5923, 600, 0));
                }
            }
            
            // 4. DARK ABILITY (5x5 mining)
            if (this.method_8022() == ModToolMaturial.ESSENCE_DARK) {
                breakArea(world, pos, player, stack, -2, 2, -2, 2, 0, 0);
                // 5% шанс на накладивание эффекта Ночного зрения I на 30 секунд при ломание блока темной киркой
                if (effectChance < 0.05F) {
                    player.method_6092(new class_1293(class_1294.field_5925, 600, 0));
                }

            }

            // 5. LIGHT ABILITY (5x5 mining)
            if (this.method_8022() == ModToolMaturial.ESSENCE_LIGHT) {
                breakArea(world, pos, player, stack, -2, 2, -2, 2, 0, 0);
                // 5% шанс на накладивание эффекта Ночного зрения I на 30 секунд при ломание блока светлой киркой
                if (effectChance < 0.05F) {
                    player.method_6092(new class_1293(class_1294.field_5925, 600, 0));
                }
            }

            // 6. EARTH ABILITY (3x3 mining)
            if (this.method_8022() == ModToolMaturial.ESSENCE_EARTH) {
                breakArea(world, pos, player, stack, -1, 1, -1, 1, 0, 0);
                // 5% шанс на накладивание эффекта Ускорение I на 30 секунд при ломание блока земной киркой
                if (effectChance < 0.05F) {
                    player.method_6092(new class_1293(class_1294.field_5917, 600, 0));
                }
            }
        }

        return super.method_7879(stack, world, state, pos, miner);
    }
    //Функция которая создает лазер из голови игрока и определяет на какой блок игрок смотрит
    private class_2350 getPlayerDirection(class_3222 player) {
        class_239 hit = player.method_5745(20.0D, 0.0F, false);
        if (hit.method_17783() == class_239.class_240.field_1332) {
            return ((class_3965) hit).method_17780();
        }
        return class_2350.field_11036;
    }
    //функция которая определяет куда смотрит игрок,верх/вниз/влево/вправо и в зависимости от этого ломает блоки вокруг блока на которий игрок нажал
    private class_2338 getTargetBlockPos(class_2338 center, class_2350 face, int gridX, int grixY, int depth) {
        class_2338 shiftedCenter = center.method_10079(face.method_10153(), depth);

        if (face == class_2350.field_11036 || face == class_2350.field_11033) {
            return shiftedCenter.method_10069(gridX, depth, grixY);
        } else if (face == class_2350.field_11034 || face == class_2350.field_11039) {
            return shiftedCenter.method_10069(depth, grixY, gridX);
        } else {
            return shiftedCenter.method_10069(gridX, grixY, depth);
        }
    }
    //Тоже самое что и breakArea, только ломает блоки вглубь, в зависимости от того на какой блок игрок нажал
    private void breakTunnel(class_1937 world, class_2338 targetPos, class_3222 player, class_1799 toolStack, int maxDepth) {
        class_2350 face = getPlayerDirection(player);
        class_2350 inwardDirection = face.method_10153();

        for (int i = 1; i <= maxDepth; i++) {
            class_2338 nextBlockPos = targetPos.method_10079(inwardDirection, i);
            class_2680 nextBlockState = world.method_8320(nextBlockPos);

            if (!nextBlockState.method_26215() && nextBlockState.method_26214(world, nextBlockPos) >= 0) {
                world.method_8651(nextBlockPos, true, player);
                toolStack.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
                if (toolStack.method_7960()) {
                    return;
                }
            }
        }
    }
    //Самая главная функция, в зависимости от значений в (), ломает блоки так,
    // breakArea(world, pos, player, stack, -1, 1, -1, 1) - ломает блоки 3x3 
    // breakArea(world, pos, player, stack, -1, 2, -1, 2) - ломает блоки 4x4
    private void breakArea(class_1937 world, class_2338 targetPos, class_3222 player, class_1799 toolStack, int minX, int maxX, int minY, int maxY, int minDepth, int maxDepth) {
        class_2350 DirectionSide = getPlayerDirection(player);
        // 3D и 2D сетка, которая определяет какие блоки ломать вокруг блока на которий игрок нажал или вглубину
        for (int depth = minDepth; depth <= maxDepth; depth++) {
            for (int gridX = minX; gridX <= maxX; gridX++) {
                for (int gridY = minY; gridY <= maxY; gridY++) {

                 // Пропускает центральний блок которий игрок сломал
                if (depth == 0 && gridX == 0 && gridY == 0) continue;
           
              // Получает блоки которие возле блока на которий игрок нажал,в зависимости от сторони на которую игрок смотрит(raycast)
              class_2338 NeighbourBlockPos = getTargetBlockPos(targetPos, DirectionSide, gridX, gridY, depth);
              class_2680 NeighbourBlockState = world.method_8320(NeighbourBlockPos);
             //Проверяет если блок сломать можно, если ето бедрок или воздух,то не ломает
             if (!NeighbourBlockState.method_26215() && NeighbourBlockState.method_26214(world, NeighbourBlockPos) >= 0) {
                        world.method_8651(NeighbourBlockPos, true, player);

                        toolStack.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
                        if (toolStack.method_7960()) {
                            return;
                }
            }
        }
    }
}
}
}