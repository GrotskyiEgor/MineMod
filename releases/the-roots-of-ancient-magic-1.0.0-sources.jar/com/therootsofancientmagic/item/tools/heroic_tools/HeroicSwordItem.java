package com.therootsofancientmagic.item.tools.heroic_tools;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;

public class HeroicSwordItem extends class_1829 {

    public HeroicSwordItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }
    @Override
    public void method_7888(class_1799 stack, class_1937 world, net.minecraft.class_1297 entity, int slot, boolean selected) {
        if (!world.method_8608() && entity instanceof class_1309 livingEntity) { 

            // Проверяет, держит ли игрок героический топор в руке
            boolean isHoldingInMainHand = selected; 
            boolean isHoldingInOffHand = livingEntity.method_6079() == stack; 

            // Проверяет, держит ли вобще меч в любой руке
            if (isHoldingInMainHand || isHoldingInOffHand) { 
                // Накладивает Силу 2 на игрока
                livingEntity.method_6092(new class_1293(class_1294.field_5910, 2, 1, false, false, true)); 
                
                // Накладивает Огненний Резистенс(стойкость к огню) 2 на игрока
                livingEntity.method_6092(new class_1293(class_1294.field_5918, 2, 1, false, false, true));
            }
        }
        super.method_7888(stack, world, entity, slot, selected); 
    }
    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        if (!attacker.method_37908().method_8608()) {
            // Поджигает цель на 5 секунд
            target.method_5639(5);
            
            // Накладивает замедление 1 на врага при ударе
            target.method_6092(new class_1293(class_1294.field_5909, 80, 0));
        }
        return super.method_7873(stack, target, attacker);
    }
}
