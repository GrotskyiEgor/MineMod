package com.therootsofancientmagic.item.tools.heroic_tools;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public class HeroicPickaxeItem extends class_1810 {
    public HeroicPickaxeItem(class_1832 material, int attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, net.minecraft.class_1297 entity, int slot, boolean selected) {
        if (!world.method_8608() && entity instanceof class_1309 livingEntity) {
            
            // Проверяет, держит ли игрок героическую кирку в руке
            boolean isHoldingInMainHand = selected;
            boolean isHoldingInOffHand = livingEntity.method_6079() == stack;

             // Проверяет, держит ли вобще кирку в любой руке
            if (isHoldingInMainHand || isHoldingInOffHand) {
                // Накладывает Спешку 2 на игрока
                livingEntity.method_6092(new class_1293(class_1294.field_5917, 2, 1, false, false, true));
                // Накладивает ночное зрение на игрока
                livingEntity.method_6092(new class_1293(class_1294.field_5925, 2, 0, false, false, true));
            }
        }
        super.method_7888(stack, world, entity, slot, selected);
    }
    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        if (!world.method_8608() && miner instanceof class_3222 player) {
            
            if (this.method_7856(state)) {
                // Ломание 5 на 5 и еще 1 блок вглубину
                this.breakAreaAndTunnel(world, pos, player, stack, -2, 2, -2, 2, 0, 1);
            }
        }
        return super.method_7879(stack, world, state, pos, miner);
    }
    // Функция которая создает лазер из голови игрока и определяет на какой блок игрок смотрит
    private class_2350 getPlayerDirection(class_3222 player) {
        class_239 hit = player.method_5745(20.0D, 0.0F, false);
        if (hit.method_17783() == class_239.class_240.field_1332) {
            return ((class_3965) hit).method_17780();
        }
        return class_2350.field_11036;
    }

   //функция которая определяет куда смотрит игрок,верх/вниз/влево/вправо и в зависимости от этого ломает блоки вокруг блока на которий игрок нажал
    private class_2338 getTargetBlockPos(class_2338 center, class_2350 face, int gridX, int gridY, int depth) {
        
        class_2338 shiftedCenter = center.method_10079(face.method_10153(), depth);

        if (face == class_2350.field_11036 || face == class_2350.field_11033) {
            return shiftedCenter.method_10069(gridX, 0, gridY);
        } else if (face == class_2350.field_11034 || face == class_2350.field_11039) {
            return shiftedCenter.method_10069(0, gridY, gridX);
        } else {
            return shiftedCenter.method_10069(gridX, gridY, 0);
        }
    }
    // Самая главная функция зачистки: перебирает сетку и копает блоки вглубь
    private void breakAreaAndTunnel(class_1937 world, class_2338 targetPos, class_3222 player, class_1799 toolStack, 
            int minX, int maxX, int minY, int maxY, int minDepth, int maxDepth) {
        
        class_2350 directionSide = getPlayerDirection(player);

        // 3D и 2D сетка, которая определяет какие блоки ломать вокруг блока на которий игрок нажал или вглубину
        for (int depth = minDepth; depth <= maxDepth; depth++) {
            for (int gridX = minX; gridX <= maxX; gridX++) {
                for (int gridY = minY; gridY <= maxY; gridY++) {

                    // Пропускает центральний блок которий игрок сломал
                    if (depth == 0 && gridX == 0 && gridY == 0) continue;

                    // Получает блоки которие возле блока на которий игрок нажал,в зависимости от сторони на которую игрок смотрит(raycast)
                    class_2338 neighbourBlockPos = getTargetBlockPos(targetPos, directionSide, gridX, gridY, depth);
                    class_2680 neighbourBlockState = world.method_8320(neighbourBlockPos);

                    //Проверяет если блок сломать можно, если ето бедрок или воздух,то не ломает
                    if (this.method_7856(neighbourBlockState) && neighbourBlockState.method_26214(world, neighbourBlockPos) >= 0) {
                        world.method_8651(neighbourBlockPos, true, player);
                        //Наносит 1 урон кирке при ломании блока
                        toolStack.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
                        // Если кирка сломалась при копании, цикл перестает копать
                        if (toolStack.method_7960()) {
                            return;
                        }
                    }
                }
            }
        }
}
}