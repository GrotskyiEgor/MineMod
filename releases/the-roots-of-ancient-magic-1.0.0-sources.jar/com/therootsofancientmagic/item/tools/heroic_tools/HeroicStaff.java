package com.therootsofancientmagic.item.tools.heroic_tools;

import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1295;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2388;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class HeroicStaff extends class_1792 {
	private static final int COOLDOWN_TICKS = 1200;
	private static final int DOME_RADIUS = 2;
	private static final double DETECTION_RADIUS = 10.0D;
	private static final int DEBRIS_COUNT = 150;

	private static final Random RANDOM = new Random();

	public HeroicStaff(class_1793 settings) {
		super(settings);
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
		class_1799 stack = user.method_5998(hand);

		if (user.method_7357().method_7904(this)) {
			return class_1271.method_22431(stack);
		}

		if (!world.field_9236 && user instanceof class_3222 serverPlayer) {
			class_3218 serverWorld = (class_3218) world;

			List<class_1309> targets = findNearbyEntities(serverWorld, user);

			if (targets.isEmpty()) {
				return class_1271.method_22431(stack);
			}

			if (!PlayerMana.consumeMana((IEntityDataSaver) serverPlayer, 100, serverPlayer)) {
				return class_1271.method_22431(stack);
			}

			for (class_1309 target : targets) {
				class_2338 centerPos = target.method_24515().method_10086(DOME_RADIUS);

				createObsidianSnowSphere(serverWorld, centerPos);
				spawnImpactEffects(serverWorld, centerPos);
				spawnDragonBreathCloud(serverWorld, centerPos, user);
			}

			world.method_8396(null, user.method_24515(), class_3417.field_14574, class_3419.field_15248, 1.0F, 1.0F);
			user.method_7357().method_7906(this, COOLDOWN_TICKS);
		}

		return class_1271.method_29237(stack, world.field_9236);
	}

	private List<class_1309> findNearbyEntities(class_3218 world, class_1657 user) {
		class_238 box = new class_238(user.method_24515()).method_1014(DETECTION_RADIUS);
		return world.method_8390(
				class_1309.class,
				box,
				e -> e != user && e.method_5858(user) <= DETECTION_RADIUS * DETECTION_RADIUS
		);
	}

	private void createObsidianSnowSphere(class_1937 world, class_2338 centerPos) {
		for (int x = -DOME_RADIUS; x <= DOME_RADIUS; x++) {
			for (int y = -DOME_RADIUS; y <= DOME_RADIUS; y++) {
				for (int z = -DOME_RADIUS; z <= DOME_RADIUS; z++) {
					double distance = Math.sqrt(x * x + y * y + z * z);
					if (distance > DOME_RADIUS + 0.5D) {
						continue;
					}

					class_2338 blockPos = centerPos.method_10069(x, y, z);

					if (distance >= DOME_RADIUS - 0.5D) {
						world.method_8501(blockPos, class_2246.field_10540.method_9564());
					} else {
						world.method_8501(blockPos, class_2246.field_10491.method_9564());
					}
				}
			}
		}
	}

	/**
	 * Создаёт облако дыхания дракона внутри купола: Слабость III и Иссушение.
	 */
	private void spawnDragonBreathCloud(class_3218 world, class_2338 centerPos, class_1657 user) {
		class_1295 cloud = new class_1295(world, centerPos.method_10263() + 0.5, centerPos.method_10264(), centerPos.method_10260() + 0.5);

		cloud.method_5607(user);
		cloud.method_5608(class_2398.field_11216);
		cloud.method_5603((float) DOME_RADIUS + 0.5F);
		cloud.method_5609(-0.2F);
		cloud.method_5595(0);
		cloud.method_5604(200);
		cloud.method_5596(-0.02F);

		cloud.method_5610(new class_1293(class_1294.field_5911, 100, 2));
		cloud.method_5610(new class_1293(class_1294.field_5920, 100, 0));

		world.method_8649(cloud);
	}

	private void spawnImpactEffects(class_3218 world, class_2338 centerPos) {
		class_243 center = class_243.method_24953(centerPos);
		class_2394 obsidianDust = new class_2388(class_2398.field_11217, class_2246.field_10540.method_9564());
		class_2394 snowDust = new class_2388(class_2398.field_11217, class_2246.field_10491.method_9564());

		sphereBurst(world, center, DEBRIS_COUNT, obsidianDust, 0.4);
		sphereBurst(world, center, 100, snowDust, 0.35);
		sphereBurst(world, center, DEBRIS_COUNT / 3, class_2398.field_28013, 0.15);
		groundRing(world, center, DOME_RADIUS + 1.5, 40);

		world.method_8396(null, centerPos, class_3417.field_15081, class_3419.field_15248, 1.2F, 0.5F);
		world.method_8396(null, centerPos, class_3417.field_14671, class_3419.field_15248, 0.8F, 0.8F);
	}

	private void sphereBurst(class_3218 world, class_243 origin, int count, class_2394 particle, double maxSpeed) {
		for (int i = 0; i < count; i++) {
			double u = RANDOM.nextDouble() * 2.0 - 1.0;
			double theta = RANDOM.nextDouble() * Math.PI * 2.0;
			double sqrtTerm = Math.sqrt(1.0 - u * u);

			double dirX = sqrtTerm * Math.cos(theta);
			double dirY = u;
			double dirZ = sqrtTerm * Math.sin(theta);
			double speed = RANDOM.nextDouble() * maxSpeed;

			world.method_14199(particle, origin.field_1352, origin.field_1351, origin.field_1350, 1, dirX * speed, dirY * speed, dirZ * speed, 1.0);
		}
	}

	private void groundRing(class_3218 world, class_243 center, double radius, int count) {
		for (int i = 0; i < count; i++) {
			double angle = (Math.PI * 2.0 * i) / count;
			double dirX = Math.cos(angle);
			double dirZ = Math.sin(angle);

			double x = center.field_1352 + dirX * radius;
			double z = center.field_1350 + dirZ * radius;

			world.method_14199(class_2398.field_11205, x, center.field_1351 - DOME_RADIUS, z, 1, dirX * 0.05, 0.05, dirZ * 0.05, 0.0);
		}
	}
}