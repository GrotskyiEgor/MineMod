package com.therootsofancientmagic.item.tools.heroic_tools;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3481;

public class HeroicAxeItem extends class_1743 {

    public HeroicAxeItem(class_1832 material, float attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    
    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        if (!attacker.method_37908().method_8608()) {
            
            // проверка на крит удар, оно проверяет что игрок не на земле и не лазит по лестнице
            boolean isCritical = attacker.method_18798().field_1351 < 0 
                    && !attacker.method_24828() 
                    && !attacker.method_6101();

            if (isCritical) {
                // При критическом ударе станит врага на 3 секунди
                target.method_6092(new class_1293(class_1294.field_5909, 60, 4));
            } else {
                // Подбрасует врага при обичном ударе как у земляного меча
                target.method_5762(0, 1.0, 0);
                target.field_6037 = true; 
            }
        }

        return super.method_7873(stack, target, attacker);
    }
@Override
    public void method_7888(class_1799 stack, class_1937 world, net.minecraft.class_1297 entity, int slot, boolean selected) {
        if (!world.method_8608() && entity instanceof class_1309 livingEntity) { 

            // Проверяет, держит ли игрок героический топор в руке
            boolean isHoldingInMainHand = selected; 
            boolean isHoldingInOffHand = livingEntity.method_6079() == stack; 

            // Проверяет, держит ли вобще топор в любой руке
            if (isHoldingInMainHand || isHoldingInOffHand) { 
                // Накладивает Скорость 2 на игрока 
                livingEntity.method_6092(new class_1293(class_1294.field_5904, 2, 1, false, false, true)); 
                
                // Накладивает Резистенс(стойкость) 2 на игрока
                livingEntity.method_6092(new class_1293(class_1294.field_5907, 2, 1, false, false, true));
            }
        }
        super.method_7888(stack, world, entity, slot, selected); 
    }

@Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        if (!world.method_8608() && miner instanceof class_3222 player) {
            
            //Проверяет, является ли блок деревом
            if (state.method_26164(class_3481.field_15475)) {
                // Проходит по дереву вверх, начиная с блока, которий бил сломан, просто чтоби найти все блоки дерева в пределах 30 блоков вверх
                for (int y = 1; y <= 30; y++) {
                    // Если топор сломался то дерево перестает ломаться
                    if (stack.method_7960()) break; 

                    boolean foundLogInLayer = false;
                    // Определяет центр дерева, которий ми проверяем
                    class_2338 layerCenter = pos.method_10086(y);
                    
                    // Сетка 5x5 вокруг центра дерева,чтоби найти все блоки дерева в пределах этого слоя
                     for (int x = -2; x <= 2; x++) {
                        for (int z = -2; z <= 2; z++) {
                            // Получает точние координати конкретного блока на этой сетке 3х3
                            class_2338 nextLogPos = layerCenter.method_10069(x, 0, z);
                            // Получает состояние блока на этих координатах
                            class_2680 nextLogState = world.method_8320(nextLogPos);

                           // Проверяет является ли этот блок деревом,если да, то ломает его и наносит урон топору
                            if (nextLogState.method_26164(class_3481.field_15475)) {
                                world.method_8651(nextLogPos, true, player);
                                stack.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
                                // Если блок дерева сломали, то дает значение True
                                foundLogInLayer = true;
                            }
                        }
                    }
                    // Если дерева верху больше нету, например небо началось, то цикл останавливаеться
                    if (!foundLogInLayer) {
                        break; 
                    }
                }
            }
        }

        return super.method_7879(stack, world, state, pos, miner);
    }
}
