package com.therootsofancientmagic.item.tools.heroic_tools;

import com.therootsofancientmagic.item.ModToolMaturial;
import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class HeroicHoeItem extends class_1794 {

    public HeroicHoeItem(class_1832 material, int attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
    @Override
    public void method_7888(class_1799 stack, class_1937 world, net.minecraft.class_1297 entity, int slot, boolean selected) {
        if (!world.method_8608() && entity instanceof class_1309 livingEntity) {
            
            // Проверяет, держит ли игрок героическую кирку в руке
            boolean isHoldingInMainHand = selected;
            boolean isHoldingInOffHand = livingEntity.method_6079() == stack;

             // Проверяет, держит ли вобще кирку в любой руке
            if (isHoldingInMainHand || isHoldingInOffHand) {
                // Накладивает еффект удачи на игрока
                livingEntity.method_6092(new class_1293(class_1294.field_5926, 2, 0, false, false, true));
                // Добавляет игроку +1 сердце, как при поедании золотого яблока
                livingEntity.method_6092(new class_1293(class_1294.field_5898, 60, 0, false, false, true));
            }
        }
        super.method_7888(stack, world, entity, slot, selected);
    }
    // Главний метод как и harvestAndreplant
    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 clickedPos = context.method_8037();
        class_1657 player = context.method_8036();
        class_1799 hoeStack = context.method_8041();
        class_2680 clickedState = world.method_8320(clickedPos);

        if (clickedState.method_26204() instanceof class_2302 clickedCrop && clickedCrop.method_9825(clickedState)) {
            
            if (world.method_8608()) {
                return class_1269.field_5812;
            }

            if (player instanceof class_3222 serverPlayer) {
                
                harvestAndReplantArea(world, clickedPos, serverPlayer, hoeStack, -3, 3, -3, 3);

                return class_1269.field_21466;
            }
        }

        return super.method_7884(context);
    }
        // обрабатывает один конкретный блок, типо (сбор плодов + посадка семечка обратно)
        private boolean tryHarvestAndReplant(class_1937 world, class_2338 pos, class_3222 player, class_1799 hoeStack) { // //
        class_2680 state = world.method_8320(pos);
        
        if (state.method_26204() instanceof class_2302 cropBlock && cropBlock.method_9825(state)) {
            class_1792 seedItem = cropBlock.method_9574(world, pos, state).method_7909();

           //Если семена кончились то преривает харвест и посадку
            if (!player.method_7337() && player.method_31548().method_18861(seedItem) <= 0) {
                return false;
            }
            // Считает лут, который должен был выпасть если би ми все просто собирали 
            List<class_1799> drops = class_2248.method_9609(state, (net.minecraft.class_3218) world, pos, null, player, hoeStack);
            
            for (class_1799 drop : drops) {
                class_2248.method_9577(world, pos, drop);
            }
             // Забирает семена из инвентаре при посадке
            if (!player.method_7337()) {
                player.method_31548().method_29280(stack -> stack.method_7909() == seedItem, 1, player.method_31548());
            }

            world.method_8652(pos, cropBlock.method_9828(0), 3);
            // Тратит 1 прочность мотиги 
            hoeStack.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
        }
        return true;
    }

    private void harvestAndReplantArea(class_1937 world, class_2338 targetPos, class_3222 player, class_1799 hoeStack, int minX, int maxX, int minZ, int maxZ) {
        for (int gridX = minX; gridX <= maxX; gridX++) {
            for (int gridZ = minZ; gridZ <= maxZ; gridZ++) {
                if (hoeStack.method_7960()) return;

                class_2338 neighbourCropPos = targetPos.method_10069(gridX, 0, gridZ);
                // Харвест 7 на 7 или столько сколько есть семян в инвентаре
                if (!tryHarvestAndReplant(world, neighbourCropPos, player, hoeStack)) {
                    return;
                }
            }
        }
    }
}