package com.therootsofancientmagic.item.tools.hoe;

import com.therootsofancientmagic.item.ModToolMaturial;
import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class ElementalHoeItem extends class_1794 {

    public ElementalHoeItem(class_1832 material, int attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
    // Главный метод, который срабатывает, когда игрок нажимает правой кнопкой мыши по любому блоку
    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 clickedPos = context.method_8037();
        class_1657 player = context.method_8036();
        class_1799 hoeStack = context.method_8041();
        class_2680 clickedState = world.method_8320(clickedPos);

        // Проверяет, нажал ли игрок на грядку с выросшим растением
        if (clickedState.method_26204() instanceof class_2302 clickedCrop && clickedCrop.method_9825(clickedState)) {
            if (world.method_8608()) { 
                return class_1269.field_5812;
            }
            if (player instanceof class_3222 serverPlayer) {
                class_1792 seedItem = clickedCrop.method_9574(world, clickedPos, clickedState).method_7909();
                
                // Получаем случайное число для расчета 5% шанса баффов
                float effectChance = player.method_6051().method_43057();
                if (effectChance < 0.05F) {
                    applyElementalBuff(serverPlayer);
                }

                // Смотрит на материал мотиги и вибирает нужний сбор, типо если aqua мотига то 3 блока вперед собирает, если огненная то 3 на 3
                if (this.method_8022() == ModToolMaturial.ESSENCE_AIR || this.method_8022() == ModToolMaturial.ESSENCE_AQUA) {
                    class_2350 playerFacing = serverPlayer.method_5735();

                    // Собирает по прямой линии на 3 блока вперед
                    for (int i = 0; i < 3; i++) {
                        // Если мотига сломалась то цикл прекращаеться
                        if (hoeStack.method_7960()) break;

                        class_2338 nextCropPos = clickedPos.method_10079(playerFacing, i);
                        if (!tryHarvestAndReplant(world, nextCropPos, serverPlayer, hoeStack)) break;
                    }
                }
                // Огненная и Земляная, собирает 3 на 3
                else if (this.method_8022() == ModToolMaturial.ESSENCE_EARTH || this.method_8022() == ModToolMaturial.ESSENCE_FIRE) {
                    harvestAndReplantArea(world, clickedPos, serverPlayer, hoeStack, -1, 1, -1, 1);
                }
                // Дарк и Лайт, собирает 5 на 5
                else if (this.method_8022() == ModToolMaturial.ESSENCE_DARK || this.method_8022() == ModToolMaturial.ESSENCE_LIGHT) {
                    harvestAndReplantArea(world, clickedPos, serverPlayer, hoeStack, -2, 2, -2, 2);
                }
                return class_1269.field_21466;
            }
        }
        return super.method_7884(context);
    }

    // Налаживаем ефект в зависимости от мотиги
    private void applyElementalBuff(class_3222 player) {
        if (this.method_8022() == ModToolMaturial.ESSENCE_AIR) {
            player.method_6092(new class_1293(class_1294.field_5904, 600, 0));
        } else if (this.method_8022() == ModToolMaturial.ESSENCE_AQUA) {
            player.method_6092(new class_1293(class_1294.field_5923, 600, 0));
        } else if (this.method_8022() == ModToolMaturial.ESSENCE_DARK || this.method_8022() == ModToolMaturial.ESSENCE_LIGHT) {
            player.method_6092(new class_1293(class_1294.field_5925, 600, 0));
        } else if (this.method_8022() == ModToolMaturial.ESSENCE_EARTH) {
            player.method_6092(new class_1293(class_1294.field_5917, 600, 0));
        } else if (this.method_8022() == ModToolMaturial.ESSENCE_FIRE) {
            player.method_6092(new class_1293(class_1294.field_5918, 600, 0));
        }
    }
    
    // обрабатывает один конкретный блок, типо (сбор плодов + посадка семечка обратно)
    private boolean tryHarvestAndReplant(class_1937 world, class_2338 pos, class_3222 player, class_1799 hoeStack) {
        class_2680 state = world.method_8320(pos);
        
        // Опять проверяет что перед нами созревший урожай
        if (state.method_26204() instanceof class_2302 cropBlock && cropBlock.method_9825(state)) {
            class_1792 seedItem = cropBlock.method_9574(world, pos, state).method_7909();
            
            // Проверяет если ли игрок в креативе, если нет то ищет семечко в инвентаре
           if (!player.method_7337() && player.method_31548().method_18861(seedItem) <= 0) {
                return false;
            }
                // Считает лут, который должен был выпасть если би ми все просто собирали 
                List<class_1799> drops = class_2248.method_9609(state, (net.minecraft.class_3218) world, pos, null, player, hoeStack);
                    
                for (class_1799 drop : drops) {
                    class_2248.method_9577(world, pos, drop);
                }
                // Забирает семена из инвентаре при посадке
                if (!player.method_7337()) {
                    player.method_31548().method_29280(stack -> stack.method_7909() == seedItem, 1, player.method_31548());
                }
                world.method_8652(pos, cropBlock.method_9828(0), 3);

                // Тратит 1 прочность мотиги
                hoeStack.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
            }
            return true;
        }
    

    //Перебор координатной сетки
    private void harvestAndReplantArea(class_1937 world, class_2338 targetPos, class_3222 player, class_1799 hoeStack, int minX, int maxX, int minZ, int maxZ) {
        for (int gridX = minX; gridX <= maxX; gridX++) {
            for (int gridZ = minZ; gridZ <= maxZ; gridZ++) {
                // Останавливает цикл при ломании мотиги
                if (hoeStack.method_7960()) return;
                // Находит соседний блок
                class_2338 neighbourCropPos = targetPos.method_10069(gridX, 0, gridZ);
                // Собирает и пересаживает
                if (!tryHarvestAndReplant(world, neighbourCropPos, player, hoeStack)) {
                    return;
                }
            }
        }
    }
}