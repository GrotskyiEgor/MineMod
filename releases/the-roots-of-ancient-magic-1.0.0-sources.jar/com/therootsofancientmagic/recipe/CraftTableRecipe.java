package com.therootsofancientmagic.recipe;

import com.google.gson.JsonObject;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class CraftTableRecipe implements class_3955 {

    private final class_1869 wrapped;

    public CraftTableRecipe(class_1869 wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public boolean matches(class_8566 inventory, class_1937 world) {
        return this.wrapped.method_17728(inventory, world);
    }

    @Override
    public class_1799 craft(class_8566 inventory, class_5455 registryManager) {
        return this.wrapped.method_17727(inventory, registryManager);
    }

    @Override
    public boolean method_8113(int width, int height) {
        return this.wrapped.method_8113(width, height);
    }

    @Override
    public class_1799 method_8110(class_5455 registryManager) {
        return this.wrapped.method_8110(registryManager);
    }

    @Override
    public class_2371<class_1856> method_8117() {
        return this.wrapped.method_8117();
    }

    @Override
    public String method_8112() {
        return this.wrapped.method_8112();
    }

    @Override
    public class_7710 method_45441() {
        return this.wrapped.method_45441();
    }

    @Override
    public class_2960 method_8114() {
        return this.wrapped.method_8114();
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipes.CRAFT_TABLE_SERIALIZER;
    }

    @Override
    public class_3956<?> method_17716() {
        return ModRecipes.CUSTOM_CRAFTING_TYPE;
    }

    public static class Serializer implements class_1865<CraftTableRecipe> {

        @Override
        public CraftTableRecipe method_8121(class_2960 id, JsonObject json) {
            class_1869 shaped = class_1865.field_9035.method_8121(id, json);
            return new CraftTableRecipe(shaped);
        }

        @Override
        public CraftTableRecipe method_8122(class_2960 id, class_2540 buf) {
            class_1869 shaped = class_1865.field_9035.method_8122(id, buf);
            return new CraftTableRecipe(shaped);
        }

        @Override
        public void write(class_2540 buf, CraftTableRecipe recipe) {
            class_1865.field_9035.method_8124(buf, recipe.wrapped);
        }
    }
}
