package com.therootsofancientmagic.recipe;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public class ModRecipes {

    public static final class_3956<class_3955> CUSTOM_CRAFTING_TYPE = class_2378.method_10230(
        class_7923.field_41188,
        new class_2960(TheRootsOfAncientMagic.MOD_ID, "craft_table"),
        new class_3956<class_3955>() {
            @Override
            public String toString() {
                return "craft_table";
            }
        }
    );

    public static final class_1865<CraftTableRecipe> CRAFT_TABLE_SERIALIZER = class_2378.method_10230(
        class_7923.field_41189,
        new class_2960(TheRootsOfAncientMagic.MOD_ID, "craft_table"),
        new CraftTableRecipe.Serializer()
    );

    public static void registerRecipes() {
        TheRootsOfAncientMagic.LOGGER.info("Registering Custom Recipes for " + TheRootsOfAncientMagic.MOD_ID);
    }
}
