package com.therootsofancientmagic.mana; // Путь к нашей папке mana

import com.therootsofancientmagic.util.IEntityDataSaver;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Unique;

import com.therootsofancientmagic.network.ModMessages; // Импортируем нашу сетевую систему

public class PlayerMana {
    private static final int MAX_MANA = 100; 
    private static final int MANA_REGEN_TICK_DELAY = 20; 

    // Метод добавления мани
    public static void addMana(IEntityDataSaver player, int amount, class_3222 serverPlayer) {
        class_2487 nbt = player.getPersistentData();
        int currentMana = nbt.method_10550("mana");
        int finalMana;

        // Прибавляем ману,но чтоби не било больше 100
        if (currentMana + amount >= MAX_MANA) {
            finalMana = MAX_MANA;
        } else {
            finalMana = currentMana + amount;
        }
        
        nbt.method_10569("mana", finalMana);
        ModMessages.sendToClient(serverPlayer, finalMana);
    }

    // Метод трати мани
    public static boolean consumeMana(IEntityDataSaver player, int amount, class_3222 serverPlayer) {
        class_2487 nbt = player.getPersistentData();
        int currentMana = nbt.method_10550("mana");


        if (currentMana >= amount) {
            int finalMana = currentMana - amount;
            nbt.method_10569("mana", finalMana);
            
            ModMessages.sendToClient(serverPlayer, finalMana);
            return true;
        }
        return false;
    }

    @Unique
    public static boolean tryConsumeMana(class_1657 player, int mana_cost) {
        if (!(player instanceof class_3222 serverPlayer)) {
            return false;
        }

        return PlayerMana.consumeMana(
                (IEntityDataSaver) serverPlayer,
                mana_cost,
                serverPlayer
        );
    }

    // Пассивная регенерация мани
    public static void regenerateMana(class_3222 player) {
        IEntityDataSaver dataSaver = (IEntityDataSaver) player;
        class_2487 nbt = dataSaver.getPersistentData();
        
        int regenTimer = nbt.method_10550("mana_regen_timer");
        int currentMana = nbt.method_10550("mana");

        // Проверяем, нужно ли регенить ману
        if (currentMana < MAX_MANA) {
            if (regenTimer >= MANA_REGEN_TICK_DELAY) {
                addMana(dataSaver, 10, player); 
                nbt.method_10569("mana_regen_timer", 0);
            } else {
                nbt.method_10569("mana_regen_timer", regenTimer + 1);
            }
        } else {
            nbt.method_10569("mana_regen_timer", 0);
        }
    }
}
