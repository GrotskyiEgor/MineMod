package com.therootsofancientmagic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.therootsofancientmagic.biome.ModBiomes;
import com.therootsofancientmagic.block.ModBlock;
import com.therootsofancientmagic.block.ModFlowerBlock;
import com.therootsofancientmagic.block.entity.ModBlockEntities;
import com.therootsofancientmagic.client.ModTooltips;
import com.therootsofancientmagic.entity.ModEntities;
import com.therootsofancientmagic.init.worldgen.PlacedFeatureInit;
import com.therootsofancientmagic.item.ModItem;
import com.therootsofancientmagic.item.ModItemGroups;
import com.therootsofancientmagic.network.RobeAbilityServerHandler;
import com.therootsofancientmagic.recipe.ModRecipes;
import com.therootsofancientmagic.screen.CraftTableScreen;
import com.therootsofancientmagic.screen.FurnacePowderScreen;
import com.therootsofancientmagic.screen.ModScreenHandlers;
import com.therootsofancientmagic.util.AccessoryHandler;
// import com.therootsofancientmagic.block.entity.ModBlockEntities;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3929;
import net.minecraft.class_5321;
import net.minecraft.class_6796;


public class TheRootsOfAncientMagic implements ModInitializer {
    public static final String MOD_ID = "the-roots-of-ancient-magic";

    public static final Logger LOGGER =
            LoggerFactory.getLogger(MOD_ID);
            
    @Override
    public void onInitialize() {
        
        com.therootsofancientmagic.network.ModMessages.registerC2SPackets();
        ModItemGroups.registerItemGroups();

        ModItem.registerModItems();
        ModTooltips.register();
        ModBlock.registerModBlocks();
        ModFlowerBlock.registerModBlocks();
        ModFlowerBlock.RenderFlowers();
        ModRecipes.registerRecipes();

        ModEntities.registerModEntities();
        ModBlockEntities.registerBlockEntities();
        ModScreenHandlers.registerScreenHandlers();

        RobeAbilityServerHandler.register();

        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                AccessoryHandler.applyAccessoryEffects(player);
                com.therootsofancientmagic.mana.PlayerMana.regenerateMana(player);
            }
        });
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            net.minecraft.class_3222 player = handler.method_32311();
            if (player instanceof com.therootsofancientmagic.util.IEntityDataSaver dataSaver) {
                int currentMana = dataSaver.getPersistentData().method_10550("mana");
                com.therootsofancientmagic.network.ModMessages.sendToClient(player, currentMana);
            }
        });

        class_3929.method_17542(ModScreenHandlers.FURNACE_POWDER_SCREEN_HANDLER, FurnacePowderScreen::new);
        class_3929.method_17542(ModScreenHandlers.CRAFT_TABLE_SCREEN_HANDLER, CraftTableScreen::new);
        
        
	    registerFlowers();
    }

    
    public static class_2960 id(String path) {
        return new class_2960(MOD_ID, path);
    }
    
    public void registerFlowers() {
        registerFlowerInBiome(PlacedFeatureInit.FLOWER_DARK_PLACED_KEY, ModBiomes.DARK);
        registerFlowerInBiome(PlacedFeatureInit.FLOWER_LIGHT_PLACED_KEY, ModBiomes.LIGHT);
        registerFlowerInBiome(PlacedFeatureInit.FLOWER_AIR_PLACED_KEY, ModBiomes.AIR);
        registerFlowerInBiome(PlacedFeatureInit.FLOWER_EARTH_PLACED_KEY, ModBiomes.EARTH);
        registerFlowerInBiome(PlacedFeatureInit.FLOWER_FIRE_PLACED_KEY, ModBiomes.FIRE);
        registerFlowerInBiome(PlacedFeatureInit.FLOWER_AQUA_PLACED_KEY, ModBiomes.AQUA);
    }

    private void registerFlowerInBiome(class_5321<class_6796> flowerKey, class_5321<class_1959> biomeKey) {
        BiomeModifications.addFeature(
                BiomeSelectors.includeByKey(biomeKey),
                class_2893.class_2895.field_13178,
                flowerKey
        );
    }
}