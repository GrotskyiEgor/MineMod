package com.therootsofancientmagic.component;

import net.minecraft.class_1263;

public interface CustomArmorHolder {
    class_1263 getCustomArmorInventory();
    void useFirstRingAbility();
    void useSecondRingAbility();
    
    default void ActivateAquaRobeAbility() {}
    default void ActivateFireRobeAbility() {}
    default void activateFireRobeAbility() {}
}
