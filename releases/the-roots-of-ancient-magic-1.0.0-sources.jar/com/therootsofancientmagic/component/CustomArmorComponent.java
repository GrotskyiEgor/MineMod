package com.therootsofancientmagic.component;

import net.minecraft.class_1277;
import net.minecraft.class_2487;
import net.minecraft.class_2499;

public class CustomArmorComponent {
    private final class_1277 inventory = new class_1277(4);

    public class_1277 getInventory() {
        return inventory;
    }

    public void readNbt(class_2487 tag) {
        if (tag.method_10573("CustomArmor", 9)) {
            class_2499 list = tag.method_10554("CustomArmor", 10);
            for (int i = 0; i < list.size(); i++) {
                class_2487 itemTag = list.method_10602(i);
                int slot = itemTag.method_10571("Slot") & 255;
                if (slot < inventory.method_5439()) {
                    inventory.method_5447(slot, net.minecraft.class_1799.method_7915(itemTag));
                }
            }
        }
    }

    public void writeNbt(class_2487 tag) {
        class_2499 list = new class_2499();
        for (int i = 0; i < inventory.method_5439(); i++) {
            if (!inventory.method_5438(i).method_7960()) {
                class_2487 itemTag = new class_2487();
                itemTag.method_10567("Slot", (byte) i);
                inventory.method_5438(i).method_7953(itemTag);
                list.add(itemTag);
            }
        }
        tag.method_10566("CustomArmor", list);
    }
}