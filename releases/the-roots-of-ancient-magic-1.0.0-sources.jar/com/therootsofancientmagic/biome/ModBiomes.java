package com.therootsofancientmagic.biome;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.minecraft.class_1959;
import net.minecraft.class_2922;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class ModBiomes {

    public static final class_5321<class_1959> DARK = key("dark");
    public static final class_5321<class_1959> LIGHT = key("light");
    public static final class_5321<class_1959> AIR = key("air");
    public static final class_5321<class_1959> EARTH = key("earth");
    public static final class_5321<class_1959> FIRE = key("fire");
    public static final class_5321<class_1959> AQUA = key("aqua");

    private static class_5321<class_1959> key(String path) {
        return class_5321.method_29179(
                class_7924.field_41236,
                TheRootsOfAncientMagic.id(path)
        );
    }

    public static void bootstrap(class_7891<class_1959> context) {

        class_7871<class_6796> featureLookup =
                context.method_46799(class_7924.field_41245);

        class_7871<class_2922<?>> carverLookup =
                context.method_46799(class_7924.field_41238);

        context.method_46838(
                DARK,
                DarkBiome.create(featureLookup, carverLookup)
        );

        context.method_46838(
                LIGHT,
                LightBiome.create(featureLookup, carverLookup)
        );

        context.method_46838(
                AIR,
                AirBiome.create(featureLookup, carverLookup)
        );

        context.method_46838(
                EARTH,
                EarthBiome.create(featureLookup, carverLookup)
        );

        context.method_46838(
                FIRE,
                FireBiome.create(featureLookup, carverLookup)
        );

        context.method_46838(
                AQUA,
                AquaBiome.create(featureLookup, carverLookup)
        );
    }
}