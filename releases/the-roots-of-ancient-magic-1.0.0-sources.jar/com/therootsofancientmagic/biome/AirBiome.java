package com.therootsofancientmagic.biome;

import net.minecraft.class_1959;
import net.minecraft.class_2922;
import net.minecraft.class_3864;
import net.minecraft.class_4763;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_7871;

public class AirBiome {

    public static class_1959 create(
            class_7871<class_6796> featureLookup,
            class_7871<class_2922<?>> carverLookup
    ) {

        class_5485.class_5495 generationSettings =
                new class_5485.class_5495(
                        featureLookup,
                        carverLookup
                );

        class_3864.method_16983(generationSettings);
        class_3864.method_32236(generationSettings);
        class_3864.method_38568(generationSettings);

        class_3864.method_17023(generationSettings);
        class_3864.method_16968(generationSettings);

        class_3864.method_16996(generationSettings);

        class_5483.class_5496 spawnSettings =
                new class_5483.class_5496();

        class_3864.method_30580(spawnSettings);
        class_3864.method_30581(spawnSettings);

        return new class_1959.class_1960()
        .method_48164(true)
        .method_8747(0.6F)
        .method_8727(0.5F)
        .method_24379(
                new class_4763.class_4764()
                        .method_24395(0x32D583)
                        .method_24397(0x168A4A)
                        .method_24392(0xB8FFB8)
                        .method_30820(0x87E887)
                        .method_30822(0x20E820)
                        .method_30821(0x0FAF32)
                        .method_24391()
        )
        .method_30974(spawnSettings.method_31007())
        .method_30973(generationSettings.method_46671())
        .method_30972();
    }
}