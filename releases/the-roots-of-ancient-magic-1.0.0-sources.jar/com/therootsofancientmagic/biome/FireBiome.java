package com.therootsofancientmagic.biome;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_3864;
import net.minecraft.class_4763;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_7871;
import net.minecraft.class_7924;

public class FireBiome {

    public static class_1959 create(
            class_7871<class_6796> featureLookup,
            class_7871<class_2922<?>> carverLookup
    ) {
        class_5485.class_5495 generationSettings =
                new class_5485.class_5495(
                        featureLookup,
                        carverLookup
                );

        class_3864.method_16983(generationSettings);
        class_3864.method_38568(generationSettings);

        class_3864.method_16968(generationSettings);

        addFeature(
                generationSettings,
                featureLookup,
                "flower_fire_placed",
                class_2893.class_2895.field_13178
        );

        addFeature(
                generationSettings,
                featureLookup,
                "fire_lava_lake",
                class_2893.class_2895.field_25186
        );

        addFeature(
                generationSettings,
                featureLookup,
                "fire_acacia",
                class_2893.class_2895.field_13178
        );

        class_5483.class_5496 spawnSettings =
                new class_5483.class_5496();

        return new class_1959.class_1960()
                .method_48164(false)
                .method_8747(2.0F)
                .method_8727(0.0F)
                .method_24379(
                        new class_4763.class_4764()
                                .method_24395(0xD84315)
                                .method_24397(0x7F1D0C)
                                .method_24392(0xD8896B)
                                .method_30820(0xC96B45)
                                .method_30822(0xA63D2F)
                                .method_30821(0x8B321F)
                                .method_24391()
                )
                .method_30974(spawnSettings.method_31007())
                .method_30973(generationSettings.method_46671())
                .method_30972();
    }

    private static void addFeature(
            class_5485.class_5495 gen,
            class_7871<class_6796> featureLookup,
            String id,
            class_2893.class_2895 step
    ) {
        gen.method_46676(
                step,
                featureLookup.method_46747(
                        class_5321.method_29179(
                                class_7924.field_41245,
                                TheRootsOfAncientMagic.id(id)
                        )
                )
        );
    }
}