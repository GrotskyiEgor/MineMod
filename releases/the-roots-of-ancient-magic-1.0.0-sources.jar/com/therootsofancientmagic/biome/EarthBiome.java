package com.therootsofancientmagic.biome;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_2960;
import net.minecraft.class_3864;
import net.minecraft.class_4763;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_7871;
import net.minecraft.class_7924;

public class EarthBiome {

    public static class_1959 create(
            class_7871<class_6796> featureLookup,
            class_7871<class_2922<?>> carverLookup
    ) {

        class_5485.class_5495 generationSettings =
                new class_5485.class_5495(
                        featureLookup,
                        carverLookup
                );

        // Пещеры
        class_3864.method_16983(generationSettings);

        // Геоды
        class_3864.method_32236(generationSettings);

        // Руды
        class_3864.method_38568(generationSettings);

        // Подземелья
        class_3864.method_17004(generationSettings);

        // 🌿 ТРАВА
        addVanillaFeature(
                generationSettings,
                featureLookup,
                "patch_grass_plain"
        );

        // 🌳 ТВОЁ ДЕРЕВО
        addModFeature(
                generationSettings,
                featureLookup,
                "earth_dark_oak"
        );

        // 🍄 ТВОИ ГРИБЫ
        addModFeature(
                generationSettings,
                featureLookup,
                "earth_brown_mushroom"
        );

        addModFeature(
                generationSettings,
                featureLookup,
                "earth_huge_brown_mushroom"
        );

        // Источники воды/лавы
        class_3864.method_16996(generationSettings);

        class_5483.class_5496 spawnSettings =
                new class_5483.class_5496();

        class_3864.method_30580(spawnSettings);
        class_3864.method_30581(spawnSettings);

        return new class_1959.class_1960()
                .method_48164(true)
                .method_8747(0.5F)
                .method_8727(1.0F)
                .method_24379(
                        new class_4763.class_4764()
                                .method_24395(0x3F7180)
                                .method_24397(0x304F58)
                                .method_24392(0x777A78)
                                .method_30820(0x777A7D)
                                .method_30822(0x77786E)
                                .method_30821(0x5F6259)
                                .method_24391()
                )
                .method_30974(spawnSettings.method_31007())
                .method_30973(generationSettings.method_46671())
                .method_30972();
    }

    private static void addVanillaFeature(
            class_5485.class_5495 gen,
            class_7871<class_6796> featureLookup,
            String featureId
    ) {
        gen.method_46676(
                class_2893.class_2895.field_13178,
                featureLookup.method_46747(
                        class_5321.method_29179(
                                class_7924.field_41245,
                                class_2960.method_43902(
                                        "minecraft",
                                        featureId
                                )
                        )
                )
        );
    }

    private static void addModFeature(
            class_5485.class_5495 gen,
            class_7871<class_6796> featureLookup,
            String featureId
    ) {
        gen.method_46676(
                class_2893.class_2895.field_13178,
                featureLookup.method_46747(
                        class_5321.method_29179(
                                class_7924.field_41245,
                                TheRootsOfAncientMagic.id(featureId)
                        )
                )
        );
    }
}