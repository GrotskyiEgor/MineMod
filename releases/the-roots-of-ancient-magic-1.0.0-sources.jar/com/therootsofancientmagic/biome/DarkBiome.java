package com.therootsofancientmagic.biome;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_3864;
import net.minecraft.class_4763;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_7871;
import net.minecraft.class_7924;

public class DarkBiome {

    public static class_1959 create(
            class_7871<class_6796> featureLookup,
            class_7871<class_2922<?>> carverLookup
    ) {
        class_5485.class_5495 generationSettings =
                new class_5485.class_5495(
                        featureLookup,
                        carverLookup
                );

        class_3864.method_16983(generationSettings);
        class_3864.method_32236(generationSettings);
        class_3864.method_38568(generationSettings);
        class_3864.method_17004(generationSettings);
        class_3864.method_16980(generationSettings);

        generationSettings.method_46676(
                class_2893.class_2895.field_13178,
                featureLookup.method_46747(
                        class_5321.method_29179(
                                class_7924.field_41245,
                                TheRootsOfAncientMagic.id("dark_spruce")
                        )
                )
        );

        generationSettings.method_46676(
                class_2893.class_2895.field_13178,
                featureLookup.method_46747(
                        class_5321.method_29179(
                                class_7924.field_41245,
                                TheRootsOfAncientMagic.id("dark_red_mushroom")
                        )
                )
        );

        class_3864.method_16996(generationSettings);

        class_5483.class_5496 spawnSettings =
                new class_5483.class_5496();

        class_3864.method_30580(spawnSettings);
        class_3864.method_30581(spawnSettings);

        return new class_1959.class_1960()
                .method_48164(true)
                .method_8747(0.15F)
                .method_8727(0.9F)
                .method_24379(
                        new class_4763.class_4764()
                                .method_24395(0x6A3FA0)
                                .method_24397(0x3A1F5C)
                                .method_24392(0x5A3A7A)
                                .method_30820(0x7B4FB3)
                                .method_30822(0xA855F7)
                                .method_30821(0x9333EA)
                                .method_24391()
                )
                .method_30974(spawnSettings.method_31007())
                .method_30973(generationSettings.method_46671())
                .method_30972();
    }
}