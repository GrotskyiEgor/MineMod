package com.therootsofancientmagic.util;

import com.therootsofancientmagic.component.CustomArmorHolder;
import com.therootsofancientmagic.item.magic.necklace.NecklaceItem;
import com.therootsofancientmagic.item.magic.ring.RingItem;
import net.minecraft.class_1263;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

public class AccessoryHandler {

    public static void applyAccessoryEffects(class_3222 player) {
        if (!(player instanceof CustomArmorHolder holder)) return;
        class_1263 inv = holder.getCustomArmorInventory();

        class_1799 necklaceStack = inv.method_5438(1);
        if (!necklaceStack.method_7960() && necklaceStack.method_7909() instanceof NecklaceItem) {
            if (player.method_7344().method_7586() < 20) {
                player.method_7344().method_7580(20);
                player.method_7344().method_7581(5.0f);
            }
        }

        class_1324 maxHealth = player.method_5996(class_5134.field_23716);
        if (maxHealth != null) {
            boolean hasRing1 = inv.method_5438(2).method_7909() instanceof RingItem;
            boolean hasRing2 = inv.method_5438(3).method_7909() instanceof RingItem;

            boolean containsModifier1 = maxHealth.method_6199(RingItem.RING_1_MODIFIER_ID) != null;
            if (hasRing1 && !containsModifier1) {
                maxHealth.method_26835(new class_1322(
                        RingItem.RING_1_MODIFIER_ID, "Ring Health 1", 4.0, class_1322.class_1323.field_6328));
            } else if (!hasRing1 && containsModifier1) {
                maxHealth.method_6200(RingItem.RING_1_MODIFIER_ID);
            }

            boolean containsModifier2 = maxHealth.method_6199(RingItem.RING_2_MODIFIER_ID) != null;
            if (hasRing2 && !containsModifier2) {
                maxHealth.method_26835(new class_1322(
                        RingItem.RING_2_MODIFIER_ID, "Ring Health 2", 4.0, class_1322.class_1323.field_6328));
            } else if (!hasRing2 && containsModifier2) {
                maxHealth.method_6200(RingItem.RING_2_MODIFIER_ID);
            }

            if (player.method_6032() > player.method_6063()) {
                player.method_6033(player.method_6063());
            }
        }
    }
}