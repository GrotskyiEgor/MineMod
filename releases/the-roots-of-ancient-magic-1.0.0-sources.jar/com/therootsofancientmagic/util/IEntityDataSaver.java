package com.therootsofancientmagic.util;
import net.minecraft.class_2487;

public interface IEntityDataSaver {
    // Этот метод будет возвращать скр ит ий карман NBT данн их у игрока
    class_2487 getPersistentData();
}
