package com.therootsofancientmagic.block;

import com.therootsofancientmagic.block.custom.FurnacePowderBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import com.therootsofancientmagic.block.custom.CraftTableBlock;

public class ModBlock {
    public static final class_2248 NEW_BLOCK = registerBlock(
        "new_block",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10340))
    );

    public static final class_2248 FURNACE_POWDER = registerBlock("furnace_powder",
        new FurnacePowderBlock(class_4970.class_2251.method_9630(class_2246.field_10085).method_22488())
    );

    public static final class_2248 CRAFT_TABLE = registerBlock("craft_table",
        new CraftTableBlock(class_4970.class_2251.method_9630(class_2246.field_10085).method_22488())
    );
    
    public static class_2248 registerBlock(String name, class_2248 block){
        class_2378.method_10230(
            class_7923.field_41175, 
            class_2960.method_43902("the-roots-of-ancient-magic", name),
            block
        );
        
        class_2378.method_10230(
            class_7923.field_41178, 
            class_2960.method_43902("the-roots-of-ancient-magic", name),
            new class_1747(block, new class_1792.class_1793())
        );

        return block;
    }

    public static void registerModBlocks(){
    }
}
