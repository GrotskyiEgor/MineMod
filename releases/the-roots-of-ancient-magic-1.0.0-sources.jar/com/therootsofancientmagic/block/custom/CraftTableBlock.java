package com.therootsofancientmagic.block.custom;

import com.therootsofancientmagic.screen.CraftTableScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3914;
import net.minecraft.class_3965;

public class CraftTableBlock extends class_2248 {

    private static final class_2561 TITLE = class_2561.method_43470("Craft Table");

    public CraftTableBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.field_9236) {
            return class_1269.field_5812;
        } else {
            player.method_17355(state.method_26196(world, pos));
            return class_1269.field_21466;
        }
    }

    @Override
    public class_3908 method_17454(class_2680 state, class_1937 world, class_2338 pos) {
        return new ExtendedScreenHandlerFactory() {
            @Override
            public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
                buf.method_10807(pos);
            }

            @Override
            public class_2561 method_5476() {
                return TITLE;
            }

            @Override
            public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
                return new CraftTableScreenHandler(syncId, playerInventory, class_3914.method_17392(world, pos));
            }
        };
    }
}