package com.therootsofancientmagic.block;

import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1921;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2356;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class ModFlowerBlock {
    public static void RenderFlowers() {
        BlockRenderLayerMap.INSTANCE.putBlock(ModFlowerBlock.FLOWER_DARK, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(ModFlowerBlock.FLOWER_LIGHT, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(ModFlowerBlock.FLOWER_AQUA, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(ModFlowerBlock.FLOWER_FIRE, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(ModFlowerBlock.FLOWER_EARTH, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(ModFlowerBlock.FLOWER_AIR, class_1921.method_23581());
    }

    public static final class_2248 FLOWER_DARK = registerBlock(
        "flower_dark",
        new class_2356(
            class_1294.field_5926,
            0,
            class_4970.class_2251.method_9637()
                .method_9634()      
                .method_9618()   
                .method_22488()
        )
    );

    // public static final Block FLOWER_DARK_POT

    public static final class_2248 FLOWER_LIGHT = registerBlock(
        "flower_light",
        new class_2356(
            class_1294.field_5926,
            0,
            class_4970.class_2251.method_9637()
                .method_9634()      
                .method_9618()
                .method_22488() 
        )
    );

    public static final class_2248 FLOWER_AQUA = registerBlock(
        "flower_aqua",
        new class_2356(
            class_1294.field_5926,
            0,
            class_4970.class_2251.method_9637()
                .method_9634()      
                .method_9618()
                .method_22488() 
        )
    );

    public static final class_2248 FLOWER_FIRE = registerBlock(
        "flower_fire",
        new class_2356(
            class_1294.field_5926,
            0,
            class_4970.class_2251.method_9637()
                .method_9634()
                .method_9618()
                .method_22488()
        ) {
            @Override
            protected boolean method_9695(
                    class_2680 floor,
                    class_1922 world,
                    class_2338 pos
            ) {
                return floor.method_27852(class_2246.field_10102)
                        || floor.method_27852(class_2246.field_10534)
                        || super.method_9695(floor, world, pos);
            }
        }
    );

    public static final class_2248 FLOWER_EARTH = registerBlock(
        "flower_earth",
        new class_2356(
            class_1294.field_5926,
            0,
            class_4970.class_2251.method_9637()
                .method_9634()      
                .method_9618()   
                .method_22488()
        )
    );

    public static final class_2248 FLOWER_AIR = registerBlock(
        "flower_air",
        new class_2356(
            class_1294.field_5926,
            0,
            class_4970.class_2251.method_9637()
                .method_9634()      
                .method_9618()   
                .method_22488()
        )
    );
        
    public static class_2248 registerBlock(String name, class_2248 block){
        class_2378.method_10230(
            class_7923.field_41175, 
            class_2960.method_43902("the-roots-of-ancient-magic", name),
            block
        );
        
        class_2378.method_10230(
            class_7923.field_41178, 
            class_2960.method_43902("the-roots-of-ancient-magic", name),
            new class_1747(block, new class_1792.class_1793())
        );

        return block;
    }

    public static void registerModBlocks(){
    }
}
