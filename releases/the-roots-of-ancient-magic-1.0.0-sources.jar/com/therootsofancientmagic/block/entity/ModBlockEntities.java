package com.therootsofancientmagic.block.entity;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import com.therootsofancientmagic.TheRootsOfAncientMagic;
import com.therootsofancientmagic.block.ModBlock;

public class ModBlockEntities {
    public static final class_2591<FurnacePowderBlockEntity> FURNACE_POWDER_BLOCK_ENTITY =
            class_2378.method_10230(class_7923.field_41181, new class_2960(TheRootsOfAncientMagic.MOD_ID, "furnace_powder_be"),
                    FabricBlockEntityTypeBuilder.create(FurnacePowderBlockEntity::new, ModBlock.FURNACE_POWDER).build());

    public static final class_2591<CraftTableBlockEntity> CRAFT_TABLE_BLOCK_ENTITY =
            class_2378.method_10230(class_7923.field_41181, new class_2960(TheRootsOfAncientMagic.MOD_ID, "craft_table_be"),
                    FabricBlockEntityTypeBuilder.create(CraftTableBlockEntity::new, ModBlock.CRAFT_TABLE).build());

    public static void registerBlockEntities() {
        TheRootsOfAncientMagic.LOGGER.info("Registering Block Entities for " + TheRootsOfAncientMagic.MOD_ID);
    }
}