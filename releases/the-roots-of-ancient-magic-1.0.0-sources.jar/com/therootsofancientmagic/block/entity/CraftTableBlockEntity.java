package com.therootsofancientmagic.block.entity;

import com.therootsofancientmagic.screen.CraftTableScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3914;
import org.jetbrains.annotations.Nullable;

public class CraftTableBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory {

    public CraftTableBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CRAFT_TABLE_BLOCK_ENTITY, pos, state);
    }

    @Override
    public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
        buf.method_10807(this.field_11867);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470("Craft Table");
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new CraftTableScreenHandler(syncId, playerInventory, class_3914.method_17392(this.field_11863, this.field_11867));
    }
}