package com.therootsofancientmagic.block.entity;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import com.therootsofancientmagic.item.ModItem;
import com.therootsofancientmagic.block.ModFlowerBlock;
import com.therootsofancientmagic.util.ImplementedInventory;
import com.therootsofancientmagic.screen.FurnacePowderScreenHandler;
import org.jetbrains.annotations.Nullable;

public class FurnacePowderBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory, ImplementedInventory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(2, class_1799.field_8037);

    private static final int INPUT_SLOT = 0;
    private static final int OUTPUT_SLOT = 1;

    protected final class_3913 propertyDelegate;
    private int progress = 0;
    private int maxProgress = 72;

    public FurnacePowderBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.FURNACE_POWDER_BLOCK_ENTITY, pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> FurnacePowderBlockEntity.this.progress;
                    case 1 -> FurnacePowderBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0 -> FurnacePowderBlockEntity.this.progress = value;
                    case 1 -> FurnacePowderBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    @Override
    public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
        buf.method_10807(this.field_11867);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470("Furnace Powder");
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
        nbt.method_10569("furnace_powder.progress", progress);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        class_1262.method_5429(nbt, inventory);
        progress = nbt.method_10550("furnace_powder.progress");
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new FurnacePowderScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if(world.method_8608()) {
            return;
        }

        if(isOutputSlotEmptyOrReceivable()) {
            if(this.hasRecipe()) {
                this.increaseCraftProgress();
                method_31663(world, pos, state);

                if(hasCraftingFinished()) {
                    this.craftItem();
                    this.resetProgress();
                }
            } else {
                this.resetProgress();
            }
        } else {
            this.resetProgress();
            method_31663(world, pos, state);
        }
    }

    private void resetProgress() {
        this.progress = 0;
    }

    private void craftItem() {
        class_1799 result = getRecipeResult();

        if (!result.method_7960()) {
            this.method_5434(INPUT_SLOT, 1);
            this.method_5447(OUTPUT_SLOT, new class_1799(result.method_7909(), method_5438(OUTPUT_SLOT).method_7947() + result.method_7947()));
        }

        this.method_5447(OUTPUT_SLOT, new class_1799(result.method_7909(), method_5438(OUTPUT_SLOT).method_7947() + result.method_7947()));
    }

    private class_1799 getRecipeResult() {
        class_1792 input = method_5438(INPUT_SLOT).method_7909();

        if (input == ModFlowerBlock.FLOWER_FIRE.method_8389()) {
            return new class_1799(ModItem.ESSENCE_FIRE);
        } else if (input == ModFlowerBlock.FLOWER_AQUA.method_8389()) {
            return new class_1799(ModItem.ESSENCE_AQUA);
        } else if (input == ModFlowerBlock.FLOWER_AIR.method_8389()) {
            return new class_1799(ModItem.ESSENCE_AIR);
        } else if (input == ModFlowerBlock.FLOWER_EARTH.method_8389()) {
            return new class_1799(ModItem.ESSENCE_EARTH);
        } else if (input == ModFlowerBlock.FLOWER_DARK.method_8389()) {
            return new class_1799(ModItem.ESSENCE_DARK);
        } else if (input == ModFlowerBlock.FLOWER_LIGHT.method_8389()) {
            return new class_1799(ModItem.ESSENCE_LIGHT);
        }

        return class_1799.field_8037;
    }

    private boolean hasCraftingFinished() {
        return progress >= maxProgress;
    }

    private void increaseCraftProgress() {
        progress++;
    }

    private boolean hasRecipe() {
        class_1799 result = new class_1799(ModItem.ESSENCE_FIRE);

        boolean hasInput = method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_FIRE.method_8389()
            || method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_AQUA.method_8389()
            || method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_AIR.method_8389()
            || method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_EARTH.method_8389()
            || method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_DARK.method_8389()
            || method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_LIGHT.method_8389();
        
        if (method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_AQUA.method_8389()) {
            result = new class_1799(ModItem.ESSENCE_AQUA);
        } else if (method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_AIR.method_8389()) {
            result = new class_1799(ModItem.ESSENCE_AIR);
        } else if (method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_EARTH.method_8389()) {
            result = new class_1799(ModItem.ESSENCE_EARTH);
        } else if (method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_DARK.method_8389()) {
            result = new class_1799(ModItem.ESSENCE_DARK);
        } else if (method_5438(INPUT_SLOT).method_7909() == ModFlowerBlock.FLOWER_LIGHT.method_8389()) {
            result = new class_1799(ModItem.ESSENCE_LIGHT);
        }

        return hasInput && canInsertAmountIntoOutputSlot(result) && canInsertItemIntoOutputSlot(result.method_7909());
    }

    private boolean canInsertItemIntoOutputSlot(class_1792 item) {
        return this.method_5438(OUTPUT_SLOT).method_7909() == item || this.method_5438(OUTPUT_SLOT).method_7960();
    }

    private boolean canInsertAmountIntoOutputSlot(class_1799 result) {
        return this.method_5438(OUTPUT_SLOT).method_7947() + result.method_7947() <= method_5438(OUTPUT_SLOT).method_7914();
    }

    private boolean isOutputSlotEmptyOrReceivable() {
        return this.method_5438(OUTPUT_SLOT).method_7960() 
                || this.method_5438(OUTPUT_SLOT).method_7947() < this.method_5438(OUTPUT_SLOT).method_7914();
    }
}