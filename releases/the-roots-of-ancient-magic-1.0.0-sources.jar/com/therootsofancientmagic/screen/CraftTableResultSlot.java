package com.therootsofancientmagic.screen;

import com.therootsofancientmagic.recipe.ModRecipes;
import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1715;
import net.minecraft.class_1731;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3955;

public class CraftTableResultSlot extends class_1735 {

    private final class_1657 player;
    private final class_1715 input;

    public CraftTableResultSlot(
            class_1657 player,
            class_1715 input,
            class_1731 result,
            int index,
            int x,
            int y
    ) {
        super(result, index, x, y);
        this.player = player;
        this.input = input;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return false;
    }

    @Override
    public void method_7667(class_1657 player, class_1799 stack) {
        class_1937 world = player.method_37908();

        if (world.field_9236) {
            return;
        }

        Optional<class_3955> optional = world.method_8433()
                .method_8132(
                        ModRecipes.CUSTOM_CRAFTING_TYPE,
                        this.input,
                        world
                );

        if (optional.isEmpty()) {
            return;
        }

        class_3955 recipe = optional.get();

        class_2371<class_1799> remainder = recipe.method_8111(this.input);

        for (int i = 0; i < this.input.method_5439(); i++) {
            class_1799 inputStack = this.input.method_5438(i);

            if (!inputStack.method_7960()) {
                this.input.method_5434(i, 1);
            }

            class_1799 remainderStack = remainder.get(i);

            if (!remainderStack.method_7960()) {
                if (this.input.method_5438(i).method_7960()) {
                    this.input.method_5447(i, remainderStack.method_7972());
                } else if (class_1799.method_31577(
                        this.input.method_5438(i),
                        remainderStack
                )) {
                    this.input.method_5438(i).method_7933(remainderStack.method_7947());
                } else {
                    player.method_31548().method_7394(remainderStack.method_7972());
                }
            }
        }

        this.method_7669(stack);
    }
}