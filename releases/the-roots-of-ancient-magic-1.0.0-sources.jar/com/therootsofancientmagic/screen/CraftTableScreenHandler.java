package com.therootsofancientmagic.screen;

import com.therootsofancientmagic.recipe.ModRecipes;
import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1715;
import net.minecraft.class_1731;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_3914;
import net.minecraft.class_3955;

public class CraftTableScreenHandler extends class_1703 {

    private final class_1715 input;
    private final class_1731 result = new class_1731();
    private final class_3914 context;
    private final class_1657 player;

    public CraftTableScreenHandler(int syncId, class_1661 playerInventory, class_2540 buf) {
        this(syncId, playerInventory, class_3914.field_17304);
    }

    public CraftTableScreenHandler(int syncId, class_1661 playerInventory, class_2586 entity, class_3913 delegate) {
        this(syncId, playerInventory, class_3914.method_17392(entity.method_10997(), entity.method_11016()));
    }

    public CraftTableScreenHandler(int syncId, class_1661 playerInventory, class_3914 context) {
        super(ModScreenHandlers.CRAFT_TABLE_SCREEN_HANDLER, syncId);

        this.context = context;
        this.player = playerInventory.field_7546;
        this.input = new class_1715(this, 3, 3);

        this.method_7621(new CraftTableResultSlot(
                playerInventory.field_7546,
                this.input,
                this.result,
                0,
                124,
                35
        ));

        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                this.method_7621(new class_1735(
                        this.input,
                        j + i * 3,
                        30 + j * 18,
                        17 + i * 18
                ));
            }
        }

        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.method_7621(new class_1735(
                        playerInventory,
                        j + i * 9 + 9,
                        8 + j * 18,
                        84 + i * 18
                ));
            }
        }

        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(
                    playerInventory,
                    i,
                    8 + i * 18,
                    142
            ));
        }
    }

    @Override
    public void method_7609(class_1263 inventory) {
        this.context.method_17393((world, pos) -> {
            updateResult(
                    this,
                    world,
                    this.player,
                    this.input,
                    this.result
            );
        });
    }

    protected static void updateResult(
            class_1703 handler,
            class_1937 world,
            class_1657 player,
            class_1715 inventory,
            class_1731 result
    ) {
        if (!world.field_9236 && player instanceof class_3222 serverPlayer) {
            class_1799 itemStack = class_1799.field_8037;

            Optional<class_3955> optional = world.method_8433()
                    .method_8132(
                            ModRecipes.CUSTOM_CRAFTING_TYPE,
                            inventory,
                            world
                    );

            if (optional.isPresent()) {
                class_3955 recipe = optional.get();

                if (result.method_7665(world, serverPlayer, recipe)) {
                    itemStack = recipe.method_8116(
                            inventory,
                            world.method_30349()
                    );
                }
            }

            result.method_5447(0, itemStack);
        }
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);

        this.context.method_17393((world, pos) -> {
            this.method_7607(player, this.input);
        });
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slotIndex) {
        class_1799 originalStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(slotIndex);

        if (slot != null && slot.method_7681()) {
            class_1799 stack = slot.method_7677();
            originalStack = stack.method_7972();

            if (slotIndex == 0) {
                if (!this.method_7616(stack, 10, 46, true)) {
                    return class_1799.field_8037;
                }

                slot.method_7670(stack, originalStack);

            } else if (slotIndex >= 1 && slotIndex < 10) {
                if (!this.method_7616(stack, 10, 46, false)) {
                    return class_1799.field_8037;
                }

            } else if (slotIndex >= 10 && slotIndex < 46) {
                if (!this.method_7616(stack, 1, 10, false)) {
                    return class_1799.field_8037;
                }

            } else {
                return class_1799.field_8037;
            }

            if (stack.method_7960()) {
                slot.method_48931(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (stack.method_7947() == originalStack.method_7947()) {
                return class_1799.field_8037;
            }

            if (slotIndex != 0) {
                slot.method_7667(player, stack);
            }

            return originalStack;
        }

        return class_1799.field_8037;
    }
}