package com.therootsofancientmagic.screen;

import com.therootsofancientmagic.item.magic.necklace.NecklaceItem;
import com.therootsofancientmagic.item.magic.ring.RingItem;
import com.therootsofancientmagic.item.magic.robe.ElementalRobeItem;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import com.mojang.datafixers.util.Pair;

public class CustomArmorSlot extends class_1735 {
    private final class_1304 equipmentSlot;

    public static final String MOD_ID = "the-roots-of-ancient-magic";

    public static final class_2960 EMPTY_ROBE_SLOT_TEXTURE = new class_2960(MOD_ID, "item/empty_slot_robe");
    public static final class_2960 EMPTY_NECKLACE_SLOT_TEXTURE = new class_2960(MOD_ID, "item/empty_slot_necklace");
    public static final class_2960 EMPTY_RING_SLOT_TEXTURE = new class_2960(MOD_ID, "item/empty_slot_ring");

    public CustomArmorSlot(class_1263 inventory, int index, int x, int y, class_1304 equipmentSlot) {
        super(inventory, index, x, y);
        this.equipmentSlot = equipmentSlot;
    }

    public class_1304 getEquipmentSlot() {
        return this.equipmentSlot;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        int index = this.method_34266();

        if (index == 0) return stack.method_7909() instanceof ElementalRobeItem;
        if (index == 1) return stack.method_7909() instanceof NecklaceItem;
        if (index == 2 || index == 3) return stack.method_7909() instanceof RingItem;

        return false;
    }

    @Override
    public Pair<class_2960, class_2960> method_7679() {
        int index = this.method_34266();

        if (index == 0) return Pair.of(class_1723.field_21668, EMPTY_ROBE_SLOT_TEXTURE);
        if (index == 1) return Pair.of(class_1723.field_21668, EMPTY_NECKLACE_SLOT_TEXTURE);
        if (index == 2 || index == 3) return Pair.of(class_1723.field_21668, EMPTY_RING_SLOT_TEXTURE);

        return super.method_7679();
    }
}