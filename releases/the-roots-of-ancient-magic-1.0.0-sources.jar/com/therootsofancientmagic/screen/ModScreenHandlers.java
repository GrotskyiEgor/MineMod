package com.therootsofancientmagic.screen;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class ModScreenHandlers {

    public static final class_3917<FurnacePowderScreenHandler> FURNACE_POWDER_SCREEN_HANDLER =
            class_2378.method_10230(
                    class_7923.field_41187,
                    new class_2960(TheRootsOfAncientMagic.MOD_ID, "furnace_powder"),
                    new ExtendedScreenHandlerType<>((syncId, inventory, buf) -> 
                            new FurnacePowderScreenHandler(syncId, inventory, buf))
            );

    public static final class_3917<CraftTableScreenHandler> CRAFT_TABLE_SCREEN_HANDLER =
            class_2378.method_10230(
                    class_7923.field_41187,
                    new class_2960(TheRootsOfAncientMagic.MOD_ID, "craft_table"),
                    new ExtendedScreenHandlerType<>((syncId, inventory, buf) -> 
                            new CraftTableScreenHandler(syncId, inventory, buf))
            );
    
    public static void registerScreenHandlers() {
        TheRootsOfAncientMagic.LOGGER.info("Registering Screen Handlers for " + TheRootsOfAncientMagic.MOD_ID);
    }
}