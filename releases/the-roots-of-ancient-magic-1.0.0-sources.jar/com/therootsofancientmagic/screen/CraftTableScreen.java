package com.therootsofancientmagic.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_757;

public class  CraftTableScreen extends class_465<CraftTableScreenHandler> {
    private static final class_2960 TEXTURE = new class_2960(TheRootsOfAncientMagic.MOD_ID, "textures/gui/craft_table_gui.png");

    public CraftTableScreen(CraftTableScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25268 = 1000;
        field_25270 = 1000;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.setShaderTexture(0, TEXTURE);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25302(TEXTURE, x, y, 0, 0, field_2792, field_2779);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }
}