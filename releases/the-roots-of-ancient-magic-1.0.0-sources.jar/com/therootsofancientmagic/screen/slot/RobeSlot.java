package com.therootsofancientmagic.screen.slot;

import com.therootsofancientmagic.item.ModItem;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class RobeSlot extends class_1735 {

    public RobeSlot(class_1263 inventory, int index, int x, int y) {
        super(inventory, index, x, y);
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return stack.method_31574(ModItem.AIR_ROBE);
    }
}