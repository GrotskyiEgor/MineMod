package com.therootsofancientmagic.entity;

import com.therootsofancientmagic.TheRootsOfAncientMagic;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

public class ModEntities {
    @SuppressWarnings("unchecked")
    public static final class_1299<WindChargeEntity> WIND_CHARGE = (class_1299<WindChargeEntity>)(Object)class_2378.method_10230(
            class_7923.field_41177,
            new class_2960(TheRootsOfAncientMagic.MOD_ID, "wind_charge"),
            FabricEntityTypeBuilder.create(class_1311.field_17715, WindChargeEntity::new)
                    .dimensions(class_4048.method_18385(0.3125f, 0.3125f))
                    .trackRangeBlocks(4)
                    .trackedUpdateRate(10)
                    .build()
    );

    public static void registerModEntities() {
        // This method is called in the main mod initializer
    }
}
