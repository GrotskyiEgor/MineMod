package com.therootsofancientmagic.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;

public class WindChargeEntity extends class_1297 {
    private static final int MAX_LIFETIME = 80; // 4 seconds
    private static final double PULL_RADIUS = 5.0;
    private static final double PULL_STRENGTH = 0.3;
    
    private int lifetime = 0;

    public WindChargeEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
        this.field_5960 = true; // Pass through blocks
    }

    public WindChargeEntity(class_1937 world, double x, double y, double z, class_1657 owner) {
        this(ModEntities.WIND_CHARGE, world);
        this.method_5814(x, y, z);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        
        lifetime++;
        
        // Apply slow drag to velocity
        class_243 vel = this.method_18798();
        this.method_18799(vel.method_1021(0.96));
        
        // Manual movement
        double newX = this.method_23317() + this.method_18798().field_1352;
        double newY = this.method_23318() + this.method_18798().field_1351;
        double newZ = this.method_23321() + this.method_18798().field_1350;
        this.method_5814(newX, newY, newZ);
        
        // Server-side logic only
        if (!this.method_37908().field_9236 && lifetime >= MAX_LIFETIME) {
            this.tryPullEntities();
            this.method_31472();
        }
    }

    private void tryPullEntities() {
        try {
            class_1937 world = this.method_37908();
            double posX = this.method_23317();
            double posY = this.method_23318();
            double posZ = this.method_23321();
            
            // Check all players in world
            for (class_1657 player : world.method_18456()) {
                if (player == null) continue;
                
                double dx = posX - player.method_23317();
                double dy = posY - player.method_23318();
                double dz = posZ - player.method_23321();
                double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
                
                // Only pull if in range
                if (distance > 0 && distance < PULL_RADIUS) {
                    // Normalize direction
                    double nx = dx / distance;
                    double ny = dy / distance;
                    double nz = dz / distance;
                    
                    // Add velocity (don't replace it)
                    player.method_5762(
                        nx * PULL_STRENGTH,
                        ny * PULL_STRENGTH * 0.5, // Less vertical pull
                        nz * PULL_STRENGTH
                    );
                }
            }
        } catch (Exception e) {
            // Ignore any errors
        }
    }

    @Override
    protected void method_5693() {
        // No tracked data
    }

    @Override
    protected void method_5749(class_2487 nbt) {
        this.lifetime = nbt.method_10550("lifetime");
    }

    @Override
    protected void method_5652(class_2487 nbt) {
        nbt.method_10569("lifetime", lifetime);
    }

    @Override
    public class_2596<class_2602> method_18002() {
        return new class_2604(this);
    }
}
