package com.therootsofancientmagic;

import com.therootsofancientmagic.biome.ModBiomes;
import com.therootsofancientmagic.init.worldgen.ConfigureFeatureInit;
import com.therootsofancientmagic.init.worldgen.PlacedFeatureInit;
import com.therootsofancientmagic.world.ModWordGenerator;

import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_7877;
import net.minecraft.class_7924;

public class TheRootsOfAncientMagicDataGenerator
        implements DataGeneratorEntrypoint {

    @Override
    public void onInitializeDataGenerator(
            FabricDataGenerator fabricDataGenerator
    ) {
        FabricDataGenerator.Pack pack =
                fabricDataGenerator.createPack();

        pack.addProvider(ModWordGenerator::new);
    }

    @Override
    public void buildRegistry(class_7877 registryBuilder) {
        registryBuilder.method_46777(
                class_7924.field_41239,
                ConfigureFeatureInit::bootstrap
        );

        registryBuilder.method_46777(
                class_7924.field_41245,
                PlacedFeatureInit::bootstrap
        );

        registryBuilder.method_46777(
            class_7924.field_41236,
            ModBiomes::bootstrap
        );
    }
}