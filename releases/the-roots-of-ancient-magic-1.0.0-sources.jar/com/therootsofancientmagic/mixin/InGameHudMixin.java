package com.therootsofancientmagic.mixin;

import com.therootsofancientmagic.component.CustomArmorHolder;
import com.therootsofancientmagic.item.magic.necklace.NecklaceItem;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_329.class)
public class InGameHudMixin {

    @Unique
    private static final class_2960 ICONS = new class_2960("minecraft", "textures/gui/icons.png");

    @Inject(method = "renderStatusBars", at = @At("TAIL"))
    private void renderExtraFoodOverlay(class_332 context, CallbackInfo ci) {
        class_1657 player = net.minecraft.class_310.method_1551().field_1724;

        if (player == null || player.method_7325()) return;

        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();

            boolean hasNecklace = false;
            for (int i = 0; i < inv.method_5439(); i++) {
                class_1799 stack = inv.method_5438(i);
                if (!stack.method_7960() && stack.method_7909() instanceof NecklaceItem) {
                    hasNecklace = true;
                    break;
                }
            }

            // if (hasNecklace) {
            //     int scaledWidth = context.getScaledWindowWidth();
            //     int scaledHeight = context.getScaledWindowHeight();

            //     int right = scaledWidth / 2 + 91;
            //     int top = scaledHeight - 49; 

            //     for (int i = 0; i < 2; i++) {
            //         int x = right - (i * 8) - 9;
            //         int y = top;

            //         context.drawTexture(ICONS, x, y, 16, 27, 9, 9);
            //         context.drawTexture(ICONS, x, y, 52, 27, 9, 9);
            //     }
            // }
        }
    }

    // @Shadow private int scaledWidth;
    // @Shadow private int scaledHeight;

    // @Inject(method = "renderAir", at = @At("HEAD"), cancellable = true)
    // private void renderExtraAirBubbles(DrawContext context, CallbackInfo ci) {
    //     // PlayerEntity player = MinecraftClient.getInstance().player;

    //     // if (player != null && player.getMaxAir() > 300) {
    //            int air = player.getAir();
    //            int maxAir = player.getMaxAir();

    //            if (player.isSubmergedIn(FluidTags.WATER)) {
    //            ci.cancel();
    //            }
    //        }
    // } 
}