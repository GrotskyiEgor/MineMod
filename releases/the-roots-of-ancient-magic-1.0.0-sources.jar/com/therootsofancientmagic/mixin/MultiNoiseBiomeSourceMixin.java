package com.therootsofancientmagic.mixin;

import net.minecraft.class_1959;
import net.minecraft.class_4766;
import net.minecraft.class_6544;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4766.class)
public class MultiNoiseBiomeSourceMixin {

    @Inject(
            method = "getBiome",
            at = @At("RETURN"),
            cancellable = true
    )
    private void replaceForest(
            int x,
            int y,
            int z,
            class_6544.class_6552 noise,
            CallbackInfoReturnable<class_6880<class_1959>> cir
    ) {

        class_6880<class_1959> original = cir.getReturnValue();

        if (original.method_40225(net.minecraft.class_1972.field_9409)) {
            // Здесь пока нельзя просто получить RegistryEntry
            // твоего биома без RegistryLookup.
        }
    }
}