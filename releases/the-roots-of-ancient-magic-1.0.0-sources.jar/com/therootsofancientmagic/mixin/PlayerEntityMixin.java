package com.therootsofancientmagic.mixin;

import com.therootsofancientmagic.component.CustomArmorHolder;
import com.therootsofancientmagic.entity.WindChargeEntity;
import com.therootsofancientmagic.item.ModItem;
import com.therootsofancientmagic.item.magic.robe.ElementalRobeItem;
import com.therootsofancientmagic.mana.PlayerMana;
import com.therootsofancientmagic.util.IEntityDataSaver;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin implements CustomArmorHolder {

    @Unique
    private final class_1277 customArmorInventory = new class_1277(4);

    @Override
    public class_1263 getCustomArmorInventory() {
        return this.customArmorInventory;
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void writeCustomArmorToNbt(class_2487 nbt, CallbackInfo ci) {
        nbt.method_10566("CustomArmorInventory", this.customArmorInventory.method_7660());
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void readCustomArmorFromNbt(class_2487 nbt, CallbackInfo ci) {
        if (nbt.method_10573("CustomArmorInventory", 9)) {
            class_2499 nbtList = nbt.method_10554("CustomArmorInventory", 10);
            this.customArmorInventory.method_7659(nbtList);
        }
    }

    @Unique
    private int fireRobeTimer = 0;

    @Unique
    private int fireRobeCooldown = 0;

    @Unique
    private boolean isFireRobeOnBack() {
        class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null) {
                class_1799 backStack = inv.method_5438(0);
                return !backStack.method_7960() && backStack.method_31574(ModItem.FIRE_ROBE);
            }
        }
        return false;
    }

    @Override
    public void activateFireRobeAbility() {
        if (isFireRobeOnBack() && this.fireRobeCooldown <= 0) {
            this.fireRobeTimer = 140; 
            this.fireRobeCooldown = 240;
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void applyFireRobeEffects(CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;

        if (!player.method_37908().method_8608()) {
            if (this.fireRobeCooldown > 0) {
                this.fireRobeCooldown--;
            }

            if (this.fireRobeTimer > 0 && isFireRobeOnBack()) {
                this.fireRobeTimer--;

                if (this.fireRobeTimer % 2 == 0) {
                    class_3218 serverWorld = (class_3218) player.method_37908();
                    serverWorld.method_14199(
                        class_2398.field_11240,
                        player.method_23317(),
                        player.method_23323(0.5),
                        player.method_23321(),
                        4, 0.3, 0.5, 0.3, 0.02
                    );
                }
            }
        }
    }

    @Inject(method = "damage", at = @At("TAIL"))
    private void onTakeDamage(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1657 player = (class_1657) (Object) this;

        if (!player.method_37908().method_8608()) {
            class_1297 attacker = source.method_5529();

            if (this.fireRobeTimer > 0 && isFireRobeOnBack() && attacker instanceof class_1309 livingAttacker) {
                livingAttacker.method_5639(4);
            }
        }
    }

    @Unique
    private boolean isAquaRobeOnBack() {
        class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null) {
                class_1799 backStack = inv.method_5438(0);
                return !backStack.method_7960() && backStack.method_31574(ModItem.AQUA_ROBE);
            }
        }
        return false;
    }

    // @Unique
    // private boolean isFireRobeOnBack() {
    //     PlayerEntity player = (PlayerEntity) (Object) this;
    //     if (player instanceof CustomArmorHolder holder) {
    //         Inventory inv = holder.getCustomArmorInventory();
    //         if (inv != null) {
    //             ItemStack backStack = inv.getStack(0);
    //             return !backStack.isEmpty() && backStack.isOf(ModItem.FIRE_ROBE);
    //         }
    //     }
    //     return false;
    // }

    @Override
    public void ActivateAquaRobeAbility() {
        class_1657 player = (class_1657) (Object) this;

        if (isAquaRobeOnBack()
                && !player.method_7357().method_7904(ModItem.AQUA_ROBE)) {

            if (PlayerMana.tryConsumeMana(player, 50)) {

                player.method_6092(new class_1293(
                        class_1294.field_5900,
                        600,
                        0,
                        true,
                        false
                ));

                player.method_6092(new class_1293(
                        class_1294.field_5923,
                        600,
                        0,
                        true,
                        false
                ));

                player.method_7357().method_7906(ModItem.AQUA_ROBE, 700);
            }
        }
    }

    @Override
    public void ActivateFireRobeAbility() {
        class_1657 player = (class_1657) (Object) this;

        if (isFireRobeOnBack()
                && !player.method_7357().method_7904(ModItem.FIRE_ROBE)) {

            if (PlayerMana.tryConsumeMana(player, 50)) {

                this.fireRobeTimer = 200;

                player.method_6092(new class_1293(
                        class_1294.field_5918,
                        200,
                        0,
                        true,
                        false
                ));

                player.method_7357().method_7906(ModItem.FIRE_ROBE, 300);
            }
        }
    }

    @Unique
    private boolean isFireRingInSlot(int slotIndex) {
    class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null && slotIndex < inv.method_5439()) {
                class_1799 stack = inv.method_5438(slotIndex);
                return !stack.method_7960() && stack.method_31574(ModItem.FIRE_RING);
            }
        }
        return false;
    }

    @Unique
    private boolean isAquaRingInSlot(int slotIndex) {
    class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null && slotIndex < inv.method_5439()) {
                class_1799 stack = inv.method_5438(slotIndex);
                return !stack.method_7960() && stack.method_31574(ModItem.AQUA_RING);
            }
        }
        return false;
    }

    @Unique
    private boolean isEarthRingInSlot(int slotIndex) {
    class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null && slotIndex < inv.method_5439()) {
                class_1799 stack = inv.method_5438(slotIndex);
                return !stack.method_7960() && stack.method_31574(ModItem.EARTH_RING);
            }
        }
        return false;
    }

    @Unique
    private boolean isAirRingInSlot(int slotIndex) {
    class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null && slotIndex < inv.method_5439()) {
                class_1799 stack = inv.method_5438(slotIndex);
                return !stack.method_7960() && stack.method_31574(ModItem.AIR_RING);
            }
        }
        return false;
    }

    @Unique
    public void castFireRingSpell() {
        class_1657 player = (class_1657) (Object) this;
        class_239 hitResult = player.method_5745(5.0D, 0.0F, false);
        if (hitResult.method_17783() == class_239.class_240.field_1332) {
            class_3965 blockHit = (class_3965) hitResult;
            class_2338 targetPos = blockHit.method_17777().method_10093(blockHit.method_17780());
            class_1937 world = player.method_37908();
            if (world.method_8320(targetPos).method_26215()) {
                world.method_8501(targetPos, net.minecraft.class_2246.field_10036.method_9564());
                world.method_8396(null, targetPos, net.minecraft.class_3417.field_15145,
                    net.minecraft.class_3419.field_15248, 1.0F, 1.0F);
                if (world instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11240,
                    targetPos.method_10263() + 0.5, targetPos.method_10264() + 0.5, targetPos.method_10260() + 0.5, 15, 0.2, 0.2, 0.2, 0.05);
                }
                player.method_7357().method_7906(ModItem.FIRE_RING, 100);
            }
        }
    }
    
    @Unique
    public void castAquaRingSpell() {
        class_1657 player = (class_1657) (Object) this;
        class_239 hitResult = player.method_5745(5.0D, 0.0F, false);
        if (hitResult.method_17783() == class_239.class_240.field_1332) {
            class_3965 blockHit = (class_3965) hitResult;
            class_2338 targetPos = blockHit.method_17777().method_10093(blockHit.method_17780());
            class_1937 world = player.method_37908();
            if (world.method_8320(targetPos).method_26215()) {
                world.method_8501(targetPos, net.minecraft.class_2246.field_10382.method_9564());
                world.method_8396(null, targetPos, net.minecraft.class_3417.field_14834,
                    net.minecraft.class_3419.field_15248, 1.0F, 1.0F);
                if (world instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11202,
                    targetPos.method_10263() + 0.5, targetPos.method_10264() + 0.5, targetPos.method_10260() + 0.5, 30, 0.3, 0.3, 0.3, 0.1);
                }
                player.method_7357().method_7906(ModItem.AQUA_RING, 100);
            }
        }
    }

    @Unique
    public void castEarthRingSpell() {
        class_1657 player = (class_1657) (Object) this;
        class_239 hitResult = player.method_5745(5.0D, 0.0F, false);
        if (hitResult.method_17783() == class_239.class_240.field_1332) {
            class_3965 blockHit = (class_3965) hitResult;
            class_2338 centerPos = blockHit.method_17777().method_10093(blockHit.method_17780());
            class_1937 world = player.method_37908();
            for (int x = 0; x < 2; x++) {
                for (int y = 0; y < 2; y++) {
                    for (int z = 0; z < 2; z++) {
                        class_2338 targetPos = centerPos.method_10069(x, y, z);
                        if (world.method_8320(targetPos).method_26215() || world.method_8320(targetPos).method_27852(net.minecraft.class_2246.field_10382)) {
                            world.method_8501(targetPos, net.minecraft.class_2246.field_10566.method_9564());
                        }
                    }
                }
            }

            world.method_8396(null, centerPos, net.minecraft.class_3417.field_14609,
                net.minecraft.class_3419.field_15248, 1.0F, 0.8F);

            if (world instanceof class_3218 serverWorld) {
                serverWorld.method_14199(
                    new net.minecraft.class_2388(class_2398.field_11217, net.minecraft.class_2246.field_10566.method_9564()),
                    centerPos.method_10263() + 1.0, centerPos.method_10264() + 1.0, centerPos.method_10263() + 1.0, 40, 0.5, 0.5, 0.5, 0.15);
            }

            player.method_7357().method_7906(ModItem.EARTH_RING, 100);
        }
    }

    @Unique
    public void castAirRingSpell() {
        class_1657 player = (class_1657) (Object) this;
        class_1937 world = player.method_37908();
        class_243 look = player.method_5720();
        player.method_18800(look.field_1352 * 2.0, look.field_1351 * 1.2 + 0.2, look.field_1350 * 2.0);
        player.field_6037 = true;
        if (!world.field_9236 && world instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11204, player.method_23317(), player.method_23318(), player.method_23321(), 20, 0.5, 0.5, 0.5, 0.1);
            world.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_14869,
                net.minecraft.class_3419.field_15248, 1.0F, 1.4F);
            player.method_7357().method_7906(ModItem.AIR_RING, 100);
        }
    }

    @Override
    public void useFirstRingAbility() {
        class_1657 player = (class_1657) (Object) this;

        if (isFireRingInSlot(2)
                && !player.method_7357().method_7904(ModItem.FIRE_RING)) {

            if (PlayerMana.tryConsumeMana(player, 30)) {
                castFireRingSpell();
            }

        } else if (isAquaRingInSlot(2)
                && !player.method_7357().method_7904(ModItem.AQUA_RING)) {

            if (PlayerMana.tryConsumeMana(player, 30)) {
                castAquaRingSpell();
            }

        } else if (isEarthRingInSlot(2)
                && !player.method_7357().method_7904(ModItem.EARTH_RING)) {

            if (PlayerMana.tryConsumeMana(player, 30)) {
                castEarthRingSpell();
            }

        } else if (isAirRingInSlot(2)
                && !player.method_7357().method_7904(ModItem.AIR_RING)) {

            if (PlayerMana.tryConsumeMana(player, 30)) {
                castAirRingSpell();
            }
        }
    }

    @Override
    public void useSecondRingAbility() {
        class_1657 player = (class_1657) (Object) this;

        if (isFireRingInSlot(3)
                && !player.method_7357().method_7904(ModItem.FIRE_RING)) {

            if (PlayerMana.tryConsumeMana(player, 30)) {
                castFireRingSpell();
            }
        } else if (isAquaRingInSlot(3)
                && !player.method_7357().method_7904(ModItem.AQUA_RING)) {

            if (PlayerMana.tryConsumeMana(player, 30)) {
                castAquaRingSpell();
            }

        } else if (isEarthRingInSlot(3)
                && !player.method_7357().method_7904(ModItem.EARTH_RING)) {

            if (PlayerMana.tryConsumeMana(player, 30)) {
                castEarthRingSpell();
            }

        } else if (isAirRingInSlot(3)
                && !player.method_7357().method_7904(ModItem.AIR_RING)) {

            if (PlayerMana.tryConsumeMana(player, 30)) {
                castAirRingSpell();
            }
        }
    }

    @Unique
    private boolean isFireNecklaceInSlot(int slotIndex) {
        class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null && slotIndex >= 0 && slotIndex < inv.method_5439()) {
                return inv.method_5438(slotIndex).method_31574(ModItem.FIRE_NECKLACE);
            }
        }
        return false;
    }

    @Unique
    private boolean isAirNecklaceInSlot(int slotIndex) {
        class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null && slotIndex >= 0 && slotIndex < inv.method_5439()) {
                return inv.method_5438(slotIndex).method_31574(ModItem.AIR_NECKLACE);
            }
        }
        return false;
    }

    @Unique
    private boolean isEarthNecklaceInSlot(int slotIndex) {
        class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null && slotIndex >= 0 && slotIndex < inv.method_5439()) {
                return inv.method_5438(slotIndex).method_31574(ModItem.EARTH_NECKLACE);
            }
        }
        return false;
    }

    @Unique
    private boolean isAquaNecklaceInSlot(int slotIndex) {
        class_1657 player = (class_1657) (Object) this;
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            if (inv != null && slotIndex >= 0 && slotIndex < inv.method_5439()) {
                return inv.method_5438(slotIndex).method_31574(ModItem.AQUA_NECKLACE);
            }
        }
        return false;
    }
    
    @Inject(method = "tick", at = @At("HEAD"))
    private void FireNecklacePassive(CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        class_1937 world = player.method_37908();

        if (!world.method_8608() && player.field_6012 % 10 == 0) {
            if (isFireNecklaceInSlot(1)) {
                if (!player.method_6059(class_1294.field_5898)) {
                    player.method_6092(new class_1293(class_1294.field_5898, 200, 0, true, false, false));
                }
            } else {
                if (player.method_6059(class_1294.field_5898)) {
                    player.method_6016(class_1294.field_5898);
                }
            }
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void AirNecklacePassive(CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        class_1937 world = player.method_37908();

        if (!world.method_8608() && player.field_6012 % 10 == 0) {
            if (isAirNecklaceInSlot(1)) {
                if (!player.method_6059(class_1294.field_5904)) {
                    player.method_6092(new class_1293(class_1294.field_5904, 210, 0, true, false, false));
                }
            } else {
                if (player.method_6059(class_1294.field_5904)) {
                    player.method_6016(class_1294.field_5904);
                }
            }
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void EarthNecklacePassive(CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        class_1937 world = player.method_37908();

        if (!world.method_8608() && player.field_6012 % 10 == 0) {
            if (isEarthNecklaceInSlot(1)) {
                if (!player.method_6059(class_1294.field_5913)) {
                    player.method_6092(new class_1293(class_1294.field_5913, 210, 0, true, false, false));
                }
            } else {
                if (player.method_6059(class_1294.field_5913)) {
                    player.method_6016(class_1294.field_5913);
                }
            }
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void AquaNecklacePassive(CallbackInfo ci) {
       class_1657 player = (class_1657) (Object) this;
        class_1937 world = player.method_37908();

        if (!world.method_8608()) {
            if (isAquaNecklaceInSlot(1)) {
                // Якщо амулет одягнений, кожні 10 тіків оновлюємо ефект водного дихання
                if (player.field_6012 % 10 == 0 && !player.method_6059(class_1294.field_5923)) {
                    // Тривалість 210 тіків (10.5 сек), рівень 0 (I), без бульбашок ефекту та іконок
                    player.method_6092(new class_1293(class_1294.field_5923, 210, 0, true, false, true));
                }
            } else {
                // Якщо амулет зняли, миттєво прибираємо ефект
                if (player.method_6059(class_1294.field_5923)) {
                    player.method_6016(class_1294.field_5923);
                }
            }
        }
    }
}

