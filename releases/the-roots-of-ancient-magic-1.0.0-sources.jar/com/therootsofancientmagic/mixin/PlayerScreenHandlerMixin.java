package com.therootsofancientmagic.mixin;

import com.therootsofancientmagic.component.CustomArmorHolder;
import com.therootsofancientmagic.screen.CustomArmorSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1723.class)
public abstract class PlayerScreenHandlerMixin extends class_1703 {

    private static final class_1304[] EQUIPMENT_SLOTS = new class_1304[]{
        class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    protected PlayerScreenHandlerMixin() {
        super(null, 0);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void addCustomArmorSlots(class_1661 playerInventory, boolean onServer, class_1657 owner, CallbackInfo ci) {
        if (owner instanceof CustomArmorHolder holder) {
            class_1263 customArmor = holder.getCustomArmorInventory();

            for (int i = 0; i < 4; i++) {
                this.method_7621(new CustomArmorSlot(customArmor, i, -23, 8 + i * 18, EQUIPMENT_SLOTS[i]));
            }
        }
    }

    @Inject(method = "quickMove", at = @At("HEAD"), cancellable = true)
    private void handleCustomQuickMove(class_1657 player, int slotIndex, CallbackInfoReturnable<class_1799> cir) {
        if (slotIndex < 0 || slotIndex >= this.field_7761.size()) return;

        class_1735 slot = this.field_7761.get(slotIndex);

        if (slot instanceof CustomArmorSlot && slot.method_7681()) {
            class_1799 stackInSlot = slot.method_7677();
            class_1799 copy = stackInSlot.method_7972();

            if (!this.method_7616(stackInSlot, 9, 45, true)) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }

            if (stackInSlot.method_7960()) {
                slot.method_48931(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            slot.method_7667(player, stackInSlot);
            cir.setReturnValue(copy);
        }
    }
}