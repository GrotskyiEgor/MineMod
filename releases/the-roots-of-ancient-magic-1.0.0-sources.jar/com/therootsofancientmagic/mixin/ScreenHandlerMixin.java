package com.therootsofancientmagic.mixin;

import com.therootsofancientmagic.screen.CustomArmorSlot;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1703.class)
public abstract class ScreenHandlerMixin {

    @Inject(
        method = "onSlotClick", 
        at = @At("HEAD"), 
        cancellable = true
    )
    private void handleCustomSlotClick(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo ci) {
        class_1703 handler = (class_1703) (Object) this;

        if (handler instanceof class_1723) {
            if (slotIndex >= 0 && slotIndex < handler.field_7761.size()) {
                class_1735 slot = handler.field_7761.get(slotIndex);

                if (slot instanceof CustomArmorSlot) {
                    if (actionType == class_1713.field_7790) {
                        class_1799 cursorStack = handler.method_34255();
                        class_1799 slotStack = slot.method_7677();

                        if (cursorStack.method_7960() && !slotStack.method_7960()) {
                            handler.method_34254(slotStack.method_7972());
                            slot.method_48931(class_1799.field_8037);
                            slot.method_7667(player, slotStack);
                        } else if (!cursorStack.method_7960() && slot.method_7680(cursorStack)) {
                            if (slotStack.method_7960()) {
                                slot.method_48931(cursorStack.method_7971(1));
                            } else if (class_1799.method_31577(slotStack, cursorStack)) {
                                int max = Math.min(cursorStack.method_7914(), slot.method_7675());
                                int transfer = Math.min(cursorStack.method_7947(), max - slotStack.method_7947());
                                cursorStack.method_7934(transfer);
                                slotStack.method_7933(transfer);
                            }
                        }
                    } else if (actionType == class_1713.field_7794) {
                        handler.method_7601(player, slotIndex);
                    } else if (actionType == class_1713.field_7795 && slot.method_7681()) {
                        class_1799 itemStack = slot.method_7671(button == 0 ? 1 : slot.method_7677().method_7947());
                        slot.method_7667(player, itemStack);
                        player.method_7328(itemStack, true);
                    }

                    slot.method_7668();
                    handler.method_7623();
                    ci.cancel();
                }
            }
        }
    }
}