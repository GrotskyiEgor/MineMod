package com.therootsofancientmagic.mixin;

import net.minecraft.class_1661;
import net.minecraft.class_1723;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_485;
import net.minecraft.class_490;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_490.class)
public abstract class InventoryScreenMixin extends class_485<class_1723> {

    @Unique
    private static final class_2960 INVENTORY_TEXTURE = new class_2960("minecraft", "textures/gui/container/inventory.png");

    public InventoryScreenMixin(class_1723 screenHandler, class_1661 playerInventory, class_2561 text) {
        super(screenHandler, playerInventory, text);
    }

    @Inject(method = "isClickOutsideBounds", at = @At("HEAD"), cancellable = true)
    private void allowCustomSlotClick(double mouseX, double mouseY, int left, int top, int button, CallbackInfoReturnable<Boolean> cir) {
        if (mouseX >= left - 30 && mouseX <= left && mouseY >= top && mouseY <= top + 81) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "drawBackground", at = @At("TAIL"))
    private void drawCustomSlotTextures(class_332 context, float delta, int mouseX, int mouseY, CallbackInfo ci) {
        int panelX1 = this.field_2776 - 29;
        int panelY1 = this.field_2800 + 4;
        int panelX2 = this.field_2776 - 1;
        int panelY2 = this.field_2800 + 83;

        context.method_25294(panelX1, panelY1, panelX2, panelY2, 0xFFFFFFFF);

        context.method_25294(panelX1 + 1, panelY1 + 1, panelX2 - 1, panelY2 - 1, 0xFF555555);

        context.method_25294(panelX1 + 1, panelY1 + 1, panelX2 - 2, panelY2 - 2, 0xFFC6C6C6);

        int startX = this.field_2776 - 24;
        int startY = this.field_2800 + 7;

        for (int i = 0; i < 4; i++) {
            context.method_25302(INVENTORY_TEXTURE, startX, startY + (i * 18), 7, 7, 18, 18);
        }

        int lastSlotY = startY + (3 * 18);
        context.method_25294(startX, lastSlotY + 17, startX + 18, lastSlotY + 18, 0xFF373737);
    }
}