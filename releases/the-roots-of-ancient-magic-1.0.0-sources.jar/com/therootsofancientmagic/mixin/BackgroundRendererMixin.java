package com.therootsofancientmagic.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.therootsofancientmagic.biome.ModBiomes;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_758.class)
public class BackgroundRendererMixin {

    private static float earthFog = 0.0F;

    @Inject(
            method = "applyFog",
            at = @At("TAIL")
    )
    private static void earthMagicFog(
            class_4184 camera,
            class_758.class_4596 fogType,
            float viewDistance,
            boolean thickFog,
            float tickDelta,
            CallbackInfo ci
    ) {
        class_1297 entity = camera.method_19331();

        if (!(entity.method_37908() instanceof class_638 world)) {
            return;
        }

        class_2338 pos = entity.method_24515();

        boolean isEarth = world.method_23753(pos)
                .method_40230()
                .orElse(null)
                .equals(ModBiomes.EARTH);

        float target = isEarth ? 1.0F : 0.0F;

        earthFog += (target - earthFog) * 0.08F;

        if (earthFog < 0.001F) {
            earthFog = 0.0F;
            return;
        }

        float start = 25.0F - 11.0F * earthFog;
        float end = 90.0F - 25.0F * earthFog;

        RenderSystem.setShaderFogStart(start);
        RenderSystem.setShaderFogEnd(end);
    }
}