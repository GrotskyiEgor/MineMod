package com.therootsofancientmagic.mixin;

import com.therootsofancientmagic.component.CustomArmorHolder;
import com.therootsofancientmagic.item.magic.necklace.NecklaceItem;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1702;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1702.class)
public class HungerManagerMixin {

    @Shadow
    private int foodLevel;

    @Inject(method = "update", at = @At("HEAD"))
    private void updateExtraFood(class_1657 player, CallbackInfo ci) {
        if (player instanceof CustomArmorHolder holder) {
            class_1263 inv = holder.getCustomArmorInventory();
            
            boolean hasNecklace = false;
            for (int i = 0; i < inv.method_5439(); i++) {
                class_1799 stack = inv.method_5438(i);
                if (!stack.method_7960() && stack.method_7909() instanceof NecklaceItem) {
                    hasNecklace = true;
                    break;
                }
            }

            if (hasNecklace) {
                if (this.foodLevel < 22) {
                    this.foodLevel = 22;
                }
            } else {
                if (this.foodLevel > 20) {
                    this.foodLevel = 20;
                }
            }
        }
    }
}