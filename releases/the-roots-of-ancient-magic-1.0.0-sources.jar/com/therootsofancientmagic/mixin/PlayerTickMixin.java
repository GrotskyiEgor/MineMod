package com.therootsofancientmagic.mixin;

import com.therootsofancientmagic.item.ModItem;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public class PlayerTickMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void checkPlayerArmor(CallbackInfo ci) {

        class_1657 player = (class_1657) (Object) this;

        // Проверяем броню один раз в секунду
        if (player.field_6012 % 20 != 0) {
            return;
        }

        if (hasFullSet(
                player,
                ModItem.FIRE_HELMET,
                ModItem.FIRE_CHESTPLATE,
                ModItem.FIRE_LEGGINGS,
                ModItem.FIRE_BOOTS
        )) {

            player.method_6092(new class_1293(
                    class_1294.field_5918,
                    40,
                    0,
                    false,
                    true,
                    true
            ));
        }

        else if (hasFullSet(
                player,
                ModItem.AQUA_HELMET,
                ModItem.AQUA_CHESTPLATE,
                ModItem.AQUA_LEGGINGS,
                ModItem.AQUA_BOOTS
        )) {

            player.method_6092(new class_1293(
                    class_1294.field_5900,
                    40,
                    0,
                    false,
                    true,
                    true
            ));
        }

        else if (hasFullSet(
                player,
                ModItem.AIR_HELMET,
                ModItem.AIR_CHESTPLATE,
                ModItem.AIR_LEGGINGS,
                ModItem.AIR_BOOTS
        )) {

            // Скорость I
            player.method_6092(new class_1293(
                    class_1294.field_5904,
                    40,
                    0,
                    false,
                    true,
                    true
            ));

            // Прыгучесть I
            player.method_6092(new class_1293(
                    class_1294.field_5913,
                    40,
                    0,
                    false,
                    true,
                    true
            ));
        }

        else if (hasFullSet(
                player,
                ModItem.DARK_HELMET,
                ModItem.DARK_CHESTPLATE,
                ModItem.DARK_LEGGINGS,
                ModItem.DARK_BOOTS
        )) {

            player.method_6092(new class_1293(
                    class_1294.field_5925,
                    40,
                    0,
                    false,
                    true,
                    true
            ));
        }

        else if (hasFullSet(
                player,
                ModItem.LIGHT_HELMET,
                ModItem.LIGHT_CHESTPLATE,
                ModItem.LIGHT_LEGGINGS,
                ModItem.LIGHT_BOOTS
        )) {

            // Регенерация II
            player.method_6092(new class_1293(
                    class_1294.field_5924,
                    40,
                    1,
                    false,
                    true,
                    true
            ));
        }

        else if (hasFullSet(
                player,
                ModItem.EARTH_HELMET,
                ModItem.EARTH_CHESTPLATE,
                ModItem.EARTH_LEGGINGS,
                ModItem.EARTH_BOOTS
        )) {

            // Спешка I
            player.method_6092(new class_1293(
                    class_1294.field_5917,
                    40,
                    0,
                    false,
                    true,
                    true
            ));
        }

        else if (hasFullSet(
                player,
                ModItem.HEROIC_HELMET,
                ModItem.HEROIC_CHESTPLATE,
                ModItem.HEROIC_LEGGINGS,
                ModItem.HEROIC_BOOTS
        )) {

            // Скорость I
            player.method_6092(new class_1293(
                    class_1294.field_5904,
                    40,
                    0,
                    false,
                    true,
                    true
            ));

            // Сила I
            player.method_6092(new class_1293(
                    class_1294.field_5910,
                    40,
                    0,
                    false,
                    true,
                    true
            ));

            // Спешка I
            player.method_6092(new class_1293(
                    class_1294.field_5917,
                    40,
                    0,
                    false,
                    true,
                    true
            ));

            // Ночное зрение
            player.method_6092(new class_1293(
                    class_1294.field_5925,
                    40,
                    0,
                    false,
                    true,
                    true
            ));

            // Регенерация I
            player.method_6092(new class_1293(
                    class_1294.field_5924,
                    40,
                    0,
                    false,
                    true,
                    true
            ));
        }
    }

    private boolean hasFullSet(
            class_1657 player,
            class_1792 helmet,
            class_1792 chestplate,
            class_1792 leggings,
            class_1792 boots
    ) {

        return player.method_6118(class_1304.field_6169).method_31574(helmet)
                && player.method_6118(class_1304.field_6174).method_31574(chestplate)
                && player.method_6118(class_1304.field_6172).method_31574(leggings)
                && player.method_6118(class_1304.field_6166).method_31574(boots);
    }      
}