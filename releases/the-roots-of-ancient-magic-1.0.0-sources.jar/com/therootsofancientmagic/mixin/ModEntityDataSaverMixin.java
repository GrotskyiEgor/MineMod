package com.therootsofancientmagic.mixin;

import com.therootsofancientmagic.util.IEntityDataSaver;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class) // Внедряемся в базов ий класс всех сущностей в Майнкрафте
public abstract class ModEntityDataSaverMixin implements IEntityDataSaver {
    // Кастомний карман для NBT тегов ман и
    private class_2487 persistentData;

    @Override
    public class_2487 getPersistentData() {
        if (this.persistentData == null) {
            this.persistentData = new class_2487();
        }
        return this.persistentData;
    }

    // Инжектим логику записи данн их: сохраняем наш карман при в иходе игрока из мира
    @Inject(method = "writeNbt", at = @At("HEAD"))
    protected void injectWriteMethod(class_2487 nbt, CallbackInfoReturnable<class_2487> info) {
        if (this.persistentData != null) {
            nbt.method_10566("therootsofancientmagic.mana_data", this.persistentData);
        }
    }

    // Инжектим логику чтения данн их: загружаем ману обратно, когда игрок заходит на сервер
    @Inject(method = "readNbt", at = @At("HEAD"))
    protected void injectReadMethod(class_2487 nbt, CallbackInfo info) {
        if (nbt.method_10573("therootsofancientmagic.mana_data", 10)) {
            this.persistentData = nbt.method_10562("therootsofancientmagic.mana_data");
        }
    }
}
